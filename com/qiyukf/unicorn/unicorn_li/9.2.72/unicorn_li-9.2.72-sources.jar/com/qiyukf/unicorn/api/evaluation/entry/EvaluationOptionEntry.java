package com.qiyukf.unicorn.api.evaluation.entry;


import com.qiyukf.nimlib.ysf.attach.AttachObject;
import com.qiyukf.nimlib.ysf.attach.constant.AttachTag;

import java.util.List;

/**
 * Describe: 满意度选项信息的 entry
 */
public class EvaluationOptionEntry implements AttachObject {
    //选项名字，例如满意，非常满意，不满意等
    @AttachTag("name")
    private String name;
    //该选项的分数
    @AttachTag("value")
    private int value;
    //选项的标签集合，一个选项可能对应多个标签
    @AttachTag("tagList")
    private List<String> tagList;  //标签列表
    //标签是否必填  0:非必填 1:必填
    @AttachTag("tagRequired")
    private int tagRequired;
    //当选择这个标签的时候满意度备注是否必填 0:非必填 1:必填
    @AttachTag("commentRequired")
    private int commentRequired;

    public int getTagRequired() {
        return tagRequired;
    }

    public int getCommentRequired() {
        return commentRequired;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }

    public List<String> getTagList() {
        return tagList;
    }

    public void setTagList(List<String> tagList) {
        this.tagList = tagList;
    }
}
