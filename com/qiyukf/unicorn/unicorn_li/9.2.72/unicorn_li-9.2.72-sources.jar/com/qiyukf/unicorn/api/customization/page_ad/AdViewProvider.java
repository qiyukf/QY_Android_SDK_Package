package com.qiyukf.unicorn.api.customization.page_ad;

import android.content.Context;
import android.view.View;

/**
 * Describe:聊天界面广告 view 的 provider
 */
public interface AdViewProvider {

    /**
     * 当我们需要聊天界面的广告 view 的时候会调用该方法
     * @return 返回 APP 方想要放置的 view
     */
    View getAdview(Context context);
}
