package com.qiyukf.unicorn.api;

import android.text.TextUtils;

import com.qiyukf.unicorn.api.msg.ProductReslectOnclickListener;

import java.io.Serializable;
import java.util.List;

/**
 * 访客发起会话时自定义商品消息设置接口。
 */
public class ProductDetail implements Serializable, Cloneable {
    private String title;
    private String desc;
    private String picture;
    private String url;
    private String note;
    private int show;
    private boolean alwaysSend;
    private String ext;
    private List<Tag> tags;
    private String tagString;
    private boolean openTemplate;
    private String actionText;
    //发送连接文字的颜色 十六进制颜色例如：0xFFDB7093
    private int actionTextColor;
    private boolean sendByUser;
    private String reselectText;
    private ProductReslectOnclickListener productReslectOnclickListener;
    private String handlerTag;
    private boolean isOpenReselect;
    private int cardType;
    private String goodsCId;
    private String goodsCName;
    private String goodsId;
    private String orderId;
    private String intent;
    private int cardShowStyle;
    private String orderTime;
    private String orderStatus;
    private String price;
    private String originalPrice;
    private String payMoney;
    private String orderCount;
    private String productCount;    // 加粗的 客户传X
    private String orderSku;

    private ProductDetail() {
    }

    @Override
    public final boolean equals(Object o) {
        if (o instanceof ProductDetail) {
            ProductDetail detail = (ProductDetail) o;
            return TextUtils.equals(this.url, detail.url)
                    && TextUtils.equals(this.title, detail.title)
                    && TextUtils.equals(this.desc, detail.desc);
        }
        return false;
    }

    @Override
    public final ProductDetail clone() {
        try {
            return (ProductDetail) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public final boolean valid() {
        return !TextUtils.isEmpty(title)
                || !TextUtils.isEmpty(desc)
                || !TextUtils.isEmpty(picture)
                || !TextUtils.isEmpty(url)
                || !TextUtils.isEmpty(note);
    }

    public void setSendByUser(boolean sendByUser) {
        this.sendByUser = sendByUser;
    }

    /**
     * 获取自定义商品消息的标题
     *
     * @return 自定义商品消息的标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 获取自定义商品消息的摘要
     *
     * @return 自定义商品消息的摘要
     */
    public String getDesc() {
        return desc;
    }

    /**
     * 获取自定义商品消息的缩略图地址
     *
     * @return 自定义商品消息的缩略图地址
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 获取自定义商品消息点击后的跳转地址
     *
     * @return 自定义商品消息点击后的跳转地址
     */
    public String getUrl() {
        return url;
    }

    /**
     * 获取自定义商品消息的备注
     *
     * @return 自定义商品消息的备注
     */
    public String getNote() {
        return note;
    }

    /**
     * 获取自定义商品消息是否显示在访客端的值
     *
     * @return 自定义商品消息是否显示在访客端的值
     */
    public int getShow() {
        return show;
    }

    /**
     * 是否每次打开聊天窗口都发送商品消息。（相同的商品信息不会重复发送）
     *
     * @return true，如果在聊天过程中也可以发送；false，如果只在连接上客服时发送
     */
    public boolean isAlwaysSend() {
        return alwaysSend;
    }

    /**
     * 扩展字段
     */
    public String getExt() {
        return ext;
    }

    /**
     * 设置更多操作按钮入口
     *
     * @return
     */
    public List<Tag> getTags() {
        return tags;
    }

    public String getTagString() {
        return tagString;
    }

    /**
     * 获取商品是否开启新模版
     *
     * @return
     */
    public boolean isOpenTemplate() {
        return openTemplate;
    }

    /**
     * 获取底部发送链接的文案
     *
     * @return
     */
    public String getActionText() {
        return actionText;
    }

    /**
     * 获取发送链接文字的颜色
     *
     * @return
     */
    public int getActionTextColor() {
        return actionTextColor;
    }

    /**
     * 设置商品是否手动发送,该参数只有通过进入 activity 或 fragment 传递 source 的时候才会生效
     *
     * @return
     */
    public boolean isSendByUser() {
        return sendByUser;
    }

    /**
     * 获取重新选择按钮文案
     *
     * @return
     */
    public String getReselectText() {
        return reselectText;
    }

    /**
     * 获取重新选择按钮点击事件
     *
     * @return
     */
    public ProductReslectOnclickListener getProductReslectOnclickListener() {
        return productReslectOnclickListener;
    }

    /**
     * 获取重新选择按钮事件的 tag
     *
     * @return
     */
    public String getHandlerTag() {
        return handlerTag;
    }

    /**
     * 获取是否打开重新选择按钮的值
     *
     * @return
     */
    public boolean isOpenReselect() {
        return isOpenReselect;
    }

    /**
     * 卡片类型
     * @return
     */
    public int getCardType() {
        return cardType;
    }

    public String getGoodsCId() {
        return goodsCId;
    }

    public String getGoodsCName() {
        return goodsCName;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getIntent() {
        return intent;
    }

    public int getCardShowStyle() {
        return cardShowStyle;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public String getPrice() {
        return price;
    }

    public String getOriginalPrice() {
        return originalPrice;
    }

    public String getPayMoney() {
        return payMoney;
    }

    public String getOrderCount() {
        return orderCount;
    }

    public String getOrderSku() {
        return orderSku;
    }

    public String getProductCount() {
        return productCount;
    }


    /**
     * 商品链接附带的一些操作入口，用于客服更方便获取信息。
     */
    public static class Tag implements Serializable, Cloneable {
        private String label;
        private String url;
        private String focusIframe;
        private String data;

        public Tag() {

        }

        /**
         * @param label       操作入口的显示名字。
         * @param url         点击响应跳转的url地址
         * @param focusIframe 如果这个url需要跳转到七鱼客服界面中嵌入的iframe标签名。
         * @param data        如果需要打开iframe标签时，data会传递给指定的iframe
         */
        public Tag(String label, String url, String focusIframe, String data) {
            this.label = label;
            this.url = url;
            this.data = data;
            this.focusIframe = focusIframe;
        }

        /**
         * 设置操作入口的显示名字。
         *
         * @param label 显示名字
         */
        public void setLabel(String label) {
            this.label = label;
        }

        /**
         * 操作入口的显示名字。
         *
         * @return 显示名字
         */
        public String getLabel() {
            return label;
        }

        /**
         * 设置点击响应跳转的url地址
         *
         * @param url url
         */
        public void setUrl(String url) {
            this.url = url;
        }


        /**
         * 点击响应跳转的url地址
         *
         * @return url
         */
        public String getUrl() {
            return url;
        }

        /**
         * 如果这个url需要跳转到七鱼客服界面中嵌入的iframe标签, 可通过该接口传入对应的标签名
         *
         * @param focusIframe 标签名
         */
        public void setFocusIframe(String focusIframe) {
            this.focusIframe = focusIframe;
        }

        /**
         * 如果这个url需要跳转到七鱼客服界面中嵌入的iframe标签名。
         *
         * @return
         */
        public String getFocusIframe() {
            return focusIframe;
        }

        /**
         * 设置传递给iframe页面的数据
         *
         * @param data
         */
        public void setData(String data) {
            this.data = data;
        }

        /**
         * 如果需要打开iframe标签时，data会传递给指定的iframe
         *
         * @return
         */
        public String getData() {
            return data;
        }

    }

    /**
     * 访客发起会话时自定义商品消息对象的创建和属性设置接口。
     */
    public static class Builder {
        private ProductDetail productDetail;

        public Builder() {
            productDetail = new ProductDetail();
        }

        /**
         * 设置自定义商品消息的标题，非必填，未填写时不显示，消息传输时不超过100字，超过时自动截断进行传输。
         *
         * @param title 自定义商品消息的标题
         */
        public Builder setTitle(String title) {
            productDetail.title = title.length() > 100 ? title.substring(0, 100) : title;
            return this;
        }

        /**
         * 设置自定义商品消息的摘要，非必填，未填写时不显示，消息传输时不超过300字，超过时自动截断进行传输。
         *
         * @param desc 自定义商品消息的摘要
         */
        public Builder setDesc(String desc) {
            if (TextUtils.isEmpty(desc)) {
                return this;
            }
            productDetail.desc = desc.length() > 300 ? desc.substring(0, 300) : desc;
            return this;
        }

        /**
         * 设置自定义商品消息的缩略图地址，非必填，未填写时显示默认图片，消息传输时不超过1000字，超过时自动截断进行传输。
         *
         * @param picture 自定义商品消息的缩略图地址。picture支持的格式由开发者自由定义，但必须要支持 file://， http:// 和 https:// 这3种。
         */
        public Builder setPicture(String picture) {
            productDetail.picture = picture;
            return this;
        }

        /**
         * 设置自定义商品消息点击后的跳转地址，非必填，未填写时不可点击，消息传输时不超过1000字，超过时自动截断进行传输。
         *
         * @param url 自定义商品消息点击后的跳转地址。url支持的格式由开发者自由定义。但必须要支持 file://， http:// 和 https:// 这3种
         */
        public Builder setUrl(String url) {
            productDetail.url = url;
            return this;
        }

        /**
         * 设置自定义商品消息的备注，非必填，未填写时不显示，消息传输时不超过100字，超过时自动截断进行传输。<br>
         * 可以填写商品的价格或其他备注信息。
         *
         * @param note 自定义商品消息的备注
         */
        public Builder setNote(String note) {
            if (TextUtils.isEmpty(note)) {
                note = "";
            }
            productDetail.note = note.length() > 100 ? note.substring(0, 100) : note;
            return this;
        }

        /**
         * 访客发起会话时，设置自定义商品消息是否显示在访客端，非必填，1为显示，未填写或者填入其他值时不显示在访客端。
         *
         * @param show 自定义商品消息是否显示在访客端
         */
        public Builder setShow(int show) {
            productDetail.show = show;
            return this;
        }

        /**
         * 设置是否每次打开聊天窗口都发送商品消息。（相同的商品信息不会重复发送）
         *
         * @param alwaysSend true，如果在聊天过程中也可以发送；false，如果只在连接上客服时发送
         */
        public Builder setAlwaysSend(boolean alwaysSend) {
            productDetail.alwaysSend = alwaysSend;
            return this;
        }

        /**
         * 设置扩展字段
         */
        public Builder setExt(String ext) {
            productDetail.ext = ext;
            return this;
        }

        /**
         * 设置快捷入口列表。可以为null
         * 该接口与 {@link #setTagString(String)}互斥，若都设置了，以 setTagString 方法为准
         *
         * @param tags 快捷入口列表
         * @return this
         */
        public Builder setTags(List<Tag> tags) {
            productDetail.tags = tags;
            return this;
        }


        /**
         * 是否开启新模版的展示
         */
        public Builder setOpenTemplate(boolean openTemplate) {
            productDetail.openTemplate = openTemplate;
            return this;
        }

        /**
         * 设置商品是否需要手动发送
         */
        public Builder setSendByUser(boolean sendByUser) {
            productDetail.sendByUser = sendByUser;
            return this;
        }

        /**
         * 设置底部发送链接的 text
         */
        public Builder setActionText(String actionText) {
            productDetail.actionText = actionText;
            return this;
        }

        /**
         * 设置发送链接文字的颜色
         */
        public Builder setActionTextColor(int actionTextColor) {
            productDetail.actionTextColor = actionTextColor;
            return this;
        }

        /**
         * 设置重新选择按钮的文案
         */
        public Builder setReselectText(String reselectText) {
            productDetail.reselectText = reselectText;
            return this;
        }

        /**
         * 设置重新选择按钮的点击事件
         */
        public Builder setProductReslectOnclickListener(ProductReslectOnclickListener listener) {
            productDetail.productReslectOnclickListener = listener;
            return this;
        }

        /**
         * 设置重新选择事件的标志，当点击重新选择按钮的点击事件可能会用到
         */
        public Builder setHandlerTag(String handlerTag) {
            productDetail.handlerTag = handlerTag;
            return this;
        }

        /**
         * 设置快捷入口列表, 内容格式必须为JSONArray， 各 item 字段名为 {@link Tag}的各字段，可以为null
         * 该接口供高级可扩展需求使用，一般使用 {@link #setTags(List)} 方法即可
         * 该接口与 {@link #setTags(List)}互斥，若都设置了，以 setTagString 方法为准
         *
         * @param tagString 快捷入口列表
         * @return this
         */
        public Builder setTagString(String tagString) {
            productDetail.tagString = tagString;
            return this;
        }

        /**
         * 设置是否展示重新选择按钮
         */
        public Builder setIsOpenReselect(boolean isOpenReselect) {
            productDetail.isOpenReselect = isOpenReselect;
            return this;
        }

        /**
         * 设置卡片类型
         * 商品: 0
         * 订单: 1
         * 自定义卡片: 2
         */
        public Builder setCardType(int cardType) {
            productDetail.cardType = cardType;
            return this;
        }

        /**
         * 商品类目ID
         */
        public Builder setGoodsCId(String goodsCId) {
            productDetail.goodsCId = goodsCId;
            return this;
        }

        /**
         * 商品类目名称
         */
        public Builder setGoodsCName(String goodsCName) {
            productDetail.goodsCName = goodsCName;
            return this;
        }

        /**
         * 商品ID
         */
        public Builder setGoodsId(String goodsId) {
            productDetail.goodsId = goodsId;
            return this;
        }

        /**
         * 订单ID
         */
        public Builder setOrderId(String orderId) {
            productDetail.orderId = orderId;
            return this;
        }

        /**
         * 意向
         */
        public Builder setIntent(String intent) {
            productDetail.intent = intent;
            return this;
        }

        /**
         *  商品/订单 卡片的样式
         *  0 ：默认样式， 1：悬浮样式
         */
        public Builder setCardShowStyle(int cardShowStyle) {
            productDetail.cardShowStyle = cardShowStyle;
            return this;
        }

        /**
         *  订单时间
         */
        public Builder setOrderTime(String orderTime) {
            productDetail.orderTime = orderTime;
            return this;
        }

        /**
         *  订单状态
         */
        public Builder setOrderStatus(String orderStatus) {
            productDetail.orderStatus = orderStatus;
            return this;
        }

        public Builder setPrice(String price) {
            productDetail.price = price;
            return this;
        }

        public Builder setOriginalPrice(String originalPrice) {
            productDetail.originalPrice = originalPrice;
            return this;
        }

        public Builder setPayMoney(String payMoney) {
            productDetail.payMoney = payMoney;
            return this;
        }

        public Builder setOrderCount(String orderCount) {
            productDetail.orderCount = orderCount;
            return this;
        }

        public Builder setProductCount(String productCount) {
            productDetail.productCount = productCount;
            return this;
        }

        public Builder setOrderSku(String orderSku) {
            productDetail.orderSku = orderSku;
            return this;
        }

        /**
         * 获取自定义商品消息对象。设置完成自定义商品消息的属性后获取自定义商品消息对象。
         *
         * @return 自定义商品消息对象
         */
        public ProductDetail build() {
            return productDetail;
        }

        /**
         * 获取自定义商品消息对象。设置完成自定义商品消息的属性后获取自定义商品消息对象。
         *
         * @return 自定义商品消息对象
         * @deprecated 请使用 {@link #build()} 代替
         */
        public ProductDetail create() {
            return build();
        }


    }
}
