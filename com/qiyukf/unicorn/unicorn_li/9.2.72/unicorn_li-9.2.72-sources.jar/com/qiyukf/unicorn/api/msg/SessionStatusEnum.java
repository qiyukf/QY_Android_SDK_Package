package com.qiyukf.unicorn.api.msg;

/**
 * 会话状态
 */
public enum SessionStatusEnum {
    /**
     * 空状态
     */
    NONE(-1),

    /**
     * 会话中
     */
    IN_SESSION(200),

    /**
     * 排队中
     */
    IN_QUEUE(203);

    private int value;

    SessionStatusEnum(int value) {
        this.value = value;
    }

    public int value() {
        return value;
    }

    public static SessionStatusEnum valueOf(int value) {
        for (SessionStatusEnum e : values()) {
            if (e.value() == value) {
                return e;
            }
        }
        return NONE;
    }
}
