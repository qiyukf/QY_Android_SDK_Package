package com.qiyukf.unicorn.api.pop;


import androidx.annotation.DrawableRes;

import java.io.Serializable;

/**
 * 会话列表入口信息
 */
public class SessionListEntrance implements Serializable {
    @DrawableRes
    private int imageResId;
    private Position position;

    private SessionListEntrance() {
    }

    @DrawableRes
    public int getImageResId() {
        return imageResId;
    }

    public Position getPosition() {
        return position;
    }

    public static class Builder {
        private SessionListEntrance sessionListEntrance;

        public Builder() {
            sessionListEntrance = new SessionListEntrance();
        }

        public Builder setImageResId(@DrawableRes int imageResId) {
            sessionListEntrance.imageResId = imageResId;
            return this;
        }

        public Builder setPosition(Position position) {
            sessionListEntrance.position = position;
            return this;
        }

        public SessionListEntrance build() {
            return sessionListEntrance;
        }
    }

    public enum Position {
        TOP_LEFT,
        TOP_RIGHT
    }
}
