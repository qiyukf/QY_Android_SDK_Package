package com.qiyukf.unicorn.api;

import com.qiyukf.nimlib.sdk.ServerAddresses;
import com.qiyukf.nimlib.sdk.StatusBarNotificationConfig;
import com.qiyukf.nimlib.sdk.mixpush.MixPushConfig;
import com.qiyukf.unicorn.api.customization.input.InputPanelOptions;
import com.qiyukf.unicorn.api.customization.page_ad.IMPageViewConfig;
import com.qiyukf.unicorn.api.customization.title_bar.TitleBarConfig;
import com.qiyukf.unicorn.api.event.SDKEvents;
import com.qiyukf.unicorn.api.msg.attachment.CustomProductParser;
import com.qiyukf.unicorn.api.pop.OnShopEventListener;
import com.qiyukf.unicorn.api.privatization.UnicornAddress;

import java.io.Serializable;

/**
 * 七鱼SDK可自定义的配置选项
 */
public class YSFOptions implements Serializable {

    public static YSFOptions DEFAULT = new YSFOptions();

    /**
     * 状态提醒设置。<br>
     * 默认为null，SDK不提供状态栏提醒功能，由客户APP自行实现
     */
    public transient StatusBarNotificationConfig statusBarNotificationConfig;

    /**
     * 聊天窗口消息项的一些点击事件响应处理。
     */
    public transient OnMessageItemClickListener onMessageItemClickListener;

    /**
     * 商家事件监听器
     */
    public transient OnShopEventListener onShopEventListener;

    /**
     * 服务直达事件监听器
     */
    public transient OnBotEventListener onBotEventListener;

    /**
     * UI自定义选项。
     */
    public transient UICustomization uiCustomization;

    /**
     * log 开关，用于控制 SDK 的 log 是否要输出到 logcat
     */
    public boolean logSwitch = true;

    /**
     * 当切换账户的时候，是否从服务端拉取消息，开启之后
     * 会从服务端拉取用户最近聊天的 20 条内容加入消息流
     */
    public boolean isPullMessageFromServer;

    /**
     * 当 isPullMessageFromServer = true 时，从服务端拉取历史消息的数量
     * 默认 20 条最大 100 条
     */
    public int pullMessageCount = 20;

    /**
     * 快捷按钮点击监听器
     */
    public transient QuickEntryListener quickEntryListener;

    /**
     * 选择咨询分类时自动弹出对话框的样式<br>
     * 0 表示不弹出<br>
     * 1 表示从中间弹出<br>
     * 2 表示从底部弹出
     */
    public int categoryDialogStyle;

    /**
     * 是否自动记录用户访问轨迹，默认开启自动记录。<br>
     * 自动记录仅支持记录 Activity 的访问轨迹，如果需要更详细的访问轨迹如 Fragment，请关闭自动记录，并使用 QiyuTracker 中的方法手动记录用户轨迹。
     */
    public boolean autoTrackUser = false;

    /**
     * 自定义会话界面输入区的UI和响应事件
     */
    public transient InputPanelOptions inputPanelOptions;

    /**
     * 自定义 titlebar 的相关内容
     */
    public transient TitleBarConfig titleBarConfig;

    /**
     * 聊天界面增加的 view 的相关配置信息
     */
    public transient IMPageViewConfig imPageViewConfig;


    /**
     * 自定义事件处理的总类
     */
    public transient SDKEvents sdkEvents;

    /**
     * 在一通会话开始的时候是否加载历史消息 默认为 false
     */
    public boolean isDefaultLoadMsg = false;

    /**
     * 是否使用 ysf 的 MessageNotifierCustomization 的配置，默认都是使用的，如果在使用融合 SDK 时可以改为 false
     */
    public boolean isUseYsfNotificationConfig = true;

    /**
     * 自定义 gif 表情加载器
     */
    public transient UnicornGifImageLoader gifImageLoader;

    /**
     * 自定义商品消息的解析器，如果没有自定义商品消息的功能不需要赋值
     */
    public transient CustomProductParser customProductParser;

    /**
     * 是否使用云信 SDK 的功能
     */
    public boolean isMixSDK = false;

    /**
     * 七鱼私有化地址配置
     */
    public transient UnicornAddress unicornAddress;

    /**
     * 云信私有化地址
     */
    public transient ServerAddresses serverAddresses;

    /**
     * 对话框内容样式模板id
     */
    public long templateId;

    /**
     * 禁止后台进程唤醒ui进程, 默认是不唤醒
     */
    public boolean disableAwake = true;

    /**
     * 七鱼云信融合情况下,云信帐号被踢,点击"重新连接"响应处理
     */
    public transient OnMixSdkReconnectClickListener onMixSdkReconnectClickListener;

    /**
     * 点击视频客服小窗口,需要回到的界面,一般为客服聊天主界面
     */
    public transient OnVideoFloatBackIntent onVideoFloatBackIntent;

    /**
     * 是否异步初始化SDK
     */
    public boolean asyncInitSDK = false;

    /**
     * 第三方推送配置
     */
    public MixPushConfig mixPushConfig;

    /**
     * 跳转地图选择位置
     */
    public transient GetMapLocationEvent getMapLocationEvent;

    /**
     * 从聊天界面位置信息跳转出去，显示地图
     */
    public transient ShowMapLocationEvent showMapLocationEvent;

    /**
     * 上报位置坐标
     */
    public transient ReportLocationEvent reportLocationEvent;

    /**
     * 从聊天界面商品信息跳转出去，显示商品Dialog
     */
    public transient ShowGoodsEvent showGoodsEvent;

    /**
     * 从聊天界面订单信息跳转出去，显示订单Dialog
     */
    public transient ShowOrderEvent showOrderEvent;

}
