package com.qiyukf.unicorn.api.customization.input;

import java.io.Serializable;

/**
 * create by andya on 2018/7/10
 * 输入栏相关的配置内容，包括 actionPanel 还有语音输入表情更多的图标
 */


public class InputPanelOptions implements Serializable {
    /**
     * 语音输入图标 id
     */
    public int voiceIconResId;
    /**
     * 表情输入图标id
     */
    public int emojiIconResId;
    /**
     * 拍照和相册功能的图标
     */
    public int photoIconResId;

    /**
     * "+"功能在输入栏的图标 id
     */
    public int moreIconResId;

    /**
     * 是否开启输入更多功能，也就是是否在输入栏是否将（拍照和相册）替换为 "+"
     */
    public boolean showActionPanel = false;

    /**
     * actionPanel 相关配置（"+" 里面可以支持的功能列表和背景颜色）
     */
    public transient ActionPanelOptions actionPanelOptions;

}
