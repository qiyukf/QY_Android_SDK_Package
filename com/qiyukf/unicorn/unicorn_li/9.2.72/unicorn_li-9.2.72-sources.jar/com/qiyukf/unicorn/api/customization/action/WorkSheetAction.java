package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;

import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.unicorn.api.helper.UnicornWorkSheetHelper;

/**
 * 工单 Action
 */
public class WorkSheetAction extends BaseAction {

    private int actionFontColor = 0;
    private long templateId;
    private UnicornWorkSheetHelper helper;

    /**
     * 构造函数
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public WorkSheetAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId   图标标题的 String
     */
    public WorkSheetAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId   图标标题的 String
     */
    public WorkSheetAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    public void setTemplateId(long templateId) {
        this.templateId = templateId;
    }

    @Override
    public void onClick() {
        if (templateId != 0) {
            getHelper().openWorkSheetDialog(templateId, getAccount(), makeRequestCode(RequestCode.WATCH_ANNEX_FOR_QUICK), makeRequestCode(RequestCode.PICK_ANNEX_FOR_QUICK), null);
        }
    }

    private UnicornWorkSheetHelper getHelper() {
        if (helper == null) {
            helper = new UnicornWorkSheetHelper(getFragment());
        }
        return helper;
    }

    public void setActionFontColor(int actionFontColor){
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        }else {
            return actionFontColor;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (helper == null) {
            return;
        }
        helper.onResultWorkSheet(makeRequestCode(requestCode), data);
    }
}
