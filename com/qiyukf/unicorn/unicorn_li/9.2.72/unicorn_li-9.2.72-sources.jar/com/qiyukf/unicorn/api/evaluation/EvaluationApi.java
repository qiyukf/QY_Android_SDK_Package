package com.qiyukf.unicorn.api.evaluation;

import android.content.Context;

import com.qiyukf.nimlib.sdk.RequestCallbackWrapper;
import com.qiyukf.unicorn.api.evaluation.entry.EvaluationOpenEntry;
import com.qiyukf.unicorn.model.EvaluatorRequestEntry;
import com.qiyukf.unicorn.session.SessionManager;

import java.util.List;

/**
 * Describe: 评价相关 Api class
 */
public class EvaluationApi {


    private OnEvaluationEventListener onEvaluationEventListener;

    /**
     * 评价事件监听类,用户可以通过调用 setOnEvaluationEventListener
     * 方法去设置实现的 OnEvaluationEventListener ，当用户设置了 OnEvaluationEventListener
     * 那么当用户触发了评价事件就会交给 App 方处理
     */
    public static abstract class OnEvaluationEventListener {
        /**
         * 评价状态改变
         *
         * @param state 0:不可评价,1:可评价,2:评价完成
         */
        public void onEvaluationStateChange(int state) {
        }


        /**
         * 邀评消息被点击，App 方可以在此方法启动自己的评 价界面
         * @param entry 评价的相关数据
         * @param context 可能为 null
         */
        public void onEvaluationMessageClick(EvaluationOpenEntry entry, Context context) {
        }
    }

    private static class SingletonHolder {
        private static final EvaluationApi sInstance = new EvaluationApi();
    }

    public static EvaluationApi getInstance() {
        return SingletonHolder.sInstance;
    }


    public OnEvaluationEventListener getOnEvaluationEventListener() {
        return onEvaluationEventListener;
    }

    public void setOnEvaluationEventListener(OnEvaluationEventListener onEvaluationEventListener) {
        this.onEvaluationEventListener = onEvaluationEventListener;
    }

    /**
     * 评价
     *
     * @param shopCode 商家ID， 在 EvaluationOpenEntry 里面有这个值，只需要回传就可以了
     * @param sessionId 会话 ID ，在 EvaluationOpenEntry 里面有这个值，只需要回传就可以了
     * @param score    评分
     * @param remark   评价内容
     * @param tagList  标签
     * @param name     评价结果的文案，例如非常满意、满意、不满意等
     * @param callback 回调
     */
    public void evaluate(String shopCode, long sessionId, int score, String remark, List<String> tagList, String name,int resolveOption, RequestCallbackWrapper<String> callback) {
        EvaluatorRequestEntry evaluatorRequestEntry = new EvaluatorRequestEntry();
        evaluatorRequestEntry.exchange = shopCode;
        evaluatorRequestEntry.sessionId = sessionId;
        evaluatorRequestEntry.score = score;
        evaluatorRequestEntry.remark = remark;
        evaluatorRequestEntry.tagList = tagList;
        evaluatorRequestEntry.name = name;
        evaluatorRequestEntry.resolveOption = resolveOption;
        SessionManager.getInstance().getEvaluationManager().doEvaluate(evaluatorRequestEntry, callback);
    }

}
