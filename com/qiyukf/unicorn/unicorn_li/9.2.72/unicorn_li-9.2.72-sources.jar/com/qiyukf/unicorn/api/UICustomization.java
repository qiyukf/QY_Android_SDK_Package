package com.qiyukf.unicorn.api;

import java.io.Serializable;

/**
 * 会话窗口界面定制化设置项。需要与 SDK 提供的界面不一样的地方，就修改对应的项，否则不赋值即可，界面会保留默认表现。
 * <p>
 * 修改各设置项后，都需要等到下次进入会话界面才会看到相应的更改。
 */
public class UICustomization implements Serializable {
    /**
     * 聊天背景。优先使用uri，如果没有提供uri，使用color。如果没有color，使用默认。<br>
     * uri支持的格式由使用的ImageLoader决定
     */
    public String msgBackgroundUri;

    /**
     * 聊天背景的color。优先使用uri，如果没有提供uri，使用color。如果没有color，使用默认
     */
    public int msgBackgroundColor;

    /**
     * 客服聊天窗口，消息列表的dividerHeight
     */
    public int msgListViewDividerHeight;

    /**
     * 是否隐藏左边的客服头像。默认显示头像
     */
    public boolean hideLeftAvatar;

    /**
     * 头像优先级是否管理端优先。
     */
    public boolean priorityWebAvatar = false;

    /**
     * 是否隐藏右边的访客头像。默认隐藏头像
     */
    public boolean hideRightAvatar;

    /**
     * 是否在标题栏上面展示头像，默认是不展示
     */
    public boolean isShowTitleAvatar = false;


    /**
     * 头像形状风格，0为圆形头像，1为方形头像
     */
    public int avatarShape;

    /**
     * 客服头像的uri。<br>
     * uri支持的格式由使用的ImageLoader决定
     */
    public String leftAvatar;

    /**
     * 咨询的访客用户头像的uri。<br>
     * uri支持的格式由使用的ImageLoader决定
     */
    public String rightAvatar;

    /**
     * 提示类消息的字体颜色（包括分配客服消息，消息时间标签等）
     */
    public int tipsTextColor;
    /**
     * 提示类消息的字体大小（包括分配客服消息，消息时间标签等）
     */
    public float tipsTextSize;

    /**
     * 客服聊天窗口，左边消息项背景 drawable resId.<br>
     * 该drawable最好是一个State List Drawable(selector)<br>
     * 设置后，可影响文本和语音消息的消息项背景
     */
    public int msgItemBackgroundLeft;

    /**
     * 客服聊天窗口，右边消息项背景 drawable resId.<br>
     * 该drawable最好是一个State List Drawable(selector)<br>
     * 设置后，可影响文本和语音消息的消息项背景
     */
    public int msgItemBackgroundRight;


    /**
     * 机器人聊天窗口，左边消息项背景 drawable resId.<br>
     * 该drawable最好是一个State List Drawable(selector)<br>
     * 设置后，可影响文本和语音消息的消息项背景
     */
    public int msgRobotItemBackgroundLeft;

    /**
     * 机器人聊天窗口，右边消息项背景 drawable resId.<br>
     * 该drawable最好是一个State List Drawable(selector)<br>
     * 设置后，可影响文本和语音消息的消息项背景
     */
    public int msgRobotItemBackgroundRight;


    /**
     * 左侧语音消息播放时候的动画资源ID，该资源为一个animation-list。没有播放时会显示最后一帧
     */
    public int audioMsgAnimationLeft;

    /**
     * 右侧语音消息播放时候的动画资源ID，该资源为一个animation-list。没有播放时会显示最后一帧
     */
    public int audioMsgAnimationRight;

    /**
     * 客服聊天窗口, 左边文本消息的字体颜色
     * (包括机器人回复的消息的颜色)
     */
    public int textMsgColorLeft;

    /**
     * 客服聊天窗口，左边文本消息中超链接的字体颜色
     * (包括机器人回复消息中的链接)
     */
    public int hyperLinkColorLeft;

    /**
     * 客服聊天窗口, 右边文本消息的字体颜色
     */
    public int textMsgColorRight;

    /**
     * 客服聊天窗口，右边文本消息中超链接的字体颜色
     */
    public int hyperLinkColorRight;

    /**
     * 文本消息字体大小，单位为sp
     * (包括机器人会话的消息的字体大小)
     */
    public float textMsgSize;

    /**
     * 底部消息输入框的字体颜色
     */
    public int inputTextColor;

    /**
     * 底部消息输入框的字体大小
     */
    public float inputTextSize;

    /**
     * 顶部提示栏背景色
     */
    public int topTipBarBackgroundColor;

    /**
     * 顶部提示栏文字颜色
     */
    public int topTipBarTextColor;

    /**
     * 顶部提示栏文字大小, 单位为sp
     */
    public float topTipBarTextSize;

    /**
     * 标题栏背景资源drawable resId<br>
     * 优先使用drawable，如果没有提供drawable，使用color，如果没有color，使用默认。
     */
    public int titleBackgroundResId;

    /**
     * Activity 接入方式返回键的图片 drawable resId
     */
    public int titleBackBtnIconResId;

    /**
     * 标题栏背景颜色<br>
     * 优先使用drawable，如果没有提供drawable，使用color，如果没有color，使用默认。
     */
    public int titleBackgroundColor;

    /**
     * 设置状态栏颜色
     */
    public int statusBarColor;

    /**
     * 标题栏风格，0为浅色系，对应的标题和按钮为灰色，1为深色系，对应的标题和按钮为白色
     */
    public int titleBarStyle;

    /**
     * 标题居中，如果为 true ，居中，否则（默认）居左
     */
    public boolean titleCenter;

    /**
     * 是否隐藏客服名称
     */
    public boolean hideLeftName;

    /**
     * 发送，选择，预览等按钮的颜色，是一个ColorStateList，样例可参考 SDK 的 color.ysf_button_color_state_list
     */
    public int buttonBackgroundColorList;

    /**
     * 发送，选择等按钮的文字颜色
     */
    public int buttonTextColor;

    /**
     * 是否关闭与客服聊天发送语音功能
     */
    public boolean hideAudio;

    /**
     * 是否关闭与机器人聊天发送语音功能，默认开启语音
     */
    public boolean hideAudioWithRobot;

    /**
     * 是否关闭发送表情功能
     */
    public boolean hideEmoji;

    /**
     * 横竖屏配置项,0为竖屏，1为横屏，2为重力感应控制横竖屏，默认为竖屏
     */
    public int screenOrientation;

    /**
     * 是否设置全屏，只有在横屏下才生效
     */
    public boolean isFullScreen = false;

    /**
     * 是否进入咨询时隐藏键盘
     */
    public boolean hideKeyboardOnEnterConsult = true;

    /**
     * 是否进入咨询时键盘不可用
     */
    public boolean disableKeyboardOnEnterConsult;

    /**
     * 机器人消息过长是否折叠
     */
    public boolean isRobotMessageFold;

    /**
     * 机器人消息中的按钮的背景
     * drawable resId  推荐 resid 为 selector(效果会更好)
     */
    public int robotBtnBack;

    /**
     * 机器人消息中的按钮的文字颜色
     * 32 位颜色值
     */
    public int robotBtnTextColor;

    /**
     * 输入框上方按钮的背景
     * drawable resId 推荐 selector (效果会更好)
     */
    public int inputUpBtnBack;

    /**
     * 输入框上方按钮的文字颜色
     * 32 位颜色值
     */
    public int inputUpBtnTextColor;


    /**
     * 加载更多 loading 的帧动画 drawable
     * drawable resId
     */
    public int loadingAnimationDrawable;

    /**
     * 自定义客服界面 editText 的 hint
     */
    public String editTextHint;

    /**
     * 机器人阶段是否展示发送图片控件，默认不展示
     */
    public boolean isRobotSendImage = false;

}
