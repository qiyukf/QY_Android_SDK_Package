package com.qiyukf.unicorn.api;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;

import java.io.Serializable;

/**
 * 图片异步加载回调
 */
public interface ImageLoaderListener extends Serializable {
    void onLoadComplete(@NonNull Bitmap bitmap);

    void onLoadFailed(Throwable throwable);
}
