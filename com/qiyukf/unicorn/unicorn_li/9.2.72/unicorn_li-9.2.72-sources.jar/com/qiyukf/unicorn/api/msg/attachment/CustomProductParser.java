package com.qiyukf.unicorn.api.msg.attachment;

import java.io.Serializable;

/**
 * Describe: 自定义商品消息的解析器，当商品消息需要自定义的时候(也就是后台设置了 isOpenCustomProduct = true 的时候)
 * 会回调 parseCustomProduct 这个方法去解析消息体
 */
public interface CustomProductParser extends Serializable {

    /**
     * 把 attach 中的内容解析成 UnicornAttachmentBase 的方法
     *
     * @param attach String 类型的 Json 可以通过 new JSONObject(attach) 转换成 Json 对象
     * @return 解析之后的 UnicornAttachmentBase 对象
     */
    UnicornAttachmentBase parseCustomProduct(String attach);

}
