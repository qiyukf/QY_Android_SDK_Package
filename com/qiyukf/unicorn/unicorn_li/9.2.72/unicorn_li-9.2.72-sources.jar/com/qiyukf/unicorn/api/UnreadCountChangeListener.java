package com.qiyukf.unicorn.api;

/**
 * 消息未读数有变更时的通知
 */
public interface UnreadCountChangeListener {
    void onUnreadCountChange(int count);
}
