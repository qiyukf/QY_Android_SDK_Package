package com.qiyukf.unicorn.api.customization.action;

import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.api.helper.UnicornWorkSheetHelper;
import com.qiyukf.unicorn.ui.activity.UserWorkSheetListActivity;
import com.qiyukf.unicorn.util.ToastUtil;

import java.util.List;

/**
 * Created by zhanyage on 2020/6/9
 * Describe: 查询访客工单列表 Action
 */
public class InquireWorkSheetAction extends BaseAction {

    private List<Long> templateIds;

    private boolean isOpenUrge;

    public InquireWorkSheetAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    public InquireWorkSheetAction(String imageUrl, String title) {
        super(imageUrl, title);
    }

    public InquireWorkSheetAction(int iconResId, String title) {
        super(iconResId, title);
    }

    public void setTemplateIds(List<Long> templateIds) {
        this.templateIds = templateIds;
    }

    public void setOpenUrge(boolean openUrge) {
        isOpenUrge = openUrge;
    }

    @Override
    public void onClick() {
        if (templateIds == null ) {
            ToastUtil.showToast(R.string.ysf_work_sheet_tmp_id_empty);
            return;
        }
        UnicornWorkSheetHelper.openUserWorkSheetActivity(getActivity(), templateIds, isOpenUrge, getAccount());
    }
}
