package com.qiyukf.unicorn.api.event;

/**
 * 请求客服回调，用于判断客服是否请求成功。
 */
public interface RequestStaffCallback {

    /**
     * 请求客服成功回调
     */
    void onSuccess();

    /**
     * 请求客服失败回调
     *
     * @param errorCode 201：没有客服
     *                  202：请求失败
     *                  203：排队中
     *                  204：长连接失效
     *                  205：没有客服在线，留言关闭
     */
    void onFailed(int errorCode);

}
