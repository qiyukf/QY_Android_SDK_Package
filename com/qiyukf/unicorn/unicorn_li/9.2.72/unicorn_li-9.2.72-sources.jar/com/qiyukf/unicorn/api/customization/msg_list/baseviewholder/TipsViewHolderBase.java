package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;


import android.content.Context;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

import com.qiyukf.nimlib.sdk.msg.attachment.MsgAttachment;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.uikit.session.emoji.MoonUtil;
import com.qiyukf.unicorn.protocol.attach.notification.AssignStaffAttachment;
import com.qiyukf.unicorn.protocol.attach.notification.SessionCloseAttachment;
import com.qiyukf.unicorn.protocol.attach.notification.SessionTimeoutAttachment;


/**
 * 如果想实现系统通知消息自定义，请实现该抽象类的方法，然后再通过
 * MsgCustomizationRegistry.registerMessageViewHolder 去注册
 * 该 viewHolder ，这样就能达成系统通知消息自定义的目的
 * 通知包括（连接客服成功、会话超时、会话关闭等）
 * 附：该类的基类中有大量方法，请自行查看
 */
public abstract class TipsViewHolderBase extends UnicornMessageViewHolder{

    /**
     * 该方法需要返回一个显示系统消息的 textview 因为许多系统通知是需要点击的，所以 APP 方需要返回一个
     * TextView，然后 sdk 需要对 textview 的点击事件进行处理
     * 可以在这个里面去设置你想要定制的 UI
     * @return
     */
    public abstract TextView getMainTextView();

    @Override
    public final void bindContentView(IMMessage message, Context context) {
        handleTextNotification(getDisplayText());
    }

    private String getDisplayText() {
        MsgAttachment attachment = message.getAttachment();
        if (attachment instanceof AssignStaffAttachment) {
            //getDisplayText 方法可能返回 null，如果返回 null 就不现实该条消息
            return ((AssignStaffAttachment) attachment).getDisplayText().toString();
        } else if (attachment instanceof SessionTimeoutAttachment) {
            return ((SessionTimeoutAttachment) attachment).getMessage();
        } else if (attachment instanceof SessionCloseAttachment) {
            return ((SessionCloseAttachment) attachment).getMessage();
        } else {
            return message.getContent();
        }
    }

    private void handleTextNotification(String text) {
        MoonUtil.matchEmoticonAndATags(context, getMainTextView(), text, message.getSessionId());
        getMainTextView().setMovementMethod(LinkMovementMethod.getInstance());
    }

    /**
     * 该方法为通知是否展示在会话列表中心，默认实现为 true
     * @return
     */
    @Override
    protected boolean isMiddleItem() {
        return true;
    }

    /**
     * 该方法为通知是否展示头像，默认实现为 false
     * @return
     */
    @Override
    protected boolean showAvatar() {
        return false;
    }
}
