package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 服务直达事件监听器
 */
public abstract class OnBotEventListener {

    /**
     * 服务直达 url 点击事件
     *
     * @param context 上下文
     * @param url     url
     * @return true，如果已经处理该事件
     */
    public boolean onUrlClick(Context context, String url) {
        return false;
    }
}
