package com.qiyukf.unicorn.api.pop;

import android.text.TextUtils;

import com.qiyukf.nimlib.SDKCache;
import com.qiyukf.nimlib.sdk.msg.attachment.MsgAttachment;
import com.qiyukf.nimlib.sdk.msg.constant.MsgStatusEnum;
import com.qiyukf.nimlib.sdk.msg.constant.MsgTypeEnum;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.session.MsgAttachmentCreator;
import com.qiyukf.nimlib.util.JSONHelper;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.api.msg.SessionStatusEnum;

import static com.qiyukf.unicorn.protocol.attach.constant.YsfCmd.CARD_MESSAGE;
import static com.qiyukf.unicorn.protocol.attach.constant.YsfCmd.CARD_MESSAGE_FLOAT_LOCAL_CMD;
import static com.qiyukf.unicorn.protocol.attach.constant.YsfCmd.INVITE_INPUT_WORK_SHEET_SUBMIT_NOTIFY;
import static com.qiyukf.unicorn.protocol.attach.constant.YsfCmd.LEAVE_MESSAGE_LOCAL_CMD;
import static com.qiyukf.unicorn.protocol.attach.constant.YsfCmd.PRODUCT;

/**
 * Created by zhanyage on 2020-02-11
 * Describe: 会话 item impl
 */
public class SessionImpl implements Session {

    private String contactId;
    private String fromAccount;
    private String recentMessageId;
    private int unreadCount;
    private MsgStatusEnum msgStatus;
    private SessionTypeEnum sessionType;
    private String content;
    private long time;
    private long tag;
    private String attachStr;
    private int typeOfMsg;
    private MsgAttachment attachment;
    private SessionStatusEnum sessionStatus;
    private MsgTypeEnum msgType;
    private int cmdId = -1;

    /**
     * 获取最近联系人的ID（好友账号，群ID等）
     */
    @Override
    public String getContactId() {
        return contactId;
    }

    /**
     * 设置最近联系人ID
     */
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }


    /**
     * 设置发送方账号
     */
    public void setFromAccount(String fromAccount) {
        this.fromAccount = fromAccount;
    }


    /**
     * 设置最近一条消息的消息ID
     */
    public void setRecentMessageId(String recentMessageId) {
        this.recentMessageId = recentMessageId;
    }

    /**
     * 获取消息状态
     */
    @Override
    public MsgStatusEnum getMsgStatus() {
        return msgStatus;
    }

    public void setMsgStatus(MsgStatusEnum msgStatus) {
        this.msgStatus = msgStatus;
    }

    /**
     * 设置会话类型
     */
    public void setSessionType(SessionTypeEnum sessionType) {
        this.sessionType = sessionType;
    }

    /**
     * 获取未读消息条数
     */
    @Override
    public int getUnreadCount() {
        return unreadCount;
    }

    /**
     * 设置未读消息条数
     */
    public void setUnreadCount(int unreadCount) {
        this.unreadCount = unreadCount;
    }

    /**
     * 获取最近一条消息的缩略内容
     */
    @Override
    public String getContent() {
        String contentType = content;
        if (msgType.getValue() == 100) {
            if (cmdId == LEAVE_MESSAGE_LOCAL_CMD) {
                contentType = SDKCache.getContext().getString(R.string.ysf_msg_notify_leave);
            } else if (cmdId == PRODUCT) {
                contentType = SDKCache.getContext().getString(R.string.ysf_msg_notify_card);
            } else if (cmdId == INVITE_INPUT_WORK_SHEET_SUBMIT_NOTIFY) {
                contentType = SDKCache.getContext().getString(R.string.ysf_msg_notify_label);
            } else if (cmdId == CARD_MESSAGE || cmdId == CARD_MESSAGE_FLOAT_LOCAL_CMD) {
                contentType = SDKCache.getContext().getString(R.string.ysf_msg_notify_card);
            }
        }
        return contentType;
    }

    /**
     * 设置最近一条消息的缩略内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取最近一条消息的时间，单位为ms
     */
    @Override
    public long getTime() {
        return time;
    }

    /**
     * 设置最近一条消息的时间
     */
    public void setTime(long time) {
        this.time = time;
    }

    public void setMsgType(MsgTypeEnum msgType) {
        this.msgType = msgType;
    }


    public void setAttachment(MsgAttachment attachment) {
        this.attachment = attachment;
        if (attachment != null) {
            attachStr = attachment.toJson(false);
        }
    }

    public String getAttachStr() {
        return attachStr;
    }

    public void setAttachStr(String attachStr) {
        this.attachStr = attachStr;
        if (!TextUtils.isEmpty(attachStr)) {
            attachment = MsgAttachmentCreator.getInstance().create(typeOfMsg, attachStr);
        }
        try {
            this.cmdId = JSONHelper.parse(attachStr).getInt("cmd");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getTypeOfMsg() {
        return typeOfMsg;
    }

    public void setTypeOfMsg(int typeOfMsg) {
        this.typeOfMsg = typeOfMsg;
    }

    public void setSessionStatus(SessionStatusEnum sessionStatus) {
        this.sessionStatus = sessionStatus;
    }
}
