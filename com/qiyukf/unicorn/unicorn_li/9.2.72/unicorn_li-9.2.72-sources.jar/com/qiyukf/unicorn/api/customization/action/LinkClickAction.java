package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.GetMapLocationEvent;
import com.qiyukf.unicorn.api.OnMessageItemClickListener;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.constant.ActionConstant;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;
import com.qiyukf.unicorn.util.ToastUtil;

import java.util.Arrays;
import java.util.List;


/**
 * Created by andya on 2019-07-30
 * Describe: 链接外跳的
 */
public class LinkClickAction extends BaseAction {

    private String url;
    int actionFontColor = 0;

    /**
     * 构造函数
     *
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public LinkClickAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId 图标标题的 String
     */
    public LinkClickAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId 图标标题的 String
     */
    public LinkClickAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public void onClick() {
        // customer类型
        if (TextUtils.isEmpty(url)) {
            return;
        }
        if (ActionConstant.ACTION_SELECT_LOCATION.equals(url)) {
            if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                    && !PermissionReq.hasPermissions(getFragment().getContext(), PermissionsConstant.goMap)) {
                UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
                if (unicornEventBase != null) {
                    List<String> permissionList = Arrays.asList(PermissionsConstant.goMap);
                    RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                    eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_MAP_LOCATION);
                    eventEntry.setPermissionList(permissionList);

                    unicornEventBase.onEvent(eventEntry, getFragment().getContext(), new EventCallback() {
                        @Override
                        public void onProcessEventSuccess(Object o) {
                            checkLocationPermission(unicornEventBase, eventEntry);
                        }

                        @Override
                        public void onPorcessEventError() {
                            checkLocationPermission(unicornEventBase, eventEntry);
                        }

                        @Override
                        public void onNotPorcessEvent() {
                            checkLocationPermission(unicornEventBase, eventEntry);
                        }

                        @Override
                        public void onInterceptEvent() {
                            ToastUtil.showLongToast(R.string.ysf_no_permission_location);
                        }
                    });
                } else {
                    checkLocationPermission(null, null);
                }
            } else {
                checkLocationPermission(null, null);
            }
            return;
        }
        OnMessageItemClickListener listener = UnicornImpl.getOptions().onMessageItemClickListener;
        if (listener != null) {
            listener.onURLClicked(getActivity(), url);
        } else {
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            getActivity().startActivity(intent);
        }
    }


    public void setActionFontColor(int actionFontColor) {
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        } else {
            return actionFontColor;
        }
    }

    private void checkLocationPermission(UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(getFragment())
                .permissions(PermissionsConstant.goMap)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        GetMapLocationEvent locationEvent = UnicornImpl.getOptions().getMapLocationEvent;
                        if (locationEvent != null) {
                            locationEvent.onEvent(getActivity(), RequestCode.SELECT_MAP_LOCATION);
                        }
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(getFragment().getContext(), eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_location);
                        }
                    }
                })
                .request();
    }
}
