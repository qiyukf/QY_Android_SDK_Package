package com.qiyukf.unicorn.api.msg;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;

public interface OnPushMessageListener {
    void onReceive(IMMessage message, PushMessageExtension extension);
}
