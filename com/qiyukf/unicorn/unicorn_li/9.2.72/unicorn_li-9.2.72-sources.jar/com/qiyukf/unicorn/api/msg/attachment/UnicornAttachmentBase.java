package com.qiyukf.unicorn.api.msg.attachment;


import com.qiyukf.nimlib.ysf.attach.attachment.YsfAttachment;

/**
 * Describe: 自定义本地消息和自定义商品消息的基类，当我们需要自定义 Attachment 的时候，需要继承该类
 */
public class UnicornAttachmentBase extends YsfAttachment {

    /**
     * 该字段为 String 的 json 字段，该字段永远不能为 null，因为在存储数据库的时候，会把
     * 该字段存储起来，以备历史聊天消息用，所以当我们创建 UnicornAttachmentBase 的时候，需要把
     * 该字段填充起来(目前填充方法是通过 parseCustomProduct 方法中的参数赋值即可)
     */
    protected String attach;

    public UnicornAttachmentBase(String attach) {
        this.attach = attach;
    }

    @Override
    public String toJson(boolean send) {
        return attach;
    }

    @Override
    public String getContent() {
        return null;
    }
}
