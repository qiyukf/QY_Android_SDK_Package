package com.qiyukf.unicorn.api.event;

import android.app.Activity;
import android.text.TextUtils;

import com.qiyukf.nimlib.sdk.NIMClient;
import com.qiyukf.nimlib.sdk.RequestCallbackWrapper;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.nimlib.sdk.ysf.YsfService;
import com.qiyukf.nimlib.ysf.YsfMessageBuilder;
import com.qiyukf.uikit.session.helper.InquiryFormHelper;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.evaluation.EvaluationApi;
import com.qiyukf.unicorn.api.evaluation.entry.EvaluationOpenEntry;
import com.qiyukf.unicorn.api.event.eventcallback.TransferCloseResultCallback;
import com.qiyukf.unicorn.api.event.eventcallback.TransferRequestCallback;
import com.qiyukf.unicorn.cache.UnicornPreferences;
import com.qiyukf.unicorn.constant.RequestConstant;
import com.qiyukf.unicorn.model.ConsultCategory;
import com.qiyukf.unicorn.model.EvaluatorRequestEntry;
import com.qiyukf.unicorn.model.QueueStatus;
import com.qiyukf.unicorn.model.SessionRequestStaffStream;
import com.qiyukf.unicorn.protocol.attach.model.EvaluationConfig;
import com.qiyukf.unicorn.protocol.attach.request.CloseSessionAttachment;
import com.qiyukf.unicorn.protocol.attach.request.RequestEvaluatorAgainCancelAttachment;
import com.qiyukf.unicorn.session.EvaluationManager;
import com.qiyukf.unicorn.session.SessionHelper;
import com.qiyukf.unicorn.session.SessionManager;
import com.qiyukf.unicorn.ui.evaluate.EvaluationDialog;
import com.qiyukf.unicorn.ui.evaluate.robot.EvaluatorConstants;
import com.qiyukf.unicorn.util.KeyboardUtils;
import com.qiyukf.unicorn.util.ToastUtil;

import java.util.List;

import static com.qiyukf.unicorn.protocol.attach.notification.EvaluationCallbackAttachment.EVALUATION_LIMIT;

/**
 * 为事件提供服务的类（事件可以是请求客服事件，评价事件等一些 sdk 中的动作）
 * 该类提供了连接客服的方法
 * 之后还会提供和事件相关的方法
 */
public class EventService {

    /**
     * 请求客服的方法通过此方法可以请求客服
     *
     * @param humanOnly 是否只请求人工客服，true 则只请求人工客服 false 则为人工客服和机器人都可以
     *                  return 请求是否成功，有可能你当前的状态不需要请求客服，也有可能你已经在人工的状态了，那么也会返回 true
     */
    public static void requestStaff(boolean humanOnly, RequestStaffCallback callback) {
        requestStaff(SessionHelper.getDefaultSessionId(), humanOnly, 0L, 0L, humanOnly ? RequestConstant.SCENES_RIGHT_BUTTON : RequestConstant.SCENES_NORMAL, callback);
    }

    /**
     * 请求客服的方法，可以通过该方法去请求客服
     *
     * @param exchange           平台电商版本会用到 ，可以理解为商店的 id，如果没有则传 null
     * @param humanOnly          是否只请求人工客服，true 则只请求人工客服 false 则为人工客服和机器人都可以
     * @param requestStaffScenes 请求客服的当前场景，因为现在请求客服事件可以进行拦截，这个值是与 RequestStaffEntry 中 scenes 中相对应的
     */
    public static void requestStaff(String exchange, boolean humanOnly, long staffId, long groupId, int requestStaffScenes, RequestStaffCallback callback) {
        ConsultCategory category = null;
        if (staffId != 0L || groupId != 0L) {
            category = new ConsultCategory();
            category.type = staffId == 0L ? 1 : 2;
            category.id = staffId != 0L ? staffId : groupId;
            category.setGroupId(groupId);
            category.setStaffId(staffId);
        }
        SessionRequestStaffStream sessionRequestStaffStream = new SessionRequestStaffStream(exchange);
        sessionRequestStaffStream.setHumanOnly(humanOnly);
        sessionRequestStaffStream.setCategory(category);
        sessionRequestStaffStream.setRequestStaffScenes(requestStaffScenes);
        sessionRequestStaffStream.setTransferRgType(RequestConstant.TRANSFER_TYPE_USE_INTERFACE);
        SessionManager.getInstance().setRequestStaffCallback(callback);
        SessionManager.getInstance().requestStaff(sessionRequestStaffStream);
    }

    /**
     * 请求客服的方法，可以通过该方法去请求客服,增加视频客服开关
     *
     * @param exchange           平台电商版本会用到 ，可以理解为商店的 id，如果没有则传 null
     * @param humanOnly          是否只请求人工客服，true 则只请求人工客服 false 则为人工客服和机器人都可以
     * @param isEnableVideo      是否开启视频客服
     * @param requestStaffScenes 请求客服的当前场景，因为现在请求客服事件可以进行拦截，这个值是与 RequestStaffEntry 中 scenes 中相对应的
     */
    public static void requestStaff(String exchange, boolean humanOnly, long staffId, long groupId, int requestStaffScenes, boolean isEnableVideo, RequestStaffCallback callback) {
        ConsultCategory category = null;
        if (staffId != 0L || groupId != 0L) {
            category = new ConsultCategory();
            category.type = staffId == 0L ? 1 : 2;
            category.id = staffId != 0L ? staffId : groupId;
            category.setGroupId(groupId);
            category.setStaffId(staffId);
        }
        SessionRequestStaffStream sessionRequestStaffStream = new SessionRequestStaffStream(exchange);
        sessionRequestStaffStream.setHumanOnly(humanOnly);
        sessionRequestStaffStream.setCategory(category);
        sessionRequestStaffStream.setRequestStaffScenes(requestStaffScenes);
        sessionRequestStaffStream.setTransferRgType(RequestConstant.TRANSFER_TYPE_USE_INTERFACE);
        sessionRequestStaffStream.setEnableVideo(isEnableVideo);
        SessionManager.getInstance().setRequestStaffCallback(callback);
        SessionManager.getInstance().requestStaff(sessionRequestStaffStream);
    }


    /**
     * 请求客服的方法通过此方法可以请求客服
     *
     * @param humanOnly 是否只请求人工客服，true 则只请求人工客服 false 则为人工客服和机器人都可以
     *                  return 请求是否成功，有可能你当前的状态不需要请求客服，也有可能你已经在人工的状态了，那么也会返回 true
     * @deprecated 使用 {@link #requestStaff(boolean, RequestStaffCallback)} 代替
     */
    @Deprecated
    public static boolean requestStaff(boolean humanOnly) {
        return requestStaff(SessionHelper.getDefaultSessionId(), humanOnly, 0L, 0L, humanOnly ? RequestConstant.SCENES_RIGHT_BUTTON : RequestConstant.SCENES_NORMAL);
    }

    /**
     * 请求客服的方法，可以通过该方法去请求客服
     *
     * @param exchange           平台电商版本会用到 ，可以理解为商店的 id，如果没有则传 null
     * @param humanOnly          是否只请求人工客服，true 则只请求人工客服 false 则为人工客服和机器人都可以
     * @param requestStaffScenes 请求客服的当前场景，因为现在请求客服事件可以进行拦截，这个值是与 RequestStaffEntry 中 scenes 中相对应的
     * @return false 不需要请求客服，某些场景是不需要（不能）请求客服的
     * @deprecated 使用 {@link #requestStaff(String, boolean, long, long, int, RequestStaffCallback)} 代替
     */
    @Deprecated
    public static boolean requestStaff(String exchange, boolean humanOnly, long staffId, long groupId, int requestStaffScenes) {
        ConsultCategory category = null;
        if (staffId != 0L || groupId != 0L) {
            category = new ConsultCategory();
            category.type = staffId == 0L ? 1 : 2;
            category.id = staffId != 0L ? staffId : groupId;
            category.setGroupId(groupId);
            category.setStaffId(staffId);
        }
        SessionRequestStaffStream sessionRequestStaffStream = new SessionRequestStaffStream(exchange);
        sessionRequestStaffStream.setHumanOnly(humanOnly);
        sessionRequestStaffStream.setCategory(category);
        sessionRequestStaffStream.setRequestStaffScenes(requestStaffScenes);
        sessionRequestStaffStream.setTransferRgType(RequestConstant.TRANSFER_TYPE_USE_INTERFACE);
        return SessionManager.getInstance().requestStaff(sessionRequestStaffStream);
    }

    /**
     * 转接客服的接口，在必要的时候可以通过此方法进行客服的转接
     * 方法内部实现是，现结束当前客服的会话，然后在重新连接一下客服
     *
     * @param exchange                    如果没有可以传 null 可以通过 UnicornBuilder.getSessionId 获取
     * @param staffId                     想要转接的客服 id
     * @param groupId                     想要转接的分组 id    如果同时设置 staffId 和 groupId 那么以 staffId 为主
     * @param closeSessionMsg             关闭客服的提示语
     * @param isHuman                     转接客服是否只请求人工
     * @param transferCloseResultCallback 转接客服中的关闭客服事件的回调
     * @param transferRequestCallback     转接客服中的请求客服事件的回调
     */
    public static void transferStaff(String exchange, long staffId, long groupId, String closeSessionMsg, boolean isHuman, TransferCloseResultCallback transferCloseResultCallback, TransferRequestCallback transferRequestCallback) {
        if (TextUtils.isEmpty(exchange)) {
            exchange = SessionHelper.getDefaultSessionId();
        }
        SessionManager.getInstance().transferStaff(exchange, staffId, groupId, closeSessionMsg, isHuman,
                transferCloseResultCallback, transferRequestCallback);
    }

    /**
     * 关闭会话的方法，可通过该方法结束 id 为 sessionId 的会话
     *
     * @param exchange        可以通过 UnicornMessageBuilder.getSessionId 获取该值
     * @param closeSessionMsg 关闭会话在消息流中的提示文案
     */
    public static boolean closeSession(final String exchange, String closeSessionMsg) {
        if (SessionManager.getInstance().getSessionId(exchange) == 0L) {
            return false;
        }
        final CloseSessionAttachment attachment = new CloseSessionAttachment();
        attachment.setSessionId(SessionManager.getInstance().getSessionId(exchange));
        attachment.setMessage(closeSessionMsg);
        if (TextUtils.equals(InquiryFormHelper.INQUIRY_FORM_CLOSE, closeSessionMsg)) {
            attachment.setType(1);
            attachment.setMessage("");
        }
        SessionHelper.sendCustomNotification(attachment, exchange).setCallback(new RequestCallbackWrapper<Void>() {
            @Override
            public void onResult(int code, Void result, Throwable exception) {
                if (code == 200) {
                    IMMessage message = YsfMessageBuilder.createCustomReceivedMessage(SessionHelper.getDefaultSessionId(), SessionTypeEnum.Ysf, attachment);
                    NIMClient.getService(YsfService.class).saveMessageToLocal(message, true);
                } else {
                    ToastUtil.showToast(R.string.ysf_close_session_fail);
                }
            }
        });

        return true;
    }

    /**
     * 退出排队的方法
     *
     * @param exchange 可以通过 UnicornMessageBuilder.getSessionId 获取该值
     * @return 退出排队是否成功
     */
    public static boolean quitQueue(final String exchange) {
        QueueStatus queueStatus = SessionManager.getInstance().getQueueStatus(exchange);
        if (queueStatus == null) {
            return false;
        }

        long sessionId = queueStatus.sessionId;
        final CloseSessionAttachment attachment = new CloseSessionAttachment();
        attachment.setSessionId(sessionId);
        SessionHelper.sendCustomNotification(attachment, exchange).setCallback(new RequestCallbackWrapper<Void>() {
            @Override
            public void onResult(int code, Void result, Throwable exception) {
                if (code == 200) {
                    // 清除排队信息
                    SessionManager.getInstance().onQueueEnd(exchange, true);
                    SessionManager.getInstance().clearPreviousRobotSessionId(exchange);
                    IMMessage message = YsfMessageBuilder.createCustomReceivedMessage(exchange, SessionTypeEnum.Ysf, attachment);
                    NIMClient.getService(YsfService.class).saveMessageToLocal(message, true);
                } else {
                    ToastUtil.showToast(R.string.ysf_msg_quit_queue_failed);
                }
            }
        });
        return true;
    }

    /**
     * 打开评价界面，如果自定义了评价界面会跳转自定义的评价界面，如果没有自定义，则进行七鱼评价界面的流程
     *
     * @param activity
     * @param exchange
     * @param callbackWrapper
     */
    public static void openEvaluation(final Activity activity, final String exchange, final RequestCallbackWrapper callbackWrapper) {
        //这个地方需要判断是否已经评价过了

        EvaluationConfig config = SessionManager.getInstance().getEvaluationManager().getEvaluationConfig(exchange);

        final long expiredTime = UnicornPreferences.getMultiEvaluationTime(String.valueOf(EvaluationManager.getLastSessionId(exchange)));
        //当获取到的 config 为 null 或者已经超时的时候直接提示用户
        if ((config == null || System.currentTimeMillis() > expiredTime + config.getEvaluationTimeout() * 60 * 1000) && expiredTime != 0) {
            ToastUtil.showToast(R.string.ysf_evaluation_time_out);
            return;
        }


        if (EvaluatorConstants.STATE_COMPLETE == EvaluationManager.getLastSessionEvaluateState(exchange)) {
            ToastUtil.showToast(R.string.ysf_already_evaluation);
            return;
        }

        if (EvaluationApi.getInstance().getOnEvaluationEventListener() != null) {
            EvaluationOpenEntry evaluationOpenEntry = new EvaluationOpenEntry();
            EvaluationConfig evaluationConfig = SessionManager.getInstance().getEvaluationManager().getEvaluationConfig(exchange);
            evaluationOpenEntry.setEvaluationEntryList(evaluationConfig.getEvaluationEntryList());
            evaluationOpenEntry.setType(evaluationConfig.getType());
            evaluationOpenEntry.setTitle(evaluationConfig.getTitle());
            evaluationOpenEntry.setExchange(exchange);
            evaluationOpenEntry.setSessionId(EvaluationManager.getLastSessionId(exchange));
            evaluationOpenEntry.setResolvedEnabled(evaluationConfig.getResolvedEnabled());
            evaluationOpenEntry.setResolvedRequired(evaluationConfig.getResolvedRequired());
            EvaluationApi.getInstance().getOnEvaluationEventListener().onEvaluationMessageClick(evaluationOpenEntry, activity);
        } else {
            KeyboardUtils.hideKeyboard(activity);
            final EvaluationDialog evaluationDialog = new EvaluationDialog(activity, exchange);
            evaluationDialog.setCanceledOnTouchOutside(false);
            evaluationDialog.setOnEvaluationDialogListener(new EvaluationDialog.OnEvaluationDialogListener() {
                @Override
                public void onSubmit(int score, List<String> tagIds, String remark, String name, int resolveOption, long sessionId) {
                    evaluationDialog.setSubmitBtnEnabled(false);
                    evaluationDialog.setIsSubmitting(true);
                    EvaluatorRequestEntry evaluatorRequestEntry = new EvaluatorRequestEntry();
                    evaluatorRequestEntry.exchange = exchange;
                    evaluatorRequestEntry.score = score;
                    evaluatorRequestEntry.remark = remark;
                    evaluatorRequestEntry.tagList = tagIds;
                    evaluatorRequestEntry.name = name;
                    evaluatorRequestEntry.resolveOption = resolveOption;
                    evaluatorRequestEntry.residentEntrance = 1;
                    evaluatorRequestEntry.sessionId = sessionId;
                    SessionManager.getInstance().getEvaluationManager().doEvaluate(evaluatorRequestEntry, new RequestCallbackWrapper<String>() {
                        @Override
                        public void onResult(int code, String result, Throwable exception) {
                            if ((code == 200 || code == EVALUATION_LIMIT) && evaluationDialog != null) {
                                evaluationDialog.cancel();
                            } else if (code != 200 && evaluationDialog != null && evaluationDialog.isShowing()) {
                                evaluationDialog.setSubmitBtnEnabled(true);
                                evaluationDialog.setIsSubmitting(false);
                                ToastUtil.showToast(activity.getString(R.string.ysf_network_error));

                            }
                            callbackWrapper.onResult(code, result, exception);
                        }
                    });
                }
            });
            evaluationDialog.show();
        }
    }

    /**
     * 再次评价的时候,放弃评价方法
     */
    public static void cancelEvaluation(String exchange) {
        RequestEvaluatorAgainCancelAttachment cancelAttachment = new RequestEvaluatorAgainCancelAttachment();
        cancelAttachment.setAppKey(UnicornImpl.getAppKey());
        cancelAttachment.setDeviceId(UnicornPreferences.getDeviceId());
        String dv = UnicornPreferences.getForeignName();
        if (!TextUtils.isEmpty(dv)) {
            cancelAttachment.setForeignId(UnicornPreferences.getForeignName());
        }
        cancelAttachment.setSessionId(SessionManager.getInstance().getEvaluationManager().getEvaluationAgainSessionId().get(exchange));
        SessionHelper.sendCustomNotification(cancelAttachment, exchange);
        SessionManager.getInstance().getEvaluationManager().getEvaluationAgainSessionId().remove(exchange);
    }


}
