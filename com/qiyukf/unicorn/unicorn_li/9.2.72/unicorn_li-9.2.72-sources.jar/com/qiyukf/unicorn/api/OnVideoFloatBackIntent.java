package com.qiyukf.unicorn.api;

import android.content.Context;

public interface OnVideoFloatBackIntent {

    /**
     * 点击视频客服小窗口,需要回到的界面,一般为客服聊天主界面
     *
     * @param context 上下文
     */
    void onVideoFloatBackIntent(Context context);

}
