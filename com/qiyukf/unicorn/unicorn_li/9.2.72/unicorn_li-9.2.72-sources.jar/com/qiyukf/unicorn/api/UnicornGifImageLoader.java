package com.qiyukf.unicorn.api;

import android.widget.ImageView;

import java.io.Serializable;

/**
 * Describe: 开发者需要实现的加载 gif 图片的接口，主要用于加载 gif 表情
 */
public interface UnicornGifImageLoader extends Serializable {

    /**
     * 当加载格式为 gif 表情的时候会调用此方法
     * @param url  gif 图片的 url
     * @param imageView  gif 图片的载体
     * @param imgName 根据imgName 的后缀可以知道
     */
    void loadGifImage(String url, ImageView imageView, String imgName);

}
