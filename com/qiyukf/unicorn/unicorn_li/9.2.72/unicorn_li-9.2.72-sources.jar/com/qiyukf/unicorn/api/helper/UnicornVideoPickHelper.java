package com.qiyukf.unicorn.api.helper;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import androidx.fragment.app.Fragment;

import com.qiyukf.nimlib.SDKCache;
import com.qiyukf.nimlib.net.http.util.AttachmentStore;
import com.qiyukf.nimlib.util.MD5;
import com.qiyukf.unicorn.R;
import com.qiyukf.uikit.session.activity.CaptureVideoActivity;
import com.qiyukf.uikit.session.helper.VideoMsgHelper;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.mediaselect.Matisse;
import com.qiyukf.unicorn.mediaselect.MimeType;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.UriHelper;
import com.qiyukf.unicorn.util.file.FileUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;

import java.io.File;
import java.util.Arrays;
import java.util.List;


/**
 * Created by andya on 2019-07-29
 * Describe: 可以通过该类实现使用 SDK 中的的拍摄视频和选择视频的功能(大部分使用场景是在 fragment 接入方式的情况下)
 */
public class UnicornVideoPickHelper {


    private UincornVideoSelectListener uincornVideoSelectListener;

    private VideoMsgHelper videoMsgHelper;

    /**
     * 拍摄视频或选择视频完成的回调，在 onVideoPicked 中可以通过
     * UniconrMessageBuilder 去构建一条消息，并通过 MessageService 去发送消息
     */
    public interface UincornVideoSelectListener {
        /**
         * 当拍摄成功或者选择视频成功的时候会回调该方法
         *
         * @param file 视频文件
         * @param md5  视频文件的 md5 也就是 UnicornMessageBuilder.buildVideoMessage 中的最后一个参数(displayname)
         */
        void onVideoPicked(File file, String md5);
    }

    /**
     * 构造方法
     *
     * @param activity                   接入方的 Activity
     * @param uincornVideoSelectListener
     */
    public UnicornVideoPickHelper(Activity activity, final UincornVideoSelectListener uincornVideoSelectListener) {

        this.uincornVideoSelectListener = uincornVideoSelectListener;
        videoMsgHelper = new VideoMsgHelper(activity, new VideoMsgHelper.VideoMessageHelperListener() {

            @Override
            public void onVideoPicked(File file, String md5) {
                if (UnicornVideoPickHelper.this.uincornVideoSelectListener != null) {
                    uincornVideoSelectListener.onVideoPicked(file, md5);
                }
            }
        });

    }


    /**
     * 前往 SDK 中的拍摄视频界面
     */
    public void goCaptureVideo(int requestCode) {
        if (videoMsgHelper != null) {
            videoMsgHelper.goCaptureVideo(requestCode);
        }
    }

    /**
     * 前往 SDK 中的选择视频的界面
     *
     * @param requestCode
     */
    public void goVideoAlbum(int requestCode) {
        if (videoMsgHelper != null) {
            videoMsgHelper.goVideoAlbum(requestCode);
        }
    }


    /**
     * 拍摄视频的回调
     * 当接入方 Activity 监听到 onActivityResult 方法回调且 requestCode = 拍摄的 requestCode
     * 的时候就调用该方法就可以了
     */
    public void onCaptureVideoResult(Intent data) {
        if (data == null) {
            return;
        }
        if (videoMsgHelper != null) {
            videoMsgHelper.onCaptureVideoResult(data);
        }
    }


    /**
     * 从本地选择视频的回调
     * 当接入方 Activity 监听到 onActivityResult 方法回调且 requestCode = 从本地选择视频的 requestCode
     * 的时候就调用该方法就可以了
     */
    public void onSelectLocalVideoResult(Intent data) {
        if (data == null) {
            return;
        }
        if (videoMsgHelper != null) {
            videoMsgHelper.onSelectLocalVideoResult(data);
        }
    }

    public static void goVideoAlbumActivity(final Fragment fragment, final int requestCode) {
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(fragment.getContext(), PermissionsConstant.goVideo)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.goVideo);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_SELECT_VIDEO);
                eventEntry.setPermissionList(permissionList);
                unicornEventBase.onEvent(eventEntry, fragment.getContext(), new EventCallback() {
                    @Override
                    public void onProcessEventSuccess(Object o) {
                        checkPermissionAndGoSelectVideo(fragment, requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onPorcessEventError() {
                        checkPermissionAndGoSelectVideo(fragment, requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onNotPorcessEvent() {
                        checkPermissionAndGoSelectVideo(fragment, requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onInterceptEvent() {
                        ToastUtil.showToast(R.string.ysf_no_permission_photo);
                    }
                });
            } else {
                checkPermissionAndGoSelectVideo(fragment, requestCode, null, null);
            }
        } else {
            checkPermissionAndGoSelectVideo(fragment, requestCode, null, null);
        }
    }


    public static void goVideoActivity(Fragment fragment, String videoFilePath, int requestCode) {
        CaptureVideoActivity.start(fragment, videoFilePath, requestCode);
    }

    /**
     * 用户自定义拍摄视频界面返回 file 的处理
     * 只有通过此方法处理之后的文件才能被发送
     */
    public static void onCaptureVideoResult(String videoFilePath, UincornVideoSelectListener listener) {
        String md5 = MD5.getStreamMD5(videoFilePath);
        String md5Path = YsfStorageUtil.getWritePath(md5 + ".mp4", YsfStorageType.TYPE_AUDIO);
        if (AttachmentStore.move(videoFilePath, md5Path)) {
            if (listener != null) {
                listener.onVideoPicked(new File(md5Path), md5);
            }
        } else {
            ToastUtil.showLongToast(R.string.ysf_video_exception);
        }
    }


    /**
     * 当用户自定义选择视频界面返回 file 的处理
     * 只有通过此方法处理之后的文件才能被发送
     */
    public static void onSelectLocalVideoResult(String videoFilePath, UincornVideoSelectListener listener) {
        //在拍摄中的本地视频库选择了文件
        String md5 = MD5.getStreamMD5(videoFilePath);
        String filename = md5 + "." + FileUtil.getExtensionName(videoFilePath);
        String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_VIDEO);
        if (AttachmentStore.copy(videoFilePath, md5Path) != -1) {
            if (listener != null) {
                listener.onVideoPicked(new File(md5Path), md5);
            }
        } else {
            ToastUtil.showToast(R.string.ysf_video_exception);
        }
    }

    /**
     * 当用户自定义选择视频界面返回 file 的处理
     * 只有通过此方法文件才能被发送
     */
    public static void onSelectLocalVideoResult(Uri uri, UincornVideoSelectListener listener) {
        //在拍摄中的本地视频库选择了文件
        if (uri == null) {
            return;
        }

        String md5 = MD5.getUriMD5(SDKCache.getContext(), uri);
        String filename = md5 + "." + FileUtil.getExtensionName(UriHelper.uriOfName(SDKCache.getContext(), uri));
        String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_VIDEO);
        if (AttachmentStore.copy(SDKCache.getContext(), uri, md5Path)) {
            if (listener != null) {
                listener.onVideoPicked(new File(md5Path), md5);
            }
        } else {
            ToastUtil.showToast(R.string.ysf_video_exception);
        }
    }

    private static void checkPermissionAndGoSelectVideo(Fragment fragment, int requestCode, UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(fragment)
                .permissions(PermissionsConstant.goVideo)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        //启动我们的 select media 框架
                        Matisse.startSelectMediaFile(fragment, MimeType.ofVideo(), 1, requestCode);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(fragment.getContext(), eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_photo);
                        }
                    }
                })
                .request();
    }
}
