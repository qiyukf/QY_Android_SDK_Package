package com.qiyukf.unicorn.api;



import com.qiyukf.unicorn.api.lifecycle.SessionLifeCycleOptions;
import com.qiyukf.unicorn.api.pop.SessionListEntrance;
import com.qiyukf.unicorn.api.pop.ShopEntrance;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 用户发起咨询的页面信息
 */
public class ConsultSource implements Serializable {

    /**
     * 咨询页面的uri，可以是url，也可以任意能标识来源的字符串
     */
    public String uri;

    /**
     * 咨询页面的title
     */
    public String title;

    /**
     * 可自定义传入的字符串，比如商品详细信息，用户操作状态等等, 在分配客服时该字段会传递给客服。
     */
    public String custom;
    /**
     * 请求分配客服时，指定客服分组。<br>
     * 分组 ID 可在管理后台的 「设置」-&gt;「访客分流」中查询
     */
    public long groupId;

    /**
     * 请求分配客服时，指定客服ID。如果指定了此参数，则groupId会被忽略。<br>
     * 客服 ID 可在管理后台的 「设置」-&gt;「访客分流」中查询
     */
    public long staffId;

    /**
     * 如果指定了 groupId 或者 staffId 时，该参数有效。表示会先进机器人，之后如果用户转人工服务，再分配给上面指定的groupId 或者 staffId
     */
    public boolean robotFirst;

    /**
     * 机器人ID，如果开启了机器人，该参数有效。如果不设置，将连接默认机器人。<br>
     * 机器人ID可以在管理后台的 设置 -&gt; APP接入 中查看。
     */
    public long robotId;

    /**
     * 机器人热门问题组 ID <br>
     * 如果指定了此参数，且请求客服为机器人客服，则会下发该 ID 对应的热门问题。<br>
     * 热门问题组 ID 可在管理后台查询。
     */
    public long faqGroupId;

    /**
     * 要咨询的商家 ID <br>
     * 平台电商调用，非平台电商不需要该字段。
     */
    public String shopId;

    /**
     * 访客发起会话时所带的商品消息信息<br>
     */
    public ProductDetail productDetail;

    /**
     * 访客发起会话时所带的卡片消息信息<br>
     */
    public CardDetail cardDetail;

    /**
     * 商家入口信息<br>
     * 如果为 null ，则不显示商家入口
     */
    public ShopEntrance shopEntrance;

    /**
     * 会话列表入口信息<br>
     * 如果为 null ，则不显示会话列表入口
     */
    public SessionListEntrance sessionListEntrance;

    /**
     * 用户VIP等级<br>
     * 0:非VIP（默认）<br>
     * 1-10:VIP等级<br>
     * 11:通用VIP（不显示等级）
     */
    public int vipLevel;

    /**
     * 对用户咨询会话的一些生命周期控制选项。通过这些选项，APP可以自定义是否允许用户主动结束会话，
     * 用户主动退出排队等开关，以及排队过程中用户按返回键的提示语，和界面退出的监听器等信息。
     * 默认为 null
     */
    public SessionLifeCycleOptions sessionLifeCycleOptions;

    /**
     * 人工客服时显示在输入框上方的快捷入口，如“选订单”，点击后可以响应自定义事件。<br>
     * 如果配置了快捷入口，需要在初始化七鱼时为 YSFOptions.quickEntryListener 赋值，以响应点击事件。
     */
    public ArrayList<QuickEntry> quickEntryList;

    /**
     * 是否在机器人状态发送商品，true 为机器人状态发送 false 为不发送
     */
    public boolean isSendProductonRobot;

    /**
     * 专属客服的 id
     */
    public String vipStaffid;

    /**
     * 连接专属客服成功时候的提示语
     */
    public String prompt;

    /**
     * 专属客服头像的 url ，如果配置了该字段，那么与这个客服聊天的消息都会为这个字段
     */
    public String VIPStaffAvatarUrl;

    /**
     * 专属客服的名字
     */
    public String vipStaffName;

    /**
     * 专属客服的欢迎语
     */
    public String vipStaffWelcomeMsg;

    /**
     * 机器人欢迎语 id ，可以通过该参数配置不同的机器人欢迎语
     */
    public String robotWelcomeMsgId;

    /**
     * 留言模版 id ，可以通过指定该参数配置不同的留言模版
     */
    public String leaveMsgTemplateId;

    /**
     * 访客分流模版 id
     */
    public long groupTmpId;

    /**
     * 是否禁止使用 FLAG_ACTIVITY_CLEAR_TOP 去启动客服 Activity，默认为 false
     */
    public boolean forbidUseCleanTopStart = false;

    /**
     * 是否开启视频客服
     */
    public boolean isEnableVideo = false;

    public ConsultSource(String uri, String title, String custom) {
        this.uri = uri;
        this.title = title;
        this.custom = custom;
    }
}
