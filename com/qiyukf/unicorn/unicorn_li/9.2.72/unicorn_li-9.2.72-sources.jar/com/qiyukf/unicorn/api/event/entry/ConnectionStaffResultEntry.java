package com.qiyukf.unicorn.api.event.entry;

/**
 * Describe: 链接客服成功的实体类，当连接客服有结果的时候
 * 我们将会把该实体类传递到连接客服结果事件 onEvent 方法中
 */
public class ConnectionStaffResultEntry {

    /**
     * 连接客服结果的状态码 200:成功;201:没有客服在线;202:其它错误;203:需要排队;204:bundleid无效
     */
    private int code;
    /**
     * 连接结果 0:连接成功 1:连接失败
     */
    private int connectResult;

    /**
     * 连接客服失败的类型 0：网络断开  1：连接超时
     */
    private int errorType;

    /**
     * 客服的类型 0：机器人 1：人工客服
     */
    private int staffType;

    /**
     * 客服头像 url
     * @return
     */
    private String staffIconUrl;

    /**
     * 客服的名字
     */
    private String staffName;

    /**
     * 客服的 Nimid ，一般开发者用不到该 id
     */
    private String staffId;

    /**
     * 客服的 realStaffid 与后台查询到的 id 相对应
     */
    private long staffRealId;

    /**
     * 专属客服的 id
     * 有可能为 null
     */
    private String vipStaffid;

    /**
     * 专属客服头像的 url ，如果配置了该字段，那么与这个客服聊天的消息都会为这个字段
     * 有可能为 null
     */
    private String VIPStaffAvatarUrl;

    /**
     * 专属客服的名字
     * 有可能为 null
     */
    private String vipStaffName;

    /**
     * 连接成功客服所属的分组
     * 如果用户设置了专属客服，这个里面是没有值的
     */
    private long groupId;

    /**
     * 会话id
     */
    private long sessionId;

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public int getConnectResult() {
        return connectResult;
    }

    public void setConnectResult(int connectResult) {
        this.connectResult = connectResult;
    }

    public String getStaffIconUrl() {
        return staffIconUrl;
    }

    public void setStaffIconUrl(String staffIconUrl) {
        this.staffIconUrl = staffIconUrl;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public int getStaffType() {
        return staffType;
    }

    public void setStaffType(int staffType) {
        this.staffType = staffType;
    }

    public int getErrorType() {
        return errorType;
    }

    public void setErrorType(int errorType) {
        this.errorType = errorType;
    }

    public String getVipStaffid() {
        return vipStaffid;
    }

    public void setVipStaffid(String vipStaffid) {
        this.vipStaffid = vipStaffid;
    }

    public String getVIPStaffAvatarUrl() {
        return VIPStaffAvatarUrl;
    }

    public void setVIPStaffAvatarUrl(String VIPStaffAvatarUrl) {
        this.VIPStaffAvatarUrl = VIPStaffAvatarUrl;
    }

    public String getVipStaffName() {
        return vipStaffName;
    }

    public void setVipStaffName(String vipStaffName) {
        this.vipStaffName = vipStaffName;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public long getStaffRealId() {
        return staffRealId;
    }

    public void setStaffRealId(long staffRealId) {
        this.staffRealId = staffRealId;
    }

    public long getSessionId() {
        return sessionId;
    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }
}
