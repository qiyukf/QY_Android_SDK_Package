package com.qiyukf.unicorn.api;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.qiyukf.module.log.UnicornLog;
import com.qiyukf.nimlib.SDKState;
import com.qiyukf.nimlib.net.http.download.HttpDownloadManager;
import com.qiyukf.nimlib.sdk.NIMClient;
import com.qiyukf.nimlib.sdk.RequestCallback;
import com.qiyukf.nimlib.sdk.msg.MsgService;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.unicorn.POPManagerImpl;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.msg.MessageService;
import com.qiyukf.unicorn.api.msg.OnPushMessageListener;
import com.qiyukf.unicorn.cache.UnicornPreferences;
import com.qiyukf.unicorn.session.SessionHelper;
import com.qiyukf.unicorn.session.SessionManager;
import com.qiyukf.unicorn.ui.activity.ServiceMessageActivity;
import com.qiyukf.unicorn.ui.fragment.ServiceMessageFragment;
import com.qiyukf.unicorn.util.QiyuInitHandler;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;

/**
 * 云商服业务接口。
 */
public class Unicorn {
    private static final String TAG = "Unicorn";
    private static UnicornImpl delegate;

    /**
     * 初始化云商服 SDK。
     * 该方法内部会调用 NIMClient.init 方法，如果调用此方法，则不需要调用 NIMClient.init
     * NIMClient.init 中传递的 SdkOption 可以通过 YSFOption 中的 sdkOptions 参数传递
     *
     * @param context     上下文
     * @param appKey      管理后台申请的 AppKey
     * @param options     选项配置
     * @param imageLoader 图片加载器，开发者可根据自身项目实际实现，不可为空
     * @return 初始化是否成功
     */
    public static boolean init(final Context context, final String appKey, final YSFOptions options, @NonNull final UnicornImageLoader imageLoader) {
        delegate = UnicornImpl.init(context, appKey, options, imageLoader);
        return !SDKState.isMainProcess() || delegate != null;
    }

    /**
     * [初始化SDK方法二] 需要在 Application 的 onCreate 中调用（仅仅是配置，不影响性能）
     *
     * @param context     上下文
     * @param appKey      管理后台申请的 AppKey
     * @param options     选项配置
     * @param imageLoader 图片加载器，开发者可根据自身项目实际实现，不可为空
     */
    public static boolean config(final Context context, final String appKey, final YSFOptions options, @NonNull final UnicornImageLoader imageLoader) {
        delegate = UnicornImpl.config(context, appKey, options, imageLoader);
        return !SDKState.isMainProcess() || delegate != null;
    }

    /**
     * [初始化SDK方法二] 在UI进程主线程上按需使用的初始化SDK
     * 注意:在调用该方法之前，一定要先在 Application 中调用 Unicorn.config(Context,String,YSFOptions, UnicornServiceImpl)
     */
    public static boolean initSdk() {
        UnicornImpl.initSdk();
        return !SDKState.isMainProcess() || delegate != null;
    }

    /**
     * 判断七鱼服务是否初始化成功。
     *
     * @return true，如果七鱼服务已经初始化成功，否则返回 false
     * @deprecated 该接口将始终返回 true，如果七鱼初始化失败，联系客服将无响应
     */
    @Deprecated
    public static boolean isServiceAvailable() {
        return true;
    }

    /**
     * 判断七鱼 SDK 是否初始化，当没有初始化的时候就不要进入客服界面了
     *
     * @return 是否初始化了
     */
    public static boolean isInit() {
        return delegate != null && UnicornImpl.isInitialized();
    }

    /**
     * 当需要修改选项配置时，包括通知栏提醒，UI自定义等配置，调用该接口告诉SDK。
     *
     * @param options 选项配置
     */
    public static void updateOptions(final YSFOptions options) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    delegate.updateAndSaveOptions(options);
                }
            }
        });
    }

    /**
     * 打开客服聊天界面。咨询客服以及有新消息提醒到达时都从这个接口打开界面。<br>
     * 如果当前客服系统还没有准备好，不会打开客服窗口。
     *
     * @param context 上下文
     * @param title   打开的聊天窗口的标题
     * @param source  发起咨询的来源信息
     */
    public static void openServiceActivity(final Context context, final String title, final ConsultSource source) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (delegate != null) {
                    ServiceMessageActivity.start(context, title, source);
                } else {
                    ToastUtil.showToast("init error please init first.");
                    UnicornLog.i(TAG,"QIYU is not init, please init first.");
                }
            }
        });
    }

    /**
     * 使用 Fragment 的方式集成客服聊天界面。<br>
     * 如果当前客服系统还没有准备好，会返回 null。<br>
     *
     * @param title  打开的聊天窗口的标题
     * @param source 发起咨询的来源信息
     * @return 待集成的 Fragment，或者返回 null 如果七鱼未初始化或初始化失败
     * @deprecated 使用 newServiceFragment(String, ConsultSource, ViewGroup) 代替。
     */
    @Deprecated
    public static ServiceMessageFragment newServiceFragment(String title, ConsultSource source) {
        return newServiceFragment(title, source, null);
    }

    /**
     * 使用 Fragment 的方式集成客服聊天界面。<br>
     * 如果当前客服系统还没有准备好，会返回 null。<br>
     * 由于客服评价和人工客服入口不在会话列表中，因此需要外部传入一个ViewGroup用于放置评价入口。
     *
     * @param title               打开的聊天窗口的标题
     * @param source              发起咨询的来源信息
     * @param actionMenuContainer 用于放置SDK的一些icon入口。目前用于放置客服评价和人工客服的入口
     * @return 待集成的 Fragment，或者返回 null 如果七鱼未初始化或初始化失败
     */
    public static ServiceMessageFragment newServiceFragment(String title, ConsultSource source, ViewGroup actionMenuContainer) {
        if (delegate != null) {
            ServiceMessageFragment fragment = new ServiceMessageFragment();
            fragment.setArguments(title, source, actionMenuContainer);
            return fragment;
        } else {
            UnicornLog.i(TAG,"QIYU is not init, please init first.");
            return null;
        }
    }

    /**
     * 设置 SDK 展示的语言(目前支持简体中文、繁体中文、英文)
     *
     * @param language (zh、en)
     * @param area     TW(台湾)
     */
    public static void setLocalLanguage(String language, String area) {
        if (delegate != null) {
            delegate.setLanguageLocal(language, area);
        } else {
            UnicornLog.i(TAG,"QIYU is not init, please init first.");
        }
    }

    /**
     * 跟踪用户浏览记录
     *
     * @param url   浏览记录 url
     * @param title 浏览页面标题
     */
    public static void trackUserAccess(final String url, final String title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    delegate.trackUserAccess(url, title);
                }
            }
        });
    }

    /**
     * 获取未读的客服消息数
     *
     * @return 未读数
     */
    public static int getUnreadCount() {
        POPManagerImpl popManager = UnicornImpl.getPOPManager();
        if (popManager != null) {
            return popManager.getTotalUnreadCount();
        }
        return 0;
    }

    /**
     * 添加/注销未读消息数变化监听者
     *
     * @param listener 未读数变化监听者
     * @param add      true 为添加， false 为注销
     */
    public static void addUnreadCountChangeListener(final UnreadCountChangeListener listener, final boolean add) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                POPManagerImpl popManager = UnicornImpl.getPOPManager();
                if (popManager != null) {
                    popManager.addUnreadCountChangeListener(listener, add);
                }
            }
        });
    }

    /**
     * 关联商户资料接口, 告知客服当前用户的资料。<br>
     * 请注意：由于涉及到消息记录的维护，此接口不支持直接从一个用户切换到另外一个用户。<br>
     * 如果切换用户，请先注销（参数传null），然后再调用设置。<br>
     * 如果使用融合 SDK 在调用该方法之前需要调用 NimClient.getService(AuthService.class).login 方法
     *
     * @param userInfo 商户用户资料
     * @return 设置成功或失败。此处仅检查参数是否正确。
     */
    public static boolean setUserInfo(YSFUserInfo userInfo) {
        return setUserInfo(userInfo, null);
    }

    /**
     * 该接口效果和{@link #setUserInfo(YSFUserInfo)}相同，但多了一个回调接口，当设置成功或失败后，会通过该
     * 接口通知调用者，失败情况包括网络错误，鉴权失败等情况。但如果参数检查就没有通过，则会直接返回false，而不
     * 会调用该回调接口。
     *
     * @param userInfo 商户用户资料
     * @param callback 回调接口。只有在返回为true时，才会调用到该接口。
     * @return 设置成功或失败。此处仅检查参数是否正确。该返回值在 V5.16.0 已经废弃，请在 callback 中判断该方法是否调用成功
     */
    public static boolean setUserInfo(YSFUserInfo userInfo, RequestCallback<Void> callback) {
        return isInit() && delegate.setUserInfo(userInfo, callback);
    }

    /**
     * 注销接口。等同于 `setUserInfo(null)`。 一般来说，跟随 APP 的注销登出接口一起调用。<br>
     * 注销之后，客服再给前面用户发送消息，将进入留言，等到该用户下次再在同一台设备上登录后，能够再看到。<br>
     * 注意：目前不支持跨设备的消息漫游，在其他设备上通过 {@link #setUserInfo(YSFUserInfo)} 设置相同的用户，
     * 这个设备上不能收到留言。
     * 切记该接口必须在 NIMClient.getService(AuthService.class).logout() 之前调用
     */
    public static void logout() {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                setUserInfo(null);
            }
        });
    }

    /**
     * 通知栏消息提醒开关控制。<br>
     * 只有StatusBarNotificationConfig配置不为空时才有效
     *
     * @param on 开关
     */
    public static void toggleNotification(final boolean on) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    UnicornPreferences.saveNotificationToggle(on);
                }
                NIMClient.toggleNotification(on);
            }
        });
    }

    /**
     * 拉取服务器模板消息
     *
     * @param msgId 模板消息ID
     */
    public static void pullTemplateMsg(final long msgId) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    delegate.pullTemplateMsg(SessionHelper.getDefaultSessionId(), msgId);
                }
            }
        });
    }

    /**
     * 获取和客服的最后一条聊天消息内容。
     * 可用于未读消息变化时，展示最后一条未读消息，或者展示客服的最后一条消息。
     *
     * @return 最后一条消息
     */
    public static IMMessage queryLastMessage() {
        if (isInit()) {
            return NIMClient.getService(MsgService.class).queryLastMessage(SessionHelper.getDefaultSessionId(), SessionTypeEnum.Ysf);
        }
        return null;
    }

    /**
     * 添加主动消息推送的监听器，用于处理主动推送的消息
     *
     * @param listener 监听器
     */
    public static void addPushMessageListener(OnPushMessageListener listener) {
        if (isInit()) {
            SessionManager.getInstance().addPushMessageListener(listener);
        }
    }

    /**
     * 移除主动推送消息的监听器
     *
     * @param listener 监听器
     */
    public static void removePushMessageListener(OnPushMessageListener listener) {
        if (isInit()) {
            SessionManager.getInstance().removePushMessageListener(listener);
        }
    }

    /**
     * 清除文件缓存，将删除SDK接收过的所有文件。<br>
     * 建议在工作线程中执行该操作。
     */
    public static void clearCache() {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    try {
                        // 中断当前正在下载
                        HttpDownloadManager.getInstance().cancelAll();

                        YsfStorageUtil.clearCache(YsfStorageType.TYPE_FILE);
                    } catch (Throwable th) {
                        UnicornLog.i(TAG,"clear cache error", th);
                    }
                }
            }
        });
    }

    /**
     * 向客服发送商品信息消息
     * 移动到 {@link MessageService#sendProductMessage(ProductDetail)}
     */
    @Deprecated
    public static void sendProductMessage(ProductDetail productDetail) {
        MessageService.sendProductMessage(productDetail);
    }

    /**
     * 额外提供的setUserInfo(null, callback)回调失败后，能清空本地Crm数据的方法，要在callback的onFailed或onException中调用
     */
    public static void clearCrmInfo() {
        if (isInit()) {
            delegate.clearCrmInfo();
        }
    }

    /**
     * 额外提供的clearCrmInfoAndSession方法，清空本地Crm数据和会话数据
     */
    public static void clearCrmInfoAndSession(String env) {
        if (isInit()) {
            delegate.clearCrmInfoAndSession(env);
        }
    }

    /**
     * 清空所有本地聊天消息。<br>
     * 该方法会清空本地数据库中的所有消息记录和最近会话记录。<br>
     * 建议在工作线程中执行该操作。
     *
     * @param callback 清空结果回调，成功时返回 null，失败时返回错误信息
     */
    public static void clearAllMessages(final RequestCallback<Void> callback) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (isInit()) {
                    delegate.clearAllMessages(callback);
                } else {
                    UnicornLog.i(TAG, "QIYU is not init, please init first.");
                    if (callback != null) {
                        callback.onFailed(-1);
                    }
                }
            }
        });
    }

    /**
     * 清空所有本地聊天消息（无回调版本）。<br>
     * 该方法会清空本地数据库中的所有消息记录和最近会话记录。<br>
     * 建议在工作线程中执行该操作。
     */
    public static void clearAllMessages() {
        clearAllMessages(null);
    }
}
