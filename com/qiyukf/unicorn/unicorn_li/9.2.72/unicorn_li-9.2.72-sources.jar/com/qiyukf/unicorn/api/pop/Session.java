package com.qiyukf.unicorn.api.pop;


import com.qiyukf.nimlib.sdk.msg.constant.MsgStatusEnum;

import java.io.Serializable;

/**
 * 商家会话接口
 */
public interface Session extends Serializable {

    /**
     * 获取商家ID
     *
     * @return 商家ID
     */
    String getContactId();


    /**
     * 获取最后一条消息状态
     *
     * @return 最后一条消息的状态
     */
    MsgStatusEnum getMsgStatus();

    /**
     * 获取商家的未读消息条数
     *
     * @return 未读数
     */
    int getUnreadCount();

    /**
     * 获取最后一条消息的缩略内容
     *
     * @return 缩略内容
     */
    String getContent();

    /**
     * 获取最后一条消息的时间戳
     *
     * @return 时间
     */
    long getTime();
}
