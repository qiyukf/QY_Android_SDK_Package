package com.qiyukf.unicorn.api.event.entry;

import java.util.List;

/**
 * Created by zhanyage on 2020/10/10
 * Describe: 用户申请权限事件传递的 entry
 */
public class RequestPermissionEventEntry {

    /**
     * 从本地选择媒体文件(视频和图片)
     */
    public static final int SCENES_SELECT_MEDIA = 0;
    /**
     * 拍摄视频场景
     */
    public static final int SCENES_TAKE_VIDEO = 1;
    /**
     * 保存图片到本地
     */
    public static final int SCENES_SAVE_IMAGE = 2;
    /**
     * 保存视频到本地
     */
    public static final int SCENES_SAVE_VIDEO = 3;
    /**
     * 选择本地视频
     */
    public static final int SCENES_SELECT_VIDEO = 4;
    /**
     * 选择本地文件
     */
    public static final int SCENES_SELECT_FILE = 5;
    /**
     * 选择本地图片
     */
    public static final int SCENES_SELECT_IMAGE = 6;
    /**
     * 拍照
     */
    public static final int SCENES_TAKE_PHOTO = 7;
    /**
     * 录音
     */
    public static final int SCENES_TAKE_AUDIO = 8;
    /**
     * 视频聊天
     */
    public static final int SCENES_VIDEO_CHAT = 9;
    /**
     * 通知栏权限
     */
    public static final int SCENES_POST_NOTIFICATIONS = 10;
    /**
     * 定位权限
     */
    public static final int SCENES_MAP_LOCATION = 11;
    /**
     * 申请权限的列表，具体包括如下
     * //读取文件
     * String readFile = Manifest.permission.READ_EXTERNAL_STORAGE;
     * //写文件
     * String writeFile = Manifest.permission.WRITE_EXTERNAL_STORAGE;
     * //拍摄权限
     * String camera = Manifest.permission.CAMERA;
     * //拍照和存储照片的权限
     * String[] cameraAndRedFile = {Manifest.permission.READ_EXTERNAL_STORAGE,
     *         Manifest.permission.WRITE_EXTERNAL_STORAGE,
     *         Manifest.permission.CAMERA};
     * //相册权限，包括相册和选择视频
     *  String[] goAlbum = {Manifest.permission.READ_EXTERNAL_STORAGE,
     *         Manifest.permission.WRITE_EXTERNAL_STORAGE};
     * //拍摄视频权限
     * String[] captureVideo = {Manifest.permission.READ_EXTERNAL_STORAGE,
     *          Manifest.permission.WRITE_EXTERNAL_STORAGE,
     *          Manifest.permission.CAMERA,
     *          Manifest.permission.RECORD_AUDIO};
     * //录音权限
     * String[] recordAudio = {Manifest.permission.RECORD_AUDIO,
     *          Manifest.permission.WRITE_EXTERNAL_STORAGE};
     */
    private List<String> permissionList;

    /**
     * 申请权限的场景
     */
    private int scenesType;

    public List<String> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List<String> permissionList) {
        this.permissionList = permissionList;
    }

    public int getScenesType() {
        return scenesType;
    }

    public void setScenesType(int scenesType) {
        this.scenesType = scenesType;
    }
}
