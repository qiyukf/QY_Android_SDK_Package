package com.qiyukf.unicorn.api.msg;


import android.net.Uri;
import android.text.TextUtils;

import com.qiyukf.nimlib.SDKCache;
import com.qiyukf.nimlib.net.http.util.AttachmentStore;
import com.qiyukf.nimlib.sdk.msg.MessageBuilder;
import com.qiyukf.nimlib.sdk.msg.attachment.MsgAttachment;
import com.qiyukf.nimlib.sdk.msg.constant.MsgTypeEnum;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.CustomMessageConfig;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.nimlib.session.IMMessageImpl;
import com.qiyukf.nimlib.util.MD5;
import com.qiyukf.nimlib.util.StringUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.attachment.MapLocationAttachment;
import com.qiyukf.unicorn.session.SessionHelper;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.UriHelper;
import com.qiyukf.unicorn.util.file.FileUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;

import java.io.File;

/**
 * create by andya on 2018/7/11
 * 创建 message 的工具类
 * 接入方可以通过该类去创建不同类型的 message
 * 然后再去调用 send 方法发送
 */

public class  UnicornMessageBuilder {

    private static final String TAG = "UnicornMessageBuilder";
    /**
     * 创建一条图片消息
     *
     * @param sessionId   聊天对象ID
     * @param file        图片文件
     * @param displayName 图片文件的显示名，可不同于文件名
     * @return IMMessage 生成的消息对象
     */
    public static final IMMessage buildImageMessage(String sessionId, File file, String displayName){
        return MessageBuilder.createImageMessage(sessionId, SessionTypeEnum.Ysf, file, displayName);
    }

    /**
     * 创建一条普通文本消息
     *
     * @param sessionId   聊天对象ID
     * @param text        文本消息内容
     * @return IMMessage 生成的消息对象
     */
    public static final IMMessage buildTextMessage(String sessionId, String text){
        return MessageBuilder.createTextMessage(sessionId, SessionTypeEnum.Ysf, text);
    }

    /**
     * 创建一条视频消息
     * @param file  视频文件
     * @param duration 视频文件时长   可通过 MediaPlayer 获取
     * @param width  视频文件宽       可通过 MediaPlayer 获取
     * @param height  视频文件高      可通过 MediaPlayer 获取
     * @param displayName  视频文件名字，可通过 file.getName 获取
     * @return
     */
    public static final IMMessage buildVideoMessage(File file, long duration, int width, int height, String displayName) {
        return MessageBuilder.createVideoMessage(SessionHelper.getDefaultSessionId(), SessionTypeEnum.Ysf,
                file, duration, width, height, displayName);
    }

    /**
     * 创建一条视频消息
     * @param sessionId 聊天对象的 id
     * @param file  视频文件
     * @param duration 视频文件时长   可通过 MediaPlayer 获取
     * @param width  视频文件宽       可通过 MediaPlayer 获取
     * @param height  视频文件高      可通过 MediaPlayer 获取
     * @param displayName  视频文件名字，可通过 file.getName 获取
     * @return
     */
    public static final IMMessage buildVideoMessage(String sessionId, File file, long duration, int width, int height, String displayName) {
        return MessageBuilder.createVideoMessage(sessionId, SessionTypeEnum.Ysf,
                file, duration, width, height, displayName);
    }

    /**
     * 创建一条APP自定义类型消息
     * @param attachment  消息附件对象
     * @return 自定义消息
     */
    public static IMMessage buildCustomMessage(MsgAttachment attachment) {
        return buildCustomMessage(SessionHelper.getDefaultSessionId(),  null, attachment, null);
    }

    /**
     * 创建一条APP自定义类型消息
     *
     * @param sessionId   聊天对象ID  可以通过 message.getSessionId() 获取
     * @param attachment  消息附件对象
     * @return 自定义消息
     */
    public static IMMessage buildCustomMessage(String sessionId,  MsgAttachment attachment) {
        return buildCustomMessage(sessionId,  null, attachment, null);
    }

    /**
     * 创建一条APP自定义类型消息, 同时提供描述字段，可用于推送以及状态栏消息提醒的展示。
     *
     * @param sessionId   聊天对象ID
     * @param content     消息简要描述，可通过IMMessage#getContent()获取，主要用于用户推送展示。
     * @param attachment  消息附件对象
     * @param config      自定义消息配置
     * @return 自定义消息
     */
    public static IMMessage buildCustomMessage(String sessionId, String content, MsgAttachment attachment, CustomMessageConfig config) {
        IMMessage message = MessageBuilder.createCustomMessage(sessionId, SessionTypeEnum.Ysf, content,attachment,config);
        return message;
    }

    /**
     * 创建一条APP 私有的消息类型的消息
     * @param attachment  消息附件对象
     * @return 自定义消息
     */
    public static IMMessage buildAppCustomMessage(MsgAttachment attachment) {
        IMMessageImpl message = (IMMessageImpl) MessageBuilder.createCustomMessage(SessionHelper.getDefaultSessionId(), SessionTypeEnum.Ysf, null,attachment,null);
        message.setMsgType(MsgTypeEnum.appCustom.getValue());
        return message;
    }

    /**
     * 构造一条文件消息
     * @param sessionId 如果是平台版则为 shopId，非平台版则可以通过
     * @see #getSessionId  方法获取
     * @param filePath file 路径
     * @return IMMessage
     */
    public static IMMessage buildFileMessage(String sessionId, String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        String md5 = MD5.getStreamMD5(filePath);
        //这个地方
        String filename = md5 + "." + FileUtil.getExtensionName(filePath);
        String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_FILE);
        IMMessage message = null;
        if (AttachmentStore.copy(filePath, md5Path) != -1) {
            if (md5Path != null) {
                File file = new File(md5Path);
                message = MessageBuilder.createFileMessage(sessionId, SessionTypeEnum.Ysf, file, StringUtil.nameOfPath(filePath));
            }
        } else {
            ToastUtil.showToast(R.string.ysf_create_text_message_fail);
            return null;
        }
        return message;
    }

    /**
     * 构造一条文件消息适用于可以拿到 uri 的用户
     * @param sessionId 如果是平台版则为 shopId，非平台版则可以通过
     * @see #getSessionId  方法获取
     * @param uri 文件的 uri
     * @return IMMessage
     */
    public static IMMessage buildFileMessage(String sessionId, Uri uri) {
        if (uri == null) {
            return null;
        }

        IMMessage message = null;
        String md5 = MD5.getUriMD5(SDKCache.getContext(), uri);
        String filename = md5 + "." + FileUtil.getExtensionName(uri.toString());
        String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_FILE);
        if (AttachmentStore.copy(SDKCache.getContext(), uri, md5Path)) {
            if (md5Path != null) {
                File file = new File(md5Path);
                message = MessageBuilder.createFileMessage(sessionId, SessionTypeEnum.Ysf, file, UriHelper.uriOfName(SDKCache.getContext(), uri));
            }
        } else {
            ToastUtil.showToast(R.string.ysf_media_exception);
        }
        return message;
    }

    /**
     * 获取 sessionid 的方法
     * @return
     */
    public static String getSessionId() {
        return SessionHelper.getDefaultSessionId();
    }



}
