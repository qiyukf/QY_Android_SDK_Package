package com.qiyukf.unicorn.api.customization.title_bar;

import android.app.Activity;

/**
 * create by andya on 2018/7/10
 * title bar 右侧按钮点击事件接口
 * 仅对于使用 Activity 方式接入的 app 有效。
 */

public interface OnTitleBarRightBtnClickListener {

    /**
     * 标题栏右侧按钮点击响应方法
     * @param activity 聊天窗口 Activity
     */
    void onClick(Activity activity);
}
