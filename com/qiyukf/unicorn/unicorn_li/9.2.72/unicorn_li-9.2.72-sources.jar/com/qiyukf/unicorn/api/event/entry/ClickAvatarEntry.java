package com.qiyukf.unicorn.api.event.entry;

/**
 * Created by zhanyage on 2020/8/18
 * Describe: 点击头像事件传递给 App 的 entry
 */
public class ClickAvatarEntry {

    /**
     * 点击头像的客服 ID 为 im id
     * 可以根据七鱼开放的接口查询相关的客服信息 接口文档地址：http://qiyukf.com/docs/guide/server/5-%E5%91%98%E5%B7%A5%E7%AE%A1%E7%90%86.html#%E6%9F%A5%E8%AF%A2%E5%8D%95%E4%B8%AA%E5%AE%A2%E6%9C%8D%E4%BF%A1%E6%81%AF
     * 点击消息头像为机器人时 ID = QIYU_ROBOT
     * 点击系统消息头像时，ID = "-1"
     */
    private String staffId;

    /**
     * 用户可以点击聊天界面的左侧头像(客服头像)
     * 也可以点击聊天界面的右侧头像(方可头像)
     * 当点击客服头像时该字段为 true
     * 当点击方可头像石该字段为 false
     */
    private boolean isStaff;

    /**
     * 访客的 userId 与 setUserInfo 传递进来的一致
     */
    private String userId;

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public boolean isStaff() {
        return isStaff;
    }

    public void setStaff(boolean staff) {
        isStaff = staff;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "ClickAvatarEntry{" +
                "staffId=" + staffId +
                ", isStaff=" + isStaff +
                ", userId='" + userId + '\'' +
                '}';
    }
}
