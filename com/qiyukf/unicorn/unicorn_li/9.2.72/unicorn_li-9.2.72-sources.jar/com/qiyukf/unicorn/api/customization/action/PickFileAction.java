package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;

import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.unicorn.api.helper.UnicornPickFileHelper;

import static android.app.Activity.RESULT_OK;

/**
 * 选择文件的 Action ，用于 "+" 中的选择文件选项，可在
 * ActionListProvider.getActionList 方法中根据需要返回
 */
public class PickFileAction extends BaseAction {

    private int actionFontColor = 0; //底部文字颜色

    /**
     * 构造方法
     *
     * @param iconResId 图片的 resId
     * @param titleId   文字的 stringId
     */
    public PickFileAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    public PickFileAction(String imageUrl, String title) {
        super(imageUrl, title);
    }

    public PickFileAction(int iconResId, String title) {
        super(iconResId, title);
    }

    /**
     * 点击方法
     */
    @Override
    public void onClick() {
        UnicornPickFileHelper.goPickFileActivity(getFragment(), makeRequestCode(RequestCode.SELECT_FILE_REQUEST_CODE));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RequestCode.SELECT_FILE_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    UnicornPickFileHelper.onPickFileResult(getAccount(), getActivity(), data);
                }
                break;
        }
    }

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     *
     * @param actionFontColor
     */

    public void setActionFontColor(int actionFontColor) {
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        } else {
            return actionFontColor;
        }
    }
}
