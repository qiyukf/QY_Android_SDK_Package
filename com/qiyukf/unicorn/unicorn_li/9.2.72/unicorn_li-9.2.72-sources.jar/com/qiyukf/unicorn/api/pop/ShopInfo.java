package com.qiyukf.unicorn.api.pop;


import com.qiyukf.nimlib.sdk.uinfo.model.UserInfo;

/**
 * 商家信息接口
 */
public interface ShopInfo extends UserInfo {
    /**
     * 获取商家ID
     *
     * @return 商家ID
     */
    @Override
    String getAccount();

    /**
     * 获取商家名称
     *
     * @return 商家名称
     */
    @Override
    String getName();

    /**
     * 获取商家头像
     *
     * @return 商家头像
     */
    @Override
    String getAvatar();
}
