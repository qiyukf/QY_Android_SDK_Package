package com.qiyukf.unicorn.api;

import android.app.Activity;
import android.app.Fragment;

import com.qiyukf.unicorn.statistics.StatisticsManager;
import com.qiyukf.unicorn.util.QiyuInitHandler;

import org.json.JSONObject;

/**
 * app 访问轨迹设置接口，提供Activity和Fragment的进入退出封装
 */
public class QiyuTracker {
    /**
     * 如果关闭自动记录用户访问轨迹，则需要在 Activity#onResume 中调用该方法，该方法需要和 QiyuTracker#onPause 成对使用。<br>
     * 如果使用该方法，请在 AndroidManifest 中指定 Activity 的 label，参考 onResume(Activity, CharSequence)。
     *
     * @param activity 当前页面
     */
    public static void onResume(final Activity activity) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onResume(activity);
                }
            }
        });
    }

    /**
     * 如果关闭自动记录用户访问轨迹，则需要在 Activity#onPause 中调用该方法，该方法需要和 QiyuTracker#onResume 成对使用。<br>
     * 如果使用该方法，请在 AndroidManifest 中指定 Activity 的 label，参考 onResume(Activity, CharSequence)。
     *
     * @param activity 当前页面
     */
    public static void onPause(final Activity activity) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onPause(activity);
                }
            }
        });
    }

    /**
     * 如果关闭自动记录用户访问轨迹，则需要在 Activity#onResume 中调用该方法，该方法需要和 QiyuTracker#onPause 成对使用。
     *
     * @param activity 当前页面
     * @param title 页面标题
     */
    public static void onResume(final Activity activity, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onResume(activity, title);
                }
            }
        });
    }

    /**
     * 如果关闭自动记录用户访问轨迹，则需要在 Activity#onPause 中调用该方法，该方法需要和 QiyuTracker#onResume 成对使用。
     *
     * @param activity 当前页面
     * @param title 页面标题
     */
    public static void onPause(final Activity activity, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onPause(activity, title);
                }
            }
        });
    }

    /**
     * 如果需要记录 Fragment，则需要在 Fragment#onResume 中调用该方法，该方法需要和 QiyuTracker#onPause 成对使用。
     *
     * @param fragment 当前页面
     * @param title 页面标题
     */
    public static void onResume(final Fragment fragment, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onResume(fragment, title);
                }
            }
        });
    }

    /**
     * 如果需要记录 Fragment，则需要在 Fragment#onPause 中调用该方法，该方法需要和 QiyuTracker#onResume 成对使用。
     *
     * @param fragment 当前页面
     * @param title 页面标题
     */
    public static void onPause(final androidx.fragment.app.Fragment fragment, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onPause(fragment, title);
                }
            }
        });
    }

    /**
     * 如果需要记录 Fragment，则需要在 Fragment#onResume 中调用该方法，该方法需要和 QiyuTracker#onPause 成对使用。
     *
     * @param fragment 当前页面
     * @param title 页面标题
     */
    public static void onResume(final androidx.fragment.app.Fragment fragment, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onResume(fragment, title);
                }
            }
        });
    }

    /**
     * 如果需要记录 Fragment，则需要在 Fragment#onPause 中调用该方法，该方法需要和 QiyuTracker#onResume 成对使用。
     *
     * @param fragment 当前页面
     * @param title 页面标题
     */
    public static void onPause(final Fragment fragment, final CharSequence title) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onPause(fragment, title);
                }
            }
        });
    }

    /**
     * 记录用户行为的方法
     * @param title  用户操作的类目是什么，可以是点击了收藏，可以是点击了查看，这个完全又客户端自己定义
     * @param jsonObject 用户操作的内容是什么，如果是商品，那么里面就是商品信息，如果是课程里面就是课程信息
     *                   如果不想传也是可以的
     */
    public static void onBehavior(final Activity activity, final String title, final JSONObject jsonObject){
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onBehavior(activity, title, jsonObject);
                }
            }
        });
    }

    /**
     * 记录用户行为的方法
     * @param title  用户操作的类目是什么，可以是点击了收藏，可以是点击了查看，这个完全又客户端自己定义
     * @param jsonObject 用户操作的内容是什么，如果是商品，那么里面就是商品信息，如果是课程里面就是课程信息
     *                   如果不想传也是可以的
     */
    public static void onBehavior(final Fragment fragment, final String title, final JSONObject jsonObject){
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onBehavior(fragment, title, jsonObject);
                }
            }
        });
    }

    /**
     * 记录用户行为的方法
     * @param title  用户操作的类目是什么，可以是点击了收藏，可以是点击了查看，这个完全又客户端自己定义
     * @param jsonObject 用户操作的内容是什么，如果是商品，那么里面就是商品信息，如果是课程里面就是课程信息
     *                   如果不想传也是可以的
     */
    public static void onBehavior(final androidx.fragment.app.Fragment fragment, final String title, final JSONObject jsonObject) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                if (Unicorn.isInit()) {
                    StatisticsManager.get().onBehavior(fragment, title, jsonObject);
                }
            }
        });
    }
}
