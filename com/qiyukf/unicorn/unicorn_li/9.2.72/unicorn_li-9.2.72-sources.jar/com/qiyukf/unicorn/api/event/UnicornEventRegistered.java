package com.qiyukf.unicorn.api.event;


import com.qiyukf.module.log.UnicornLog;
import com.qiyukf.unicorn.UnicornImpl;

/**
 * Describe:注册事件相应的 EventBase 类
 */
public class UnicornEventRegistered {
    private static final String TAG = "UnicornEventRegistered";
    /**
     * 注册事件处理的 UnicornEventBase 当又事件发生的时候，会从根据事件了类型拿到对应的 UnicornEventBase
     * @param eventType 事件的类型 0：请求客服事件 1：连接客服成功事件  2：注册自定义消息解析器的事件
     * @param unicornEventBase  处理该事件的 UnicornEventBase
     */
    public static void registerTypeForEvent(int eventType, UnicornEventBase unicornEventBase){
        try {
            if(UnicornImpl.isInitialized() && UnicornImpl.getOptions().sdkEvents != null){
                UnicornImpl.getOptions().sdkEvents.eventMap.append(eventType,unicornEventBase);
            }
        } catch (IllegalStateException e){
            UnicornLog.i(TAG,"regist event is not init", e);
        }

    }
}
