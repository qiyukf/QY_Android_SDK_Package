package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;


import android.content.Context;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.unicorn.Evaluation;
import com.qiyukf.unicorn.api.evaluation.EvaluationApi;
import com.qiyukf.unicorn.api.evaluation.entry.EvaluationOpenEntry;
import com.qiyukf.unicorn.protocol.attach.request.EvaluationAttachment;
import com.qiyukf.unicorn.session.SessionManager;


/**
 * 评价 viewholder 的基类，APP 方可通过继承该类，然后注册完成评价类型消息的自定义
 * 注意：该 viewholder 应该需要处理两种业务类型的消息：1、邀请用户评价  2、用户评价完成的提示语
 * 附：该类的基类中有大量方法，请自行查看
 */
public abstract class EvaluationViewHolderBase extends UnicornMessageViewHolder {

    /**
     * 该方法中提供了 Evaluation 中显示的全部信息，用户可以通过此信息设置 UI
     *
     * @param isEvaluate 判断是邀请评价的消息，还是评价完成的消息 true:评价完成的消息  false：邀请评价的消息
     * @param context
     * @param text       当 isEvaluate 为 true 的时候：该字段为评价完成将要展示的信息,这个时候需要调用
     *                   textView.setMovementMethod(LinkMovementMethod.getInstance()); 这个方法
     *                   当 isEvaluate 为 false 的时候：该字段为邀请评价的展示语
     */
    public abstract void bindEvaluationMsgView(Context context, boolean isEvaluate, CharSequence text);


    /**
     * 当有邀请评价事件的时候，评价按钮的点击事件可以调用该方法
     */
    public final void evaluationBtnClinck() {
        if (Evaluation.getInstance().getOnEvaluationEventListener() != null) {
            Evaluation.getInstance().getOnEvaluationEventListener().onEvaluationMessageClick(message);
        } else {
            SessionManager.getInstance().getEvaluationManager().showEvaluationDialog(context, message);
        }

        if (EvaluationApi.getInstance().getOnEvaluationEventListener() != null) {
            EvaluationAttachment attachment = (EvaluationAttachment) message.getAttachment();
            EvaluationApi.getInstance().getOnEvaluationEventListener().onEvaluationMessageClick(generateEntry(attachment), context);
        } else {
            SessionManager.getInstance().getEvaluationManager().showEvaluationDialog(context, message);
        }

    }

    private EvaluationOpenEntry generateEntry(EvaluationAttachment attachment) {

        EvaluationOpenEntry evaluationOpenEntry = new EvaluationOpenEntry();
        evaluationOpenEntry.setEvaluationEntryList(attachment.getEvaluationConfig().getEvaluationEntryList());
        evaluationOpenEntry.setExchange(message.getSessionId());
        evaluationOpenEntry.setLastRemark(attachment.getRemarks());
        evaluationOpenEntry.setLastSource(attachment.getEvaluation());
        evaluationOpenEntry.setSessionId(attachment.getSessionId());
        evaluationOpenEntry.setTitle(attachment.getEvaluationConfig().getTitle());
        evaluationOpenEntry.setType(attachment.getEvaluationConfig().getType());
        evaluationOpenEntry.setResolvedEnabled(attachment.getEvaluationConfig().getResolvedEnabled());
        evaluationOpenEntry.setResolvedRequired(attachment.getEvaluationConfig().getResolvedRequired());

        return evaluationOpenEntry;
    }

    @Override
    public final void bindContentView(IMMessage message, Context context) {
        EvaluationAttachment attachment = (EvaluationAttachment) message.getAttachment();
        boolean isEvaluated = attachment.isEvaluated();
        bindEvaluationMsgView(context, isEvaluated, attachment.getDisplayText());
    }

}
