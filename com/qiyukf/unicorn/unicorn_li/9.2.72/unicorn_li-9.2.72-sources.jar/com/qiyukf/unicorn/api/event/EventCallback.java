package com.qiyukf.unicorn.api.event;

/**
 * 事件回调的基类，当 APP 处理完成想要处理的事件之后，需要调用该
 *  callback 的 onProcessEventSuccess 方法通知 sdk 处理成功，
 *  可以进行接下来的流程
 */
public interface EventCallback<T> {

    /**
     * 处理事件成功回调的方法
     * @param t 处理该事件想要返回的数据
     */
    void onProcessEventSuccess(T t);

    /**
     * 处理事件失败回调的方法，当调用该方法之后 sdk 会忽
     * 略 app 对该事件的干扰继续进行接下来的流程
     */
    void onPorcessEventError();

    /**
     * 不对该事件进行处理，当 app 发现该事件不需要处理的
     * 时候，可以调用该方法告知 sdk 不需要处理该事件
     */
    void onNotPorcessEvent();

    /**
     * 当 APP 想拦截该事件的后续步骤可以调用该方法
     * 调用之后，事件的后续步骤将不再进行
     * 例如当请求客服的时候，如果你不想让 sdk 请求客服了，
     * 可以掉用该方法阻止 sdk 请求客服
     */
    void onInterceptEvent();
}
