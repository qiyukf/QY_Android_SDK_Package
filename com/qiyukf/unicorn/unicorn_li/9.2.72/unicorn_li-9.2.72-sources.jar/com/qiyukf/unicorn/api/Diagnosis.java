package com.qiyukf.unicorn.api;

import android.content.Context;

import com.qiyukf.nimlib.config.ServerConfig;
import com.qiyukf.unicorn.diagnose.DiagnoseImpl;
import com.qiyukf.unicorn.util.QiyuInitHandler;


/**
 * 仅供开发者在集成发生问题时调用，输出错误内容信息
 */

public class Diagnosis {

    /**
     * 开始诊断流程。诊断结果会输出到logcat，tag为Diagnose。
     * 同时，会把结果保存文件，文件路径为 "/sdcard/qiyu_diagnose_result.log"，调用该接口前，请确保有读写外部存储的权限。
     *
     * @param context 上下文
     */
    public static void start(final Context context) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                DiagnoseImpl.start(context);
            }
        });
    }

    /**
     * 调试接口，外部调用无效
     *
     * @param dev
     */
    public static void setDevServer(final int dev) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                ServerConfig.setDevServer(dev);
            }
        });
    }
}
