package com.qiyukf.unicorn.api.pop;

import android.content.Context;

/**
 * 商家事件监听器<br>
 * 包含：<br>
 * 商家入口点击事件<br>
 * 商家列表入口点击事件
 */
public abstract class OnShopEventListener {
    /**
     * 商家入口点击事件
     *
     * @param shopId 商家ID
     * @return true，如果已经处理该事件
     */
    public boolean onShopEntranceClick(Context context, String shopId) {
        return false;
    }

    /**
     * 商家列表入口点击事件
     *
     * @return true，如果已经处理该事件
     */
    public boolean onSessionListEntranceClick(Context context) {
        return false;
    }

    /**
     * 获取通知栏标题<br>
     * 如果需要根据不同商家展示不同的通知栏标题，请复写此方法。<br>
     * 如果不复写此方法或此方法返回 null
     *
     * @param shopId 商家ID
     * @return 通知栏标题
     */
    public String getNotificationTitle(Context context, String shopId) {
        return null;
    }
}
