package com.qiyukf.unicorn.api.lifecycle;

import java.io.Serializable;

/**
 * 对用户咨询会话的一些生命周期控制选项。通过这些选项，APP可以自定义是否允许用户主动结束会话，
 * 用户主动退出排队等开关，以及排队过程中用户按返回键的提示语，和界面退出的监听器等信息。
 */
public class SessionLifeCycleOptions implements Serializable {

    private boolean canQuitQueue;

    private boolean canCloseSession;

    private String quitQueuePrompt;

    private boolean canBackPrompt;

    private boolean canShowEvaluation;

    private transient SessionLifeCycleListener sessionLifeCycleListener;

    /**
     * 设置是否允许用户主动退出排队。
     * 设置该选项后，在排队状态下，右上角会有退出排队的入口。如果用户通过按返回键退出，会给出提示。
     * @param canQuitQueue 是否允许主动退出排队
     * @return this
     */
    public SessionLifeCycleOptions setCanQuitQueue(boolean canQuitQueue) {
        this.canQuitQueue = canQuitQueue;
        return this;
    }

    /**
     * 设置是否允许用户主动结束会话。
     * 设置该选项后，在会话状态下，右上角会有结束会话的入口。
     * @param canCloseSession 是否允许主动结束会话
     * @return this
     */
    public SessionLifeCycleOptions setCanCloseSession(boolean canCloseSession) {
        this.canCloseSession = canCloseSession;
        return this;
    }

    /**
     * 用户返回时弹出结束会话弹框时设置是否弹出满意度评价
     * @param canShowEvaluation 是否允许弹出满意度评价
     * @return this
     */
    public SessionLifeCycleOptions setCanShowEvaluation(boolean canShowEvaluation) {
        this.canShowEvaluation = canShowEvaluation;
        return this;
    }

    /**
     * 设置是否允许用户返回时弹出结束会话弹框
     * @param canBackPrompt 是否允许弹出返回弹框
     * @return this
     */
    public SessionLifeCycleOptions setCanBackPrompt(boolean canBackPrompt) {
        this.canBackPrompt = canBackPrompt;
        return this;
    }

    /**
     * 设置排队状态下，按返回键时给用户的提示语，提示用户是否要退出排队。
     *  注意： 该选项只有在 {@link #setCanQuitQueue(boolean)} 设置为 true 时才有效。
     * @param quitQueuePrompt 退出排队提示语
     * @return this
     */
    public SessionLifeCycleOptions setQuitQueuePrompt(String quitQueuePrompt) {
        this.quitQueuePrompt = quitQueuePrompt;
        return this;
    }

    /**
     * 设置会话界面关闭的监听器。
     * @param sessionLifeCycleListener 会话界面关闭的监听器
     * @return this
     */
    public SessionLifeCycleOptions setSessionLifeCycleListener(SessionLifeCycleListener sessionLifeCycleListener) {
        this.sessionLifeCycleListener = sessionLifeCycleListener;
        return this;
    }

    public boolean canQuitQueue() {
        return canQuitQueue;
    }

    public boolean canCloseSession() {
        return canCloseSession;
    }

    public boolean canBackPrompt() {
        return canBackPrompt;
    }

    public boolean canShowEvaluation() {
        return canShowEvaluation;
    }

    public String getQuitQueuePrompt() {
        return quitQueuePrompt;
    }

    public SessionLifeCycleListener getSessionLifeCycleListener() {
        return sessionLifeCycleListener;
    }
}
