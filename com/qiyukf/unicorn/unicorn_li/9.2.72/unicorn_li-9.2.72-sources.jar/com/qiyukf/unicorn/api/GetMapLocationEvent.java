package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 地图选点获取位置
 */
public interface GetMapLocationEvent {

    /**
     * onActivityResult通过requestCode接收返回的位置信息
     * @param context
     * @param requestCode
     * @return
     */
    boolean onEvent(Context context, int requestCode);
}
