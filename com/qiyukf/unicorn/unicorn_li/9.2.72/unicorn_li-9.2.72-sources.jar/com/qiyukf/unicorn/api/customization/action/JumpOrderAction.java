package com.qiyukf.unicorn.api.customization.action;

import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.ShowGoodsEvent;
import com.qiyukf.unicorn.api.ShowOrderEvent;

public class JumpOrderAction extends BaseAction {
   public JumpOrderAction(int iconResId, int titleId) {
      super(iconResId, titleId);
   }

   public JumpOrderAction(String imageUrl, String title) {
      super(imageUrl, title);
   }

   public JumpOrderAction(int iconResId, String title) {
      super(iconResId, title);
   }

   @Override
   public void onClick() {
      ShowOrderEvent showOrderEvent = UnicornImpl.getOptions().showOrderEvent;
      if (showOrderEvent != null) {
         showOrderEvent.onEvent(getActivity());
      }
   }
}
