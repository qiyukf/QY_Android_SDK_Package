package com.qiyukf.unicorn.api;

import java.io.Serializable;

/**
 * 由于用户咨询客服并不是一个高频操作，在咨询客服时，SDK会保持长连接以便及时收到推送。当咨询结束后，长连接不再有必要，频繁定时的心跳会造成不必要的电量消耗。但由于客服也可以主动发起同用户的会话，因此 SDK 还是需要定时查看是否有未读消息。<br>
 *     因此，七鱼 SDK 提供了该配置项，用于 APP 在电量消耗和消息及时性间自主选择平衡。
 *     <p>当用户咨询客服会话结束后，长连接会持续 activeDelay 秒长时间，然后转入省电模式。根据用户配置，省电模式又分两种状态：</p>
 *     <p>1. 推送模式：用户需要在七鱼的管理后台配置推送服务器，且此处 customPush 设置为 true。此时，如果有新消息，会自动转到后台配置的推送通道上。由于推送不受SDK控制，因此收到推送后 SDK 不会自动建立长连接，需要用户进入咨询界面后，才会建立长连接。</p>
 *     <p>2. 轮询模式：SDK 每隔 checkInterval 秒去服务器检测一次有没有新消息。如果有新消息，会自动建立长连接，并收取新消息，弹出通知。</p>
 *
 */
public class SavePowerConfig implements Serializable {

    /**
     * APP 是否自己已经集成了推送服务。<br>
     *     <p>如果此处为 true，且在七鱼后台 APP 设置处添加了推送地址，则有新消息时使用推送通道下发到 APP。</p>
     *     <p>如果此处为 false，则无论后台 APP 设置处是否添加了推送地址，均使用轮询模式检查是否有新消息。</p>
     */
    public boolean customPush;

    /**
     * 用户结束同客服的会话后，再延后 activeDelay 毫秒时间内仍然没有同客服有过会话，SDK 会转入省电模式。<br>
     *     单位：秒<br>
     *     默认值：3 * 24 * 3600 （3天）
     */
    public long activeDelay;

    /**
     * 进入省电模式后，定时拉取有没有新消息的时间间隔.<br>
     *     单位：秒<br>
     *     默认值：3600 （1小时）
     */
    public long checkInterval;

    /**
     * 如果 APP 有自己的推送服务，并在管理后台的 APP集成设置里设置了需要推送，七鱼有新消息推送给 APP 的推送服务器时，推送内容(json格式)中会包含该参数。<br>
     *     推送消息的格式为：
     */
    public String deviceIdentifier;

    public SavePowerConfig() {
        this(false, 3 * 24 * 3600, 3600);
    }

    public SavePowerConfig(boolean customPush, long activeDelay, long checkInterval) {
        this.customPush = customPush;
        this.activeDelay = activeDelay;
        this.checkInterval = checkInterval;
    }
}
