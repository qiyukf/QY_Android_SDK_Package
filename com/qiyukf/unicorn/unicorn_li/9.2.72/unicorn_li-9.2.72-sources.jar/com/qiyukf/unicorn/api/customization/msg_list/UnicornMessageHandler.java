package com.qiyukf.unicorn.api.customization.msg_list;

import android.content.Context;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;

/**
 * 在某些场景下，七鱼对于特定消息类型的处理并不适合所有的 app，该接口提供了让 app 自定义处理这些消息
 * 类型的能力。
 *
 * 开发者可以在 {@link MsgCustomizationRegistry#registerMessageHandlerFactory(MessageHandlerFactory)}  注
 * 册 Factory,然后在 Factory 的 handlerOf 方法中返回此类
 */

public interface UnicornMessageHandler {

    /**
     * 当注册了对应类型的消息需要展示时，会调用该方法供 app 自定义消息的处理逻辑。
     * @param context: 消息流所在的上下文
     * @param message：你将要处理的 message ，通过 message.getAttachment 可以拿到你注册的 attachment
     * @param handledOnce：以前是否已经成功处理过该消息，有些活动只需要处理一次，例如一条订单消息只需要弹一次订单，所以可以根据这个参数去判断
     *                 是否弹订单列表
     * @return  如果此条消息处理成功，那么返回 true，如果没有处理成功返回 false，当返回 true 的时候，下次这条消息的 handledOnce 会变为 true
     */
    boolean onMessage(Context context, IMMessage message, boolean handledOnce);

}
