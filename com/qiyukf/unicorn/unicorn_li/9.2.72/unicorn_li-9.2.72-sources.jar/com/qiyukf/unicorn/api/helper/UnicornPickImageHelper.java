package com.qiyukf.unicorn.api.helper;

import android.app.Activity;
import android.content.Intent;

import com.qiyukf.nimlib.util.StringUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.uikit.session.activity.PickImageActivity;
import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.uikit.session.helper.SendImageHelper;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 * fragment 接入方式用户使用 SDK 中拍摄照片和选择照片的帮助类，通过该类可以启动
 * SDK 中的选择照片和拍摄照片的界面，并将回调的数据通过该类提供的方法进行处理，达到
 * 发送图片消息的效果
 */
public class UnicornPickImageHelper {

    private Activity activity;
    private SendImageCallback callback;

    public interface SendImageCallback {
        void sendImage(File file, String origName, boolean isOrig);
    }

    public UnicornPickImageHelper(Activity activity, SendImageCallback callback) {
        this.activity = activity;
        this.callback = callback;
    }

    public void goUnicornAlbum(final int requestCode) {
        if (activity == null || callback == null) {
            return;
        }
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(activity, PermissionsConstant.goAlbum)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.goAlbum);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_SELECT_IMAGE);
                eventEntry.setPermissionList(permissionList);
                unicornEventBase.onEvent(eventEntry, activity, new EventCallback() {
                    @Override
                    public void onProcessEventSuccess(Object o) {
                        checkPermissionAndGoAlbum(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onPorcessEventError() {
                        checkPermissionAndGoAlbum(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onNotPorcessEvent() {
                        checkPermissionAndGoAlbum(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onInterceptEvent() {
                        ToastUtil.showToast(R.string.ysf_no_permission_photo);
                    }
                });
            } else {
                checkPermissionAndGoAlbum(requestCode, null, null);
            }
        } else {
            checkPermissionAndGoAlbum(requestCode, null, null);
        }
    }

    public void onAlbumResult(Intent data) {
        if (activity == null || callback == null || data == null) {
            return;
        }
        SendImageHelper.onPickImageActivityResult(activity, data, RequestCode.PREVIEW_IMAGE_FROM_CAMERA, new SendImageHelper.Callback() {
            @Override
            public void sendImage(File file, String origName, boolean isOrig) {
                if (callback != null) {
                    callback.sendImage(file, origName, isOrig);
                }
            }
        });
    }


    public void goUnicornCapturePhoto(final int requestCode) {
        if (activity == null || callback == null) {
            return;
        }
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(activity, PermissionsConstant.cameraAndRedFile)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.cameraAndRedFile);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_TAKE_PHOTO);
                eventEntry.setPermissionList(permissionList);
                unicornEventBase.onEvent(eventEntry, activity, new EventCallback() {
                    @Override
                    public void onProcessEventSuccess(Object o) {
                        checkPermissionAndGoCapture(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onPorcessEventError() {
                        checkPermissionAndGoCapture(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onNotPorcessEvent() {
                        checkPermissionAndGoCapture(requestCode, unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onInterceptEvent() {
                        ToastUtil.showToast(R.string.ysf_no_permission_camera);
                    }
                });
            } else {
                checkPermissionAndGoCapture(requestCode, null, null);
            }
        } else {
            checkPermissionAndGoCapture(requestCode, null, null);
        }
    }

    public void onCapturePhotoResult(Intent data, int requestCode) {
        if (activity == null || callback == null || data == null) {
            return;
        }
        SendImageHelper.onPickImageActivityResult(activity, data, requestCode, new SendImageHelper.Callback() {
            @Override
            public void sendImage(File file, String origName, boolean isOrig) {
                if (callback == null) {
                    return;
                }
                callback.sendImage(file, origName, isOrig);
            }
        });
    }

    public void onCapturePhotoPorcessResult(Intent data, int reTakeCode) {
        if (activity == null || callback == null) {
            return;
        }
        SendImageHelper.onPreviewImageActivityResult(activity, data, RequestCode.PREVIEW_IMAGE_FROM_CAMERA, reTakeCode, new SendImageHelper.Callback() {
            @Override
            public void sendImage(File file, String origName, boolean isOrig) {
                if (callback == null) {
                    return;
                }
                callback.sendImage(file, origName, isOrig);
            }
        });
    }


    private String tempFile() {
        String filename = StringUtil.get32UUID() + ".jpg";
        return YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_TEMP);
    }

    private void checkPermissionAndGoAlbum(int requestCode, UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(activity)
                .permissions(PermissionsConstant.goAlbum)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        int from = PickImageActivity.FROM_LOCAL;
                        PickImageActivity.start(activity, requestCode, from, tempFile(), true, 9, false, false, 0, 0);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(activity, eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_photo);
                        }
                    }
                })
                .request();
    }

    private void checkPermissionAndGoCapture(int requestCode, UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(activity)
                .permissions(PermissionsConstant.cameraAndRedFile)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        int from = PickImageActivity.FROM_CAMERA;
                        PickImageActivity.start(activity, requestCode, from, tempFile(), true, 1, false, false, 0, 0);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(activity, eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_camera);
                        }
                    }
                })
                .request();
    }


}
