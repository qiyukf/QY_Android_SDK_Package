package com.qiyukf.unicorn.api;

import android.content.Context;

public interface ShowGoodsEvent {

   void onEvent(Context context);

}
