package com.qiyukf.unicorn.api.customization.action;

import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.ShowGoodsEvent;

public class JumpGoodsAction extends BaseAction {
   public JumpGoodsAction(int iconResId, int titleId) {
      super(iconResId, titleId);
   }

   public JumpGoodsAction(String imageUrl, String title) {
      super(imageUrl, title);
   }

   public JumpGoodsAction(int iconResId, String title) {
      super(iconResId, title);
   }

   @Override
   public void onClick() {
      ShowGoodsEvent showGoodsEvent = UnicornImpl.getOptions().showGoodsEvent;
      if (showGoodsEvent != null) {
         showGoodsEvent.onEvent(getActivity());
      }
   }
}
