package com.qiyukf.unicorn.api.evaluation.entry;


import java.io.Serializable;
import java.util.List;

/**
 * Describe: 满意度评价事件传递给 App 端的 entry
 */
public class EvaluationOpenEntry implements Serializable {

    /**
     * 评价的场景 0：人工 1：机器人
     */
    private int evaluatorScenes;

    /**
     * 上次评价的分数，首次评价该值为 -1，再次评价的时候该值为上次评价的值
     */
    private int lastSource = -1;

    /**
     * 上次评价的备注，首次评价备注为 null，再次评价时为上次评价的备注
     */
    private String lastRemark;

    /**
     * 用户的 shopId ，App 方只需要在评价结束之后回传给 SDK 就可以了
     */
    private String exchange;

    /**
     * 会话的 id ，App 方只需要回传给 SDK 就可以了
     */
    private long sessionId;

    /**
     * 满意度评价的 title 就是邀请用户评价的文案
     */
    private String title;

    /**
     * 满意度级别类型
     * 该值只能是 2(二级评价模式，该模式下只有两个选项，该模式下取 evaluationEntryList 中的 0、1 就可以了)、3(三级评价模式，该模式下只有
     * 3 个选项，该模式下去取 evaluationEntryList 中的 0、1、2就可以了 )、5(五级评价模式，该模式下有五个选项，该模式下去取 evaluationEntryList 中的 0、1、2、3、4就可以了)
     * 具体对应关系可以查看 web 端客服工作台满意度评价设置里面的 满意度评价方案就可以了
     */
    private int type;

    /**
     * 问题是否解决选项是否开启 0-停用，1-开启'
     */
    private int resolvedEnabled;

    /**
     * 问题是否解决是否为必填 0 不必填、1 必填
     */
    private int resolvedRequired;

    /**
     * 满意度选项集合信息，具体请查看 EvaluationOptionEntry 类
     */
    private List<EvaluationOptionEntry> evaluationEntryList;


    public int getEvaluatorScenes() {
        return evaluatorScenes;
    }

    public void setEvaluatorScenes(int evaluatorScenes) {
        this.evaluatorScenes = evaluatorScenes;
    }

    public int getLastSource() {
        return lastSource;
    }

    public void setLastSource(int lastSource) {
        this.lastSource = lastSource;
    }

    public String getLastRemark() {
        return lastRemark;
    }

    public void setLastRemark(String lastRemark) {
        this.lastRemark = lastRemark;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public long getSessionId() {
        return sessionId;
    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public List<EvaluationOptionEntry> getEvaluationEntryList() {
        return evaluationEntryList;
    }

    public void setEvaluationEntryList(List<EvaluationOptionEntry> evaluationEntryList) {
        this.evaluationEntryList = evaluationEntryList;
    }

    public int getResolvedEnabled() {
        return resolvedEnabled;
    }

    public void setResolvedEnabled(int resolvedEnabled) {
        this.resolvedEnabled = resolvedEnabled;
    }

    public int getResolvedRequired() {
        return resolvedRequired;
    }

    public void setResolvedRequired(int resolvedRequired) {
        this.resolvedRequired = resolvedRequired;
    }
}
