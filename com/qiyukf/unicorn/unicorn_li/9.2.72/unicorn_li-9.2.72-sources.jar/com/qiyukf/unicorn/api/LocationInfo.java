package com.qiyukf.unicorn.api;

public class LocationInfo {

    /**
     * 经度
     */
    public double longitude;

     /**
      * 纬度
      */
    public double latitude;


}
