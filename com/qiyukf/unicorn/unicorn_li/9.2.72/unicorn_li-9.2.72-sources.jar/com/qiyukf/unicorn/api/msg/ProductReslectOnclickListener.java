package com.qiyukf.unicorn.api.msg;

import android.content.Context;

import java.io.Serializable;

/**
 * 商品消息重新选择点击事件
 * 可以在 productDetail 中指定该变量
 */
public interface ProductReslectOnclickListener extends Serializable {

    /**
     * 当点击商品中的重新选择按钮的话会调用此事件
     * @param handlerTag 在商品信息中标志哪个事件发送的商品
     */
    void onClick(Context context, String handlerTag);
}
