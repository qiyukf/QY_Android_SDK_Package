package com.qiyukf.unicorn.api;

import android.content.Context;

public interface ShowOrderEvent {

   void onEvent(Context context);

}
