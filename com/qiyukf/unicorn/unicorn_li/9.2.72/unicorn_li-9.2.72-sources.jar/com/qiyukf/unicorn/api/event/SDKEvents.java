package com.qiyukf.unicorn.api.event;

import android.util.SparseArray;

import java.io.Serializable;

/**
 * sdk 中自定义处理事件的配置类
 */
public class SDKEvents implements Serializable {

    /**
     * 事件的自定义对象
     */
    public transient EventProcessFactory eventProcessFactory;

    /**
     * 事件的对应关系 map
     * 可以通过 UnicornEventRegistered.registerTypeForEvent 方法注册到这个 map 中
     */
    public transient SparseArray<UnicornEventBase> eventMap = new SparseArray();



}
