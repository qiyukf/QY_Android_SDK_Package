package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import com.qiyukf.nimlib.util.StringUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.uikit.common.media.picker.model.PhotoInfo;
import com.qiyukf.uikit.session.activity.PickImageActivity;
import com.qiyukf.uikit.session.constant.Extras;
import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.uikit.session.helper.SendImageHelper;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.api.msg.MessageService;
import com.qiyukf.unicorn.fileselect.FilePicker;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;

import java.util.ArrayList;
import java.util.List;
import com.qiyukf.unicorn.util.SDKhelper;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;
import com.qiyukf.unicorn.widget.dialog.LocationPermissionTipDialog;

import java.io.File;
import java.util.Arrays;

/**
 * Created by andya on 2018/7/10.
 * 相册 action
 */


public class AlbumAction extends BaseAction {

    int actionFontColor = 0;

    /**
     * 构造函数
     *
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public AlbumAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId 图标标题的 String
     */
    public AlbumAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId 图标标题的 String
     */
    public AlbumAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    @Override
    public void onClick() {
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(getFragment().getContext(), PermissionsConstant.goAlbum)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.goAlbum);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_SELECT_IMAGE);
                eventEntry.setPermissionList(permissionList);

                unicornEventBase.onEvent(eventEntry, getFragment().getContext(), new EventCallback() {
                    @Override
                    public void onProcessEventSuccess(Object o) {
                        checkPermissionAndGoAlbum(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onPorcessEventError() {
                        checkPermissionAndGoAlbum(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onNotPorcessEvent() {
                        checkPermissionAndGoAlbum(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onInterceptEvent() {
                        ToastUtil.showLongToast(R.string.ysf_no_permission_photo);
                    }
                });
            } else {
                checkPermissionAndGoAlbum(null, null);
            }
        } else {
            checkPermissionAndGoAlbum(null, null);
        }
    }

    private String tempFile() {
        String filename = StringUtil.get32UUID() + ".jpg";
        return YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_TEMP);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RequestCode.PICK_IMAGE:
                // 通过 PickImageActivity 在结果 intent 中回传的标记判定本次是否为"重新打开相册"流程。
                // 这样即使 AlbumAction 实例被复用、preSelectedPhotos 字段被异常路径残留也不会污染本次判定。
                final boolean replaceMode = data != null && data.getBooleanExtra(Extras.EXTRA_PICK_REPLACE_MODE, false);
                try {
                    if (getPendingMediaCallback() != null && data != null) {
                        // 预览模式：将选图结果回传给 InputPanel，不直接发送
                        boolean isOrig = data.getBooleanExtra(Extras.EXTRA_IS_ORIGINAL, false);
                        List<PhotoInfo> photos = SendImageHelper.getPhotos(data);
                        if (photos == null) {
                            photos = new ArrayList<>();
                        }
                        // replaceMode 时即使 photos 为空也要回调，让 InputPanel 清空已有图片项
                        if (replaceMode || !photos.isEmpty()) {
                            getPendingMediaCallback().onPhotosSelected(photos, isOrig, replaceMode);
                        }
                    } else {
                        SendImageHelper.onPickImageActivityResult(getFragment(), data, makeRequestCode(RequestCode.PREVIEW_IMAGE_FROM_CAMERA), callback);
                    }
                } finally {
                    // 无论结果如何，恢复默认上限并清空预选，避免下次正常打开相册时被污染
                    multiSelectLimitSize = 9;
                    preSelectedPhotos = null;
                }
                break;
            case RequestCode.PREVIEW_IMAGE_FROM_CAMERA:
                if (getPendingMediaCallback() != null && data != null) {
                    // 拍照预览完成后回传（AlbumAction 通常不走此分支，保险起见处理）
                    boolean isOrig = data.getBooleanExtra(Extras.EXTRA_IS_ORIGINAL, false);
                    List<PhotoInfo> photos = SendImageHelper.buildPhotosFromCameraResult(data);
                    if (photos != null && !photos.isEmpty()) {
                        // 拍照流程总是追加，replace=false
                        getPendingMediaCallback().onPhotosSelected(photos, isOrig, false);
                    }
                } else {
                    SendImageHelper.onPreviewImageActivityResult(getFragment(), data, requestCode, makeRequestCode(RequestCode.PICK_IMAGE), callback);
                }
                break;
        }
    }

    private SendImageHelper.Callback callback = new SendImageHelper.Callback() {
        @Override
        public void sendImage(File file, String origName, boolean isOrig) {
            MessageService.sendMessage(buidlImageMessage(file));
        }
    };

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     *
     * @param actionFontColor
     */

    public void setActionFontColor(int actionFontColor) {
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        } else {
            return actionFontColor;
        }
    }

    private int multiSelectLimitSize = 9;

    /**
     * 已经在输入框预览条中的图片列表，用于打开相册时复显勾选态。
     * 由 InputPanel.addMoreImages() 在调用 onClick 之前注入。
     */
    private transient List<PhotoInfo> preSelectedPhotos;

    /**
     * 设置相册多选上限，用于预览条"继续添加"场景。
     */
    public void setMultiSelectLimitSize(int size) {
        this.multiSelectLimitSize = size;
    }

    /**
     * 设置已选中图片列表（用于复显勾选态）。
     * 仅在重新打开相册时由 InputPanel 调用。
     */
    public void setPreSelectedPhotos(List<PhotoInfo> selected) {
        this.preSelectedPhotos = selected;
    }

    private void checkPermissionAndGoAlbum(UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        final int requestCode = makeRequestCode(RequestCode.PICK_IMAGE);
        // 把已经在预览条中的图片透传给相册，复显勾选态。
        // 一次性消费——这里取出后立即置空，避免用户取消选择后再次打开相册时被脏数据污染。
        final List<PhotoInfo> selectedSnapshot = preSelectedPhotos;
        preSelectedPhotos = null;
        PermissionReq.with(getFragment())
                .permissions(PermissionsConstant.goAlbum)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        int from = PickImageActivity.FROM_LOCAL;
                        PickImageActivity.start(getFragment(), requestCode, from, tempFile(), true,
                                multiSelectLimitSize, false, false, 0, 0, selectedSnapshot);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(getFragment().getContext(), eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_photo);
                        }
                    }
                })
                .request();
    }

}
