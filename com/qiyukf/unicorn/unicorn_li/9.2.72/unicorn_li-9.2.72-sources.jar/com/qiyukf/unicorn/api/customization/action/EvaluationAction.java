package com.qiyukf.unicorn.api.customization.action;


import com.qiyukf.nimlib.sdk.RequestCallbackWrapper;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.api.event.EventService;
import com.qiyukf.unicorn.util.ToastUtil;

/**
 * Created by andya on 2019-07-29
 * Describe: 评价 action
 */
public class EvaluationAction extends BaseAction {

    int actionFontColor = 0;

    /**
     * 构造函数
     *
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public EvaluationAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId   图标标题的 String
     */
    public EvaluationAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId   图标标题的 String
     */
    public EvaluationAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    @Override
    public void onClick() {
        EventService.openEvaluation(getActivity(), getAccount(), new RequestCallbackWrapper() {
            @Override
            public void onResult(int code, Object result, Throwable exception) {
                ToastUtil.showToast(R.string.ysf_evaluation_success);
            }
        });
    }

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     * @param actionFontColor
     */

    public void setActionFontColor(int actionFontColor){
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        }else {
            return actionFontColor;
        }
    }
}
