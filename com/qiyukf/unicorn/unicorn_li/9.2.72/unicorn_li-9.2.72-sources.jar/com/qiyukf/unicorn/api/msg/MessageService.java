package com.qiyukf.unicorn.api.msg;

import com.qiyukf.nimlib.sdk.NIMClient;
import com.qiyukf.nimlib.sdk.msg.constant.MsgStatusEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.nimlib.sdk.ysf.YsfService;
import com.qiyukf.nimlib.util.JSONHelper;
import com.qiyukf.unicorn.api.LocationInfo;
import com.qiyukf.unicorn.api.ProductDetail;
import com.qiyukf.unicorn.api.msg.attachment.ProductAttachment;
import com.qiyukf.unicorn.protocol.attach.constant.Tags;
import com.qiyukf.unicorn.protocol.attach.constant.YsfCmd;
import com.qiyukf.unicorn.protocol.attach.notification.CardMessageAttachment;
import com.qiyukf.unicorn.protocol.attach.notification.ReportGeographicInformationAttachment;
import com.qiyukf.unicorn.session.SessionHelper;
import com.qiyukf.unicorn.session.SplitMessageManager;

import org.json.JSONObject;

/**
 * 为消息提供服务的类，此类可以发送消息
 * 之后可能会进行拓展消息相关的功能
 */
public class MessageService {

    /**
     * 发送消息的接口
     *
     * @param message 要发送的消息
     */
    public static void sendMessage(IMMessage message) {
        SessionHelper.sendMessage(message);
    }

    /**
     * 把消息存储本地的方法，调用该方法之后，本条消息只能访客看到
     * 客服看不到
     *
     * @param message  即将存储的消息
     * @param isNotify 是否通知
     * @param isSaveDB 是否将消息存储到数据库
     */
    public static void saveMessageToLocal(IMMessage message, boolean isNotify, boolean isSaveDB) {
        SessionHelper.saveMessageToLocal(message, isNotify, isSaveDB);
    }

    /**
     * 非平台企业发送商品信息
     *
     * @param productDetail productDetail
     */
    public static void sendProductMessage(ProductDetail productDetail) {
        sendProductMessage(SessionHelper.getDefaultSessionId(), productDetail);
    }

    /**
     * 发送商品信息到 shopId 指定的商户
     *
     * @param shopId        商户 id 非平台企业为 -1
     * @param productDetail productDetail
     */
    public static void sendProductMessage(String shopId, ProductDetail productDetail) {
        ProductAttachment productAttachment = new ProductAttachment();
        productAttachment.fromProductDetail(productDetail, false);
        if (productAttachment.getSendByUser() == 1) {
            productAttachment.setSendByUser(0);     //当调用这个接口的时候是不希望看到手动发送的相关内容的
        }
        if (productAttachment.getShow() == 1) {
            IMMessage message = UnicornMessageBuilder.buildCustomMessage(shopId, productAttachment);
            message.setStatus(MsgStatusEnum.success);
            SessionHelper.sendMessage(message);
        } else {
            SessionHelper.sendCustomNotification(productAttachment, shopId);
        }
    }

    /**
     * 非平台企业自动发送卡片信息
     *
     * @param cardJson 卡片消息详情json
     */
    public static void sendCardMessage(String cardJson) {
        sendCardMessage(SessionHelper.getDefaultSessionId(), cardJson, 0, "", "");
    }

    /**
     * 非平台企业发送卡片信息
     *
     * @param cardJson        卡片消息详情json
     * @param sendByUser      是否自动进线, 0 进线自动发送, 1 手动发送  默认0
     * @param actionText      发送按钮文案
     * @param actionTextColor 发送按钮颜色
     */
    public static void sendCardMessage(String cardJson, int sendByUser, String actionText, String actionTextColor) {
        sendCardMessage(SessionHelper.getDefaultSessionId(), cardJson, sendByUser, actionText, actionTextColor);
    }

    /**
     * 非平台企业发送卡片信息
     *
     * @param shopId          商户 id 非平台企业为 -1
     * @param cardJson        卡片消息详情json
     * @param sendByUser      是否自动进线, 0 进线自动发送, 1 手动发送  默认0
     * @param actionText      发送按钮文案
     * @param actionTextColor 发送按钮颜色
     */
    public static void sendCardMessage(String shopId, String cardJson, int sendByUser, String actionText, String actionTextColor) {
        CardMessageAttachment cardMessageAttachment = new CardMessageAttachment();
        cardMessageAttachment.setCardJson(cardJson);
        cardMessageAttachment.setSendByUser(sendByUser);
        cardMessageAttachment.setActionText(actionText);
        cardMessageAttachment.setActionTextColor(actionTextColor);
        IMMessage message = UnicornMessageBuilder.buildCustomMessage(shopId, cardMessageAttachment);
        message.setStatus(MsgStatusEnum.success);
        NIMClient.getService(YsfService.class).saveMessageToLocal(message, true);
        JSONObject cardJsonobject = JSONHelper.parse(cardJson);
        if (cardJsonobject == null || sendByUser == 1) {
            return;
        }
        JSONHelper.put(cardJsonobject, Tags.CMD, YsfCmd.CARD_MESSAGE);
        SplitMessageManager.get().sendSplitMessage(shopId, cardJsonobject.toString(), message);
    }

    /**
     * 发送理想H5回传消息的接口
     *
     * @param text 回传的消息
     */
    public static void sendWorkSheetMessage(String text) {
        SessionHelper.sendWorkSheetMessage(text);
    }

    /**
     * 发送位置信息
     */
    public static void sendLocationMessage(long sessionId, LocationInfo locationInfo) {
        if (locationInfo != null) {
            ReportGeographicInformationAttachment reportGeographicInformationAttachment = new ReportGeographicInformationAttachment();
            reportGeographicInformationAttachment.setSessionId(sessionId);
            reportGeographicInformationAttachment.setLongitude(locationInfo.longitude);
            reportGeographicInformationAttachment.setLatitude(locationInfo.latitude);
            SessionHelper.sendCustomNotification(reportGeographicInformationAttachment, SessionHelper.getDefaultSessionId());
        }
    }
}
