package com.qiyukf.unicorn.api.lifecycle;

/**
 * 会话界面退出监听器<br>
 * 仅在使用 Fragment 集成时需要处理，如果使用 Activity 集成则无需处理。<br>
 * 如果需要在用户退出排队时给予挽留提示，则需要在宿主 Activity 触发 onBackPressed 时调用 ServiceMessageFragment 的 onBackPressed 方法，
 * 只有当 Fragment 的 onBackPressed 方法返回为 false 时，才能调用 Activity 的 onBackPressed。示例代码<br>
 * <pre>
 * public class ServiceMessageActivity extends Activity {
 *     public void onBackPressed() {
 *         if (!messageFragment.onBackPressed()) {
 *             super.onBackPressed();
 *         }
 *     }
 * }
 * </pre>
 * 如果给予提示后用户仍然选择退出排队，则会回调{@link #onLeaveSession()}，开发者需要在回调中关闭 Fragment 。
 */
public interface SessionLifeCycleListener {

    /**
     * 用户主动离开客服咨询界面，此时需要关闭 Fragment 。<br>
     */
    void onLeaveSession();
}
