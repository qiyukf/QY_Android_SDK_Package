package com.qiyukf.unicorn.api.customization.input;

import com.qiyukf.unicorn.api.customization.action.BaseAction;

import java.util.List;

/**
 * create by andya on 2018/7/10
 * 接入方使用更多菜单需要实现的接口，通过这个接口可以获取 actionList
 */


public interface ActionListProvider {

    /**
     * @return 返回"+" 里面需要展示的 action 集合
     */
    List<BaseAction> getActionList();

}
