package com.qiyukf.unicorn.api;


import com.qiyukf.unicorn.model.IQuickEntry;

/**
 * 快捷入口
 */
public class QuickEntry implements IQuickEntry {
    /**
     * 入口ID
     */
    private long id;
    /**
     * 入口名字
     */
    private String name;
    /**
     * [可选] 入口 icon url ，支持的 url 类型由 ImageLoader 决定
     */
    private String iconUrl;

    public QuickEntry(long id, String name, String iconUrl) {
        this.id = id;
        this.name = name;
        this.iconUrl = iconUrl;
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public boolean isHighLight() {
        return false;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }
}
