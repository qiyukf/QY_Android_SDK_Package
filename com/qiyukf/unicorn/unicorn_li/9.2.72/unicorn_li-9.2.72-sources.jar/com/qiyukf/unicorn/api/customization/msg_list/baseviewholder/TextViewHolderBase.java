package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;

import android.content.Context;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.uikit.session.emoji.MoonUtil;
import com.qiyukf.uikit.session.helper.SpanUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.protocol.attach.constant.ExtTags;
import com.qiyukf.unicorn.session.SessionHelper;

/**
 * 如果想实现 Text 文本的自定义，请实现改抽象类的方法，然后再通过
 * MsgCustomizationRegistry.registerMessageViewHolder 去注册
 * 该 viewHolder ，这样就能达成自定义 text 文本消息的目的
 * 附：该类的基类中有大量方法，请自行查看
 */

public abstract class TextViewHolderBase extends UnicornMessageViewHolder {


    @Override
    public final void bindContentView(IMMessage message, Context context){
        CharSequence text;
        String webButtonText = null;
        String webJumpUrl = null;
        if (SessionHelper.getExtensionType(message) == ExtTags.TYPE_PUSH) {
            text = MoonUtil.replaceEmoticonAndATags(context, message.getContent(), message.getSessionId());
        } else {
            text = MoonUtil.replaceEmoticons(context, message.getContent());
        }
        text = SpanUtil.replaceWebLinks(context, text);

        if (message.getRemoteExtension() != null) {
            if (message.getRemoteExtension().get("action") != null) {
                webButtonText = (String)message.getRemoteExtension().get("action");
            } else {
                webButtonText = context.getString(R.string.ysf_know_str);
            }

            if (message.getRemoteExtension().get("url") != null) {
                webJumpUrl = (String) message.getRemoteExtension().get("url");
            }
        }
        bindTextMsgView(context,text,webButtonText,webJumpUrl);
    }

    /**
     * 该方法中提供了 textmessage 中显示的全部信息，用户可以通过此信息设置 UI
     * @param text textmessage 需要显示的 text 内容  别忘记设置 linktextcolor，如果要是设置点击事件
     *             请设置 onTouchListener
     * @param webButtonText  因为我们存在推送消息，推送消息下面是有跳转按钮的，该字段为按钮应该显示的文本
     * @param webJumpUrl  该字段为按钮跳转的 url
     * 注意：如果 webJumpUrl 字段为空，那么就不需要显示跳转按钮
     */
    public abstract void bindTextMsgView(Context context,CharSequence text,String webButtonText,String webJumpUrl);

}
