package com.qiyukf.unicorn.api.customization.action;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;

import androidx.fragment.app.Fragment;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.uikit.session.module.Container;
import com.qiyukf.uikit.session.module.input.PendingMediaCallback;
import com.qiyukf.unicorn.api.msg.UnicornMessageBuilder;

import java.io.File;
import java.io.Serializable;

/**
 * created by andya on 2018/7/5.
 * 接入方 Action 的基类
 * 注意：在子类中调用startActivityForResult时，requestCode必须用makeRequestCode封装一遍，否则不能再onActivityResult中收到结果。
 * requestCode仅能使用最低8位。
 */
public abstract class BaseAction implements Serializable {

    private int iconResId;

    private int titleId;

    private String imageUrl;

    private String title;

    private transient int index;
    private transient Container container;
    private transient PendingMediaCallback pendingMediaCallback;

    /**
     * 构造函数
     * @param iconResId 图标 res id
     * @param titleId 图标标题的string res id
     */
    public BaseAction(int iconResId, int titleId) {
        this.iconResId = iconResId;
        this.titleId = titleId;
    }

    /**
     * 构造函数
     * @param imageUrl 图标的 imageurl
     * @param title 图标标题的string
     */
    public BaseAction(String imageUrl, String title) {
        this.title = title;
        this.imageUrl = imageUrl;
    }

    /**
     * 构造函数
     * @param iconResId 图标的 res id
     * @param title 图标标题的string
     */
    public BaseAction(int iconResId, String title) {
        this.title = title;
        this.iconResId = iconResId;
    }

    /**
     * 获取聊天窗口所在的activity
     * @return
     */
    public final Activity getActivity() {
        return container.activity;
    }

    /**
     * 获取聊天界面的fragment
     * @return
     */
    public final Fragment getFragment() {
        return container.fragment;
    }

    /**
     * 获取资讯对象的账号，可用于发送消息等等
     * @return
     */
    public final String getAccount() {
        return container.account;
    }

    public int getIconResId() {
        return iconResId;
    }

    public int getTitleId() {
        return titleId;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    public void setPendingMediaCallback(PendingMediaCallback callback) {
        this.pendingMediaCallback = callback;
    }

    public PendingMediaCallback getPendingMediaCallback() {
        return pendingMediaCallback;
    }

    public void setIndex(int index) {
        this.index = index;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    public String getTitle() {
        return title;
    }

    protected final int makeRequestCode(int requestCode) {
        if ((requestCode & 0xffffff00) != 0) {
            throw new IllegalArgumentException("Can only use lower 8 bits for requestCode");
        }
        return ((index+1) << 8) + (requestCode & 0xff);
    }

    public final IMMessage buidlImageMessage(File file){
        IMMessage message = UnicornMessageBuilder.buildImageMessage(getAccount(), file, file.getName());
        return message;
    }

    public final IMMessage buildTextMessage(String text){
        IMMessage message = UnicornMessageBuilder.buildTextMessage(getAccount(), text);
        return message;
    }


    /**
     * 可通过重写该方法改变 action 字体的颜色
     * @return
     */
    public int getActionFontColor(){
        return Color.parseColor("#333333");
    }

    /**
     * 接入方重写的 action 的点击事件，可以跳转到接入方的 activity 跳转时候，
     * 使用 activity 记得用 getActivity 或者 getFragment 方法，不然不能回调
     * 如果调用 startActivityFroresult 记得使用 makeRequestCode 去处理 requestCode
     * 此方法里面可以跳转到接入方的 activity，可以跳转到接入方 webview，可以跳转到接入方自己的相机 Activity，相册 Activity
     */
    public abstract void onClick();


    /**
     * 回调方法可通过 sendMessage 去发送消息，可以使用 buidMessage 方法去构建消息，
     * 可以发送文本消息或者图片消息
     * 也可以通过 MessageService.sendProductMessage 去发送商品相关消息
     * @param requestCode
     * @param resultCode
     * @param data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    }





}
