package com.qiyukf.unicorn.api.customization.msg_list;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;

/**
 * 自定义消息处理器工厂类，如果外部APP想要自己自定义部分消息类型的处理，可以通过这提供。
 * 如果这条消息同时也不需要显示，可以通过 {@link MsgCustomizationRegistry#hideViewForMsgType(Class[])} 隐藏
 */
public interface MessageHandlerFactory {

    /**
     * 根据消息类型或者消息内容返回对应的消息处理器
     * @param message 消息对象
     * @return 消息处理器
     */
    UnicornMessageHandler handlerOf(IMMessage message);
}
