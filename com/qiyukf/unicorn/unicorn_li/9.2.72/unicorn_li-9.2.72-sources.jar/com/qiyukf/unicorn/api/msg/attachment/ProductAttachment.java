package com.qiyukf.unicorn.api.msg.attachment;

import android.text.TextUtils;

import com.qiyukf.nimlib.util.JSONHelper;
import com.qiyukf.nimlib.ysf.attach.constant.AttachTag;
import com.qiyukf.unicorn.api.ProductDetail;
import com.qiyukf.unicorn.api.msg.ProductReslectOnclickListener;
import com.qiyukf.unicorn.protocol.attach.YsfAttachmentBase;
import com.qiyukf.unicorn.protocol.attach.constant.CmdId;
import com.qiyukf.unicorn.protocol.attach.constant.Tags;
import com.qiyukf.unicorn.protocol.attach.constant.YsfCmd;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ACTIVITY;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ACTIVITY_HREF;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ORDERSKU;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ORDER_COUNT;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ORDER_ID;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ORDER_STATUS;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_ORDER_TIME;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PORDUCT_PAY_MONEY;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_ACTION_SEND_USER;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_ACTION_TEXT;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_ACTION_TEXT_COLOR;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_IMAGETAG;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_PRICE;
import static com.qiyukf.unicorn.protocol.attach.constant.Tags.PRODUCT_TEMPLATE;


/**
 * Created by weilv on 16/5/24.
 */
@CmdId(YsfCmd.PRODUCT)
public class ProductAttachment extends YsfAttachmentBase implements Cloneable {
    @AttachTag(Tags.PRODUCT_TITLE)
    private String title;   //商品标题
    @AttachTag(Tags.PRODUCT_DESC)
    private String desc;    //商品描述
    @AttachTag(Tags.PRODUCT_PICTURE)
    private String picture;  //商品图片 url
    @AttachTag(Tags.PRODUCT_URL)
    private String url;    //点击跳转的 url
    @AttachTag(Tags.PRODUCT_NOTE)
    private String note;
    @AttachTag(Tags.PRODUCT_SHOW)
    private int show;      //是否展示
    @AttachTag("ext")
    private String ext;
    @AttachTag("auto")
    private int auto;
    @AttachTag("tags")     //活动列表
    private JSONArray tags;
    @AttachTag(PRODUCT_PRICE)   //商品价格
    private String price;
    @AttachTag("originalPrice")
    private String originalPrice; //商品原价
    @AttachTag(PORDUCT_PAY_MONEY) //订单支付价格
    private String payMoney;
    @AttachTag(PORDUCT_ORDER_COUNT)  //订单数量
    private String orderCount;
    @AttachTag(PORDUCT_ORDER_ID)  //订单 id
    private String orderID;
    @AttachTag(PORDUCT_ORDER_TIME) //下单时间
    private String orderTime;
    @AttachTag(PORDUCT_ORDER_STATUS) //订单状态
    private String orderStatus;
    @AttachTag(PORDUCT_ACTIVITY) //活动名称
    private String activity;
    @AttachTag(PORDUCT_ACTIVITY_HREF) //活动 url
    private String activityHref;
    @AttachTag(PORDUCT_ORDERSKU)
    private String orderSku;     //应该是库存的数量
    @AttachTag(PRODUCT_TEMPLATE)
    private String template;
    @AttachTag(PRODUCT_ACTION_TEXT)
    private String actionText;
    //发送连接文字的颜色 res id
    @AttachTag(PRODUCT_ACTION_TEXT_COLOR)
    private int actionTextColor;
    @AttachTag(PRODUCT_ACTION_SEND_USER)
    private int sendByUser;
    @AttachTag(Tags.PRODUCT_CUSTOM_FIELD)
    private String productCustomField;
    @AttachTag(Tags.IS_OPEN_CUSTOM_PRODUCT)
    private boolean isOpenCustomProduct;
    @AttachTag(Tags.PRODUCT_CARD_TYPE)  //卡片类型
    private int cardType;
    @AttachTag(Tags.PRODUCT_GOODS_CID)   //商品类目ID
    private String goodsCId;
    @AttachTag(Tags.PRODUCT_GOODS_CNAME)   //商品类目名称
    private String goodsCName;
    @AttachTag(Tags.PRODUCT_GOODS_ID)   //商品ID
    private String goodsId;
    @AttachTag(Tags.PRODUCT_INTENT)   //意图
    private String intent;

    //卡片展示样式
    private int cardShowStyle;

    //是否展示重新选择按钮
    private boolean isOpenReselect;
    //重新选择按钮标志事件
    private String handlerTag;
    //重新选择按钮文案
    private String reselectText;

    private String productCount;    // 显示加粗的商品数量
    //重新选择按钮点击事件
    private ProductReslectOnclickListener productReslectOnclickListener;

    public void fromProductDetail(ProductDetail productDetail, boolean auto) {
        setTitle(productDetail.getTitle());
        setDesc(productDetail.getDesc());
        setPicture(productDetail.getPicture());
        setUrl(productDetail.getUrl());
        setNote(productDetail.getNote());
        setShow(productDetail.getShow());
        setExt(productDetail.getExt());
        setActionText(productDetail.getActionText());
        setActionTextColor(productDetail.getActionTextColor());
        setSendByUser(productDetail.isSendByUser() ? 1 : 0);
        setHandlerTag(productDetail.getHandlerTag());
        setReselectText(productDetail.getReselectText());
        setOpenReselect(productDetail.isOpenReselect());
        setProductReslectOnclickListener(productDetail.getProductReslectOnclickListener());
        setCardType(productDetail.getCardType());
        setGoodsCId(productDetail.getGoodsCId());
        setGoodsCName(productDetail.getGoodsCName());
        setGoodsId(productDetail.getGoodsId());
        setOrderID(productDetail.getOrderId());
        setIntent(productDetail.getIntent());
        setCardShowStyle(productDetail.getCardShowStyle());
        setOrderTime(productDetail.getOrderTime());
        setOrderStatus(productDetail.getOrderStatus());
        setPrice(productDetail.getPrice());
        setPayMoney(productDetail.getPayMoney());
        setOrderCount(productDetail.getOrderCount());
        setProductCount(productDetail.getProductCount());
        setOrderSku(productDetail.getOrderSku());
        setOriginalPrice(productDetail.getOriginalPrice());
        if (productDetail.isOpenTemplate()) {
            setTemplate(PRODUCT_IMAGETAG);
        }
        if (!TextUtils.isEmpty(productDetail.getTagString())) {
            tags = JSONHelper.parseArray(productDetail.getTagString());
        } else if (productDetail.getTags() != null && productDetail.getTags().size() > 0) {
            tags = fromTag(productDetail.getTags());
        }
        this.auto = auto ? 1 : 0;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public int getShow() {
        return show;
    }

    public void setShow(int show) {
        this.show = show;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public JSONArray getTags() {
        return tags;
    }

    public void setTags(JSONArray tags) {
        this.tags = tags;
    }

    public int getAuto() {
        return auto;
    }

    public void setAuto(int auto) {
        this.auto = auto;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(String originalPrice) {
        this.originalPrice = originalPrice;
    }

    public String getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(String payMoney) {
        this.payMoney = payMoney;
    }

    public String getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(String orderCount) {
        this.orderCount = orderCount;
    }

    public String getProductCount() {
        return productCount;
    }

    public void setProductCount(String productCount) {
        this.productCount = productCount;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getActivityHref() {
        return activityHref;
    }

    public void setActivityHref(String activityHref) {
        this.activityHref = activityHref;
    }

    public String getOrderSku() {
        return orderSku;
    }

    public void setOrderSku(String orderSku) {
        this.orderSku = orderSku;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getActionText() {
        return actionText;
    }

    public void setActionText(String actionText) {
        this.actionText = actionText;
    }

    public int getActionTextColor() {
        return actionTextColor;
    }

    public void setActionTextColor(int actionTextColor) {
        this.actionTextColor = actionTextColor;
    }

    public int getSendByUser() {
        return sendByUser;
    }

    public void setSendByUser(int sendByUser) {
        this.sendByUser = sendByUser;
    }

    public String getHandlerTag() {
        return handlerTag;
    }

    public void setHandlerTag(String handlerTag) {
        this.handlerTag = handlerTag;
    }

    public String getReselectText() {
        return reselectText;
    }

    public void setReselectText(String reselectText) {
        this.reselectText = reselectText;
    }

    public ProductReslectOnclickListener getProductReslectOnclickListener() {
        return productReslectOnclickListener;
    }

    public void setProductReslectOnclickListener(ProductReslectOnclickListener productReslectOnclickListener) {
        this.productReslectOnclickListener = productReslectOnclickListener;
    }

    public boolean isOpenReselect() {
        return isOpenReselect;
    }

    public void setOpenReselect(boolean openReselect) {
        isOpenReselect = openReselect;
    }

    public String getProductCustomField() {
        return productCustomField;
    }

    public boolean isOpenCustomProduct() {
        return isOpenCustomProduct;
    }

    public void setProductCustomField(String productCustomField) {
        this.productCustomField = productCustomField;
    }

    public void setOpenCustomProduct(boolean openCustomProduct) {
        isOpenCustomProduct = openCustomProduct;
    }

    public int getCardType() {
        return cardType;
    }

    public void setCardType(int cardType) {
        this.cardType = cardType;
    }

    public String getGoodsCId() {
        return goodsCId;
    }

    public void setGoodsCId(String goodsCId) {
        this.goodsCId = goodsCId;
    }

    public String getGoodsCName() {
        return goodsCName;
    }

    public void setGoodsCName(String goodsCName) {
        this.goodsCName = goodsCName;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public void setCardShowStyle(int cardShowStyle) {
        this.cardShowStyle = cardShowStyle;
    }

    public int getCardShowStyle() {
        return cardShowStyle;
    }

    private static JSONArray fromTag(List<ProductDetail.Tag> tagList) {
        JSONArray array = new JSONArray();
        for (ProductDetail.Tag tag : tagList) {
            JSONObject object = new JSONObject();
            JSONHelper.put(object, "label", tag.getLabel());
            JSONHelper.put(object, "url", tag.getUrl());
            JSONHelper.put(object, "focusIframe", tag.getFocusIframe());
            JSONHelper.put(object, "data", tag.getData());
            JSONHelper.put(array, object);
        }
        return array;
    }

    @Override
    public final ProductAttachment clone() {
        try {
            return (ProductAttachment) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

}
