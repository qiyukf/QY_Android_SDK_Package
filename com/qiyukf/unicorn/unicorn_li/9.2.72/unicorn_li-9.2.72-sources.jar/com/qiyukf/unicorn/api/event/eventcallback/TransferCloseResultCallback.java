package com.qiyukf.unicorn.api.event.eventcallback;


import com.qiyukf.unicorn.api.event.entry.TransferCloseResultEntry;

/**
 * Describe:转接关闭客服事件的回调
 */
public interface TransferCloseResultCallback {

    /**
     * 转接的关闭事件有结果的时候会回调该方法
     * @param entry 结果信息的 entry
     */
    void handlerTransferCloseCallback(TransferCloseResultEntry entry);
}
