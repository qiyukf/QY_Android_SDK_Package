package com.qiyukf.unicorn.api.pop;

import java.io.Serializable;

/**
 * 商家入口信息
 */
public class ShopEntrance implements Serializable {
    private String logo;
    private String name;

    private ShopEntrance() {
    }

    public String getLogo() {
        return logo;
    }

    public String getName() {
        return name;
    }

    public static class Builder {
        private ShopEntrance shopEntrance;

        public Builder() {
            shopEntrance = new ShopEntrance();
        }

        /**
         * 设置商家logo url
         *
         * @param logo logo url
         */
        public Builder setLogo(String logo) {
            shopEntrance.logo = logo;
            return this;
        }

        /**
         * 设置商家名称
         *
         * @param name 商家名称
         */
        public Builder setName(String name) {
            shopEntrance.name = name;
            return this;
        }

        public ShopEntrance build() {
            return shopEntrance;
        }
    }
}
