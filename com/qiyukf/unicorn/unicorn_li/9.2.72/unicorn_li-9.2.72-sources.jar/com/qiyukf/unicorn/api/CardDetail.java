package com.qiyukf.unicorn.api;

import android.text.TextUtils;

import java.io.Serializable;

/**
 * 访客发起会话时自定义卡片消息设置接口。
 */
public class CardDetail implements Serializable {

    private String shopId;

    private String cardJson;

    private int sendByUser;

    private String actionText;

    private String actionTextColor;

    /**
     * 非平台企业卡片信息
     *
     * @param cardJson        卡片消息详情json
     * @param sendByUser      是否自动进线, 0 进线自动发送, 1 手动发送  默认0
     * @param actionText      发送按钮文案
     * @param actionTextColor 发送按钮颜色
     */
    public CardDetail(String cardJson, int sendByUser, String actionText, String actionTextColor) {
        this("-1", cardJson, sendByUser, actionText, actionTextColor);
    }

    /**
     * 非平台企业卡片信息
     *
     * @param shopId          商户 id 非平台企业为 -1
     * @param cardJson        卡片消息详情json
     * @param sendByUser      是否自动进线, 0 进线自动发送, 1 手动发送  默认0
     * @param actionText      发送按钮文案
     * @param actionTextColor 发送按钮颜色
     */
    public CardDetail(String shopId, String cardJson, int sendByUser, String actionText, String actionTextColor) {
        this.shopId = shopId;
        this.cardJson = cardJson;
        this.sendByUser = sendByUser;
        this.actionText = actionText;
        this.actionTextColor = actionTextColor;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getCardJson() {
        return cardJson;
    }

    public void setCardJson(String cardJson) {
        this.cardJson = cardJson;
    }

    public int getSendByUser() {
        return sendByUser;
    }

    public void setSendByUser(int sendByUser) {
        this.sendByUser = sendByUser;
    }

    public String getActionText() {
        return actionText;
    }

    public void setActionText(String actionText) {
        this.actionText = actionText;
    }

    public String getActionTextColor() {
        return actionTextColor;
    }

    public void setActionTextColor(String actionTextColor) {
        this.actionTextColor = actionTextColor;
    }

    public boolean valid() {
        return !TextUtils.isEmpty(cardJson);
    }
}
