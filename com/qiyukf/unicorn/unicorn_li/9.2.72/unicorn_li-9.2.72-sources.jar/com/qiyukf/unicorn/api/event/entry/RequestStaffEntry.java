package com.qiyukf.unicorn.api.event.entry;


import com.qiyukf.unicorn.api.CardDetail;
import com.qiyukf.unicorn.api.ProductDetail;

/**
 * 请求客服事件流通的实体类
 */

public class RequestStaffEntry {
    /**
     * 请求客服的场景：
     * scenes == 0、接入方不需要关心的场景
     * scenes == 1、客服分组中请求客服
     * scenes == 3、从机器人问答中请求客服(例如机器人看不懂或在机器人状态下输入 rg 等场景)
     * scenes == 4、链接客服失败，点击重新链接
     * scenes == 5、点击右上角人工客服请求客服
     * scenes == 6、点击消息中的重新连接按钮
     * scenes == 7、用户在结束会话之后，通过输入文字去请求客服的场景
     * scenes == 8、机器人转机器人会话场景
     * scenes == 100  在 onLineStatusChange 里面请求客服
     */
    private int scenes;

    //是否为只请求人工客服
    private boolean isHumanOnly;

    //当前请求客服的时刻是否为机器人状态 true 为是机器人状态 false 为不是
    private boolean isRobot;

    /**
     * 客服分组显示的名称，只有在分流请求客服的时候，这个字段才会有值
     * 此字段修改之后不会生效
     */
    private String label;

    /**
     * 该entry的ID，后面请求分配客服时带上
     */
    private long entryId;

    /**
     * 要咨询的商家 ID <br>
     * 平台电商调用，非平台电商不需要该字段。
     */
    private String shopId;

    /**
     * 咨询页面的uri，可以是url，也可以任意能标识来源的字符串
     */
    private String uri;

    /**
     * 咨询页面的title
     */
    private String title;

    /**
     * 可自定义传入的字符串，比如商品详细信息，用户操作状态等等, 在分配客服时该字段会传递给客服。
     */
    private String custom;

    /**
     * 请求分配客服时，指定客服分组。<br>
     * 分组 ID 可在管理后台的 「设置」-&gt;「访客分流」中查询
     */
    private long groupId;

    /**
     * 请求分配客服时，指定客服ID。如果指定了此参数，则groupId会被忽略。<br>
     * 客服 ID 可在管理后台的 「设置」-&gt;「访客分流」中查询
     */
    private long staffId;

    /**
     * 如果指定了 groupId 或者 staffId 时，该参数有效。表示会先进机器人，之后如果用户转人工服务，再分配给上面指定的groupId 或者 staffId
     */
    private boolean robotFirst;

    /**
     * 机器人ID，如果开启了机器人，该参数有效。如果不设置，将连接默认机器人。<br>
     * 机器人ID可以在管理后台的 设置 -&gt; APP接入 中查看。
     */
    private long robotId;

    /**
     * 机器人热门问题组 ID <br>
     * 如果指定了此参数，且请求客服为机器人客服，则会下发该 ID 对应的热门问题。<br>
     * 热门问题组 ID 可在管理后台查询。
     */
    private long faqGroupId;

    /**
     * 连接客服成功之后想要发送的商品信息（也就是在 source 中配置的，没配置就为 null），如果重写会覆盖之前的商品信息
     */
    private ProductDetail productDetail;

    /**
     * 连接客服成功之后想要发送的卡片信息（也就是在 source 中配置的，没配置就为 null），如果重写会覆盖之前的卡片信息
     */
    private CardDetail cardDetail;

    /**
     * 用户VIP等级<br>
     * 0:非VIP（默认）<br>
     * 1-10:VIP等级<br>
     * 11:通用VIP（不显示等级）
     * 修改之后不会生效
     */
    public int vipLevel;

    /**
     * 当前请求是否为转接请求
     */
    private boolean isTransfar;

    public ProductDetail getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ProductDetail productDetail) {
        this.productDetail = productDetail;
    }

    public CardDetail getCardDetail() {
        return cardDetail;
    }

    public void setCardDetail(CardDetail cardDetail) {
        this.cardDetail = cardDetail;
    }

    public boolean isTransfar() {
        return isTransfar;
    }

    public void setTransfar(boolean transfar) {
        isTransfar = transfar;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getStaffId() {
        return staffId;
    }

    public void setStaffId(long staffId) {
        this.staffId = staffId;
    }

    public boolean isRobotFirst() {
        return robotFirst;
    }

    public void setRobotFirst(boolean robotFirst) {
        this.robotFirst = robotFirst;
    }

    public long getRobotId() {
        return robotId;
    }

    public void setRobotId(long robotId) {
        this.robotId = robotId;
    }

    public long getFaqGroupId() {
        return faqGroupId;
    }

    public void setFaqGroupId(long faqGroupId) {
        this.faqGroupId = faqGroupId;
    }

    public int getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(int vipLevel) {
        this.vipLevel = vipLevel;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public int getScenes() {
        return scenes;
    }

    public void setScenes(int scenes) {
        this.scenes = scenes;
    }

    public boolean isRobot() {
        return isRobot;
    }

    public void setRobot(boolean robot) {
        isRobot = robot;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public long getEntryId() {
        return entryId;
    }

    public void setEntryId(long entryId) {
        this.entryId = entryId;
    }

    public boolean isHumanOnly() {
        return isHumanOnly;
    }

    public void setHumanOnly(boolean humanOnly) {
        isHumanOnly = humanOnly;
    }

    @Override
    public String toString() {
        return "scenes:" + getScenes() + "isHumanOnly:" + "" + isHumanOnly() + "isRobot:" + isRobot
                + "label" + getLabel() + "entryId:" + getEntryId() + "shopId:" + getShopId() + "uri:" + getUri()
                + "title:" + getTitle() + "custom:" + getCustom() + "groupId:" + getGroupId() + "staffId:" + getStaffId()
        +"robotFirst:" + isRobotFirst() +"robotId:" + getRobotId()+"faqGroupId:" + getFaqGroupId() + "isTransfa" + isTransfar;
    }
}
