package com.qiyukf.unicorn.api.event;


/**
 * 自定义事件处理器工厂类，如果外部APP想要对 sdk 中的某些事件进行处理，可以通过该类提供。
 */
public interface EventProcessFactory {

    public static final int EVENT_REQUEST_STAFF_TAG = 0;
    public static final int EVENT_REQUEST_RESULT_TAG = 1;
    public static final int EVENT_REGISTER_PARSER_TAG = 2;
    public static final int EVENT_QUIT_PAGE_TAG = 3;
    public static final int EVENT_CLICK_AVATAR_TAG = 4;
    public static final int EVENT_REQUEST_PERMISSION = 5;

    /**
     * 根据事件的类型返回不同的 event 拦截器
     * @param eventType 事件的类型 0:请求客服事件 1:连接客服结果事件  2:注册自定义消息解析器的事件
     *                  3: 退出客服界面事件(fragment 的集成方式不会回调该事件)
     *                  4: 点击头像事件
     *                  5: 申请权限事件
     * @return 如果不需要处理该事件，那么就可以直接返回 null ，如果需要处理该事件，就返回自己实现的 UnicornEventBase
     */
    UnicornEventBase eventOf(int eventType);
}
