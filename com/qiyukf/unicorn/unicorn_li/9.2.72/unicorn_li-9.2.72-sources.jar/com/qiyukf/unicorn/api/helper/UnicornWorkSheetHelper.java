package com.qiyukf.unicorn.api.helper;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import com.qiyukf.nimlib.sdk.RequestCallback;
import com.qiyukf.uikit.session.helper.WorkSheetHelper;
import com.qiyukf.unicorn.ui.activity.UserWorkSheetListActivity;

import java.util.List;


/**
 * Describe: 操作 SDK 工单功能的帮助类
 */
public class UnicornWorkSheetHelper {

    private WorkSheetHelper workSheetHelper;

    public UnicornWorkSheetHelper(Fragment fragment) {
        workSheetHelper = new WorkSheetHelper(fragment);
    }

    /**
     * 打开提交工单 dialog
     *
     * @param templateId             工单模版 id
     * @param exchange               exchange
     * @param watchAnnexRequestCode  查看附件的 requestCode
     * @param selectAnnexRequestCode 选择附件的 requestCode
     * @param requestCallback        提交成功的回调
     */
    public void openWorkSheetDialog(long templateId, String exchange, int watchAnnexRequestCode, int selectAnnexRequestCode, RequestCallback<String> requestCallback) {
        workSheetHelper.openWorkSheetDialog(templateId, exchange, watchAnnexRequestCode, selectAnnexRequestCode, requestCallback);
    }

    /**
     * 当查看附件或者选择
     *
     * @param requestCode 请求时候的 requestCode
     * @param data        返回的数据
     */
    public void onResultWorkSheet(int requestCode, Intent data) {
        workSheetHelper.onResultWorkSheet(requestCode, data);
    }

    /**
     * 打开用户工单列表界面
     * @param context Context
     * @param templateIds 工单模版 id,可通过 web 端客服工作台获取
     * @param isOpenUrge 是否打开催单功能
     * @param exchange 如果是平台版本传递 shopId，如果是非平台可以通过 UnicornMessageBuilder.getSessionId 获取
     */
    public static void openUserWorkSheetActivity(Context context, List<Long> templateIds, boolean isOpenUrge, String exchange) {
        UserWorkSheetListActivity.start(context, templateIds, isOpenUrge, exchange);
    }

}
