package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 快捷入口点击监听器
 */
public abstract class QuickEntryListener {
    /**
     * 快捷入口被点击
     *
     * @param context    上下文
     * @param shopId     商家ID，非平台企业请忽略该字段
     * @param quickEntry 目标入口
     */
    public abstract void onClick(Context context, String shopId, QuickEntry quickEntry);
}
