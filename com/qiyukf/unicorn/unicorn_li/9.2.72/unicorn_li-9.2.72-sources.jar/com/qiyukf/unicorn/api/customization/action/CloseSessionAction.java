package com.qiyukf.unicorn.api.customization.action;


import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.api.event.EventService;
import com.qiyukf.unicorn.util.ToastUtil;

/**
 * Created by andya on 2019-07-29
 * Describe: 退出会话 action
 */
public class CloseSessionAction extends BaseAction {

    int actionFontColor = 0;

    /**
     * 构造函数
     *
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public CloseSessionAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId   图标标题的 String
     */
    public CloseSessionAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId   图标标题的 String
     */
    public CloseSessionAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    @Override
    public void onClick() {
        if (!EventService.closeSession(getAccount(),getActivity().getString(R.string.ysf_already_quit_session))) {
            ToastUtil.showToast(R.string.ysf_already_quit_advisory);
        }
    }

    public void setActionFontColor(int actionFontColor){
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        }else {
            return actionFontColor;
        }
    }
}
