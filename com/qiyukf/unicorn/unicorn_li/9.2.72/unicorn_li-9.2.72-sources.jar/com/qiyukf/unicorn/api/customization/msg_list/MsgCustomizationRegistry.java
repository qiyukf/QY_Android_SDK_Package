package com.qiyukf.unicorn.api.customization.msg_list;


import com.qiyukf.nimlib.sdk.msg.attachment.MsgAttachment;
import com.qiyukf.nimlib.sdk.msg.constant.MsgTypeEnum;
import com.qiyukf.uikit.session.viewholder.MsgViewHolderBase;
import com.qiyukf.uikit.session.viewholder.MsgViewHolderFactory;
import com.qiyukf.uikit.session.viewholder.MsgViewHolderHidden;
import com.qiyukf.unicorn.api.customization.msg_list.baseviewholder.EvaluationViewHolderBase;
import com.qiyukf.unicorn.api.customization.msg_list.baseviewholder.ProductViewHolderBase;
import com.qiyukf.unicorn.api.customization.msg_list.baseviewholder.TextViewHolderBase;
import com.qiyukf.unicorn.api.customization.msg_list.baseviewholder.TipsViewHolderBase;
import com.qiyukf.unicorn.api.msg.UnicornMessageBuilder;
import com.qiyukf.unicorn.api.msg.attachment.ProductAttachment;
import com.qiyukf.unicorn.protocol.attach.request.EvaluationAttachment;

/**
 * 自定义消息处理的注册器。目前开发以下几类自定义：
 * 1. 在消息流中隐藏某些类型的消息
 * 2. 注册自定义的消息处理器
 */
public class MsgCustomizationRegistry {

    /**
     * 在消息流中隐藏某些类型的消息。
     * 该接口可以与其他自定义的消息处理器配合使用。
     *
     * @param attachTypes 消息附件类型
     */
    @SafeVarargs
    public static void hideViewForMsgType(Class<? extends MsgAttachment>... attachTypes) {
        for (Class<? extends MsgAttachment> attachType : attachTypes) {
            MsgViewHolderFactory.register(attachType, MsgViewHolderHidden.class, false);
        }
    }

    /**
     * 注册消息处理器工厂类 @see {@link MessageHandlerFactory}
     *
     * @param factory 消息处理器工厂类
     */
    public static void registerMessageHandlerFactory(MessageHandlerFactory factory) {
        MsgViewHolderFactory.setMessageHandlerFactory(factory);
    }

    /**
     * 注册自定消息 UI 的方法，该方法目前只支持四种消息的类型
     * 文本消息，通知类型的消息，评价消息和商品消息
     * 如果自定义上面四种消息类型的 UI 需要继承不同的基类
     * TextViewHolderBase（文本消息的基类） TipsViewHolderBase（通知类型消息的基类）
     * EvaluationViewHolderBase（评价类型消息的基类）ProductViewHolderBase（商品类型消息的基类）
     * @param viewHolder APP 方自定义的 viewHolder
     */
    public static void registerMessageViewHolder(Class<? extends MsgViewHolderBase> viewHolder) {
        //如果该类为 TextViewHolderBase 的父类或者接口
        if (TextViewHolderBase.class.isAssignableFrom(viewHolder)) {
            MsgViewHolderFactory.register(MsgTypeEnum.text, viewHolder);
        } else if (TipsViewHolderBase.class.isAssignableFrom(viewHolder)) {
            MsgViewHolderFactory.register(MsgTypeEnum.tip, viewHolder);
        } else if (EvaluationViewHolderBase.class.isAssignableFrom(viewHolder)) {
            MsgViewHolderFactory.register(EvaluationAttachment.class, viewHolder, true);
        } else if (ProductViewHolderBase.class.isAssignableFrom(viewHolder)) {
            MsgViewHolderFactory.register(ProductAttachment.class, viewHolder, true);
        }
    }

    /**
     * 注册接入方自定义消息类型对应的 UI 的方法
     * 该方法可以注册除 sdk 消息类型以外的消息
     * 接入方可通过实现 Attachment 来自定自己的消息类型
     * 通过@see{@link UnicornMessageBuilder} 中的 buildAppCustomMessage 方法去创建一条自定义类型的消息
     * 通过 MsgService 中的方法去发送一条自定义的消息
     * 注意：因为自定义消息的解析过程是不确定的，所以接入方需要实现 MsgAttachmentParser 去生成一个解析器，然后在
     * 通过 MsgService.registerCustomAttachmentParser 方法把生成的解析器注册进来
     * @param attach  接入方自定的 attachment
     * @param viewHolder 自定义 attachment 对应的展示的 UI
     */
    public static void registerMessageViewHolder(Class<? extends MsgAttachment> attach, Class<? extends MsgViewHolderBase> viewHolder){
        MsgViewHolderFactory.register(attach,viewHolder,true);
    }


}
