package com.qiyukf.unicorn.api.pop;

import java.util.List;

/**
 * 商家会话列表监听器
 */
public interface OnSessionListChangedListener {
    /**
     * 商家会话发生变化（更新/添加）
     *
     * @param updateSessionList 变化的商家会话列表
     */
    void onSessionUpdate(List<Session> updateSessionList);

    /**
     * 删除商家会话
     *
     * @param shopId 商家ID
     */
    void onSessionDelete(String shopId);
}
