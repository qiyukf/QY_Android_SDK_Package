package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 七鱼云信融合情况下,云信帐号被踢,点击"重新连接"响应
 */
public interface OnMixSdkReconnectClickListener {

    /**
     * 点击"重新连接"的响应
     *
     * @param context 上下文
     */
    void onMixSdkReconnectClicked(Context context);

}
