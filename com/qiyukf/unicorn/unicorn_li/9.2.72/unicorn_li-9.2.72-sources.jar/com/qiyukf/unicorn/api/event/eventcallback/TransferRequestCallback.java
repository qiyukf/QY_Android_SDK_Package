package com.qiyukf.unicorn.api.event.eventcallback;


import com.qiyukf.unicorn.api.event.entry.TransferRequestEntry;

/**
 * Describe:转接事件中的请求客服事件的回调
 */
public interface TransferRequestCallback {

    /**
     * 当转接事件中的请求客服事件有回调的时候
     * @param entry 结果信息的 entry
     */
    void handlerTransferRequestCallback(TransferRequestEntry entry);
}
