package com.qiyukf.unicorn.api.customization.action;

import com.qiyukf.nimlib.util.JSONHelper;
import com.qiyukf.unicorn.protocol.attach.notification.QueryProductRequestAttachment;
import com.qiyukf.unicorn.ui.queryproduct.QueryProductDialog;

/**
 * 访客端快捷入口增加订单、商品查询Action
 */
public class QueryProductAction extends BaseAction {

    private String mData;
    protected long mSessionId;

    public QueryProductAction(int iconResId, int titleId, String data, long sessionId) {
        super(iconResId, titleId);
        mData = data;
        mSessionId = sessionId;
    }

    public QueryProductAction(String imageUrl, String title, String data, long sessionId) {
        super(imageUrl, title);
        mData = data;
        mSessionId = sessionId;
    }

    public QueryProductAction(int iconResId, String title, String data, long sessionId) {
        super(iconResId, title);
        mData = data;
        mSessionId = sessionId;
    }

    @Override
    public void onClick() {
        int pageSize;
        String requestUrl;
        try {
            pageSize = JSONHelper.parse(mData).getInt("pageSize");
            requestUrl = JSONHelper.parse(mData).getString("requestUrl");
        } catch (Exception e) {
            e.printStackTrace();
            pageSize = 5;
            requestUrl = "";
        }
        QueryProductRequestAttachment attachment = new QueryProductRequestAttachment();
        attachment.setSessionId(mSessionId);
        attachment.setPageSize(pageSize);
        attachment.setRequestUrl(requestUrl);
        QueryProductDialog dialog = new QueryProductDialog(getFragment().getContext(), attachment);
        dialog.show();
    }
}
