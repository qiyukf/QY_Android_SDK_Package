package com.qiyukf.unicorn.api.event.entry;

/**
 * Describe: 转接客服中，关闭上一个客服事件回调的实体类
 */
public class TransferCloseResultEntry {

    //回调的状态码 200:关闭成功 其他：都是失败的场景
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
