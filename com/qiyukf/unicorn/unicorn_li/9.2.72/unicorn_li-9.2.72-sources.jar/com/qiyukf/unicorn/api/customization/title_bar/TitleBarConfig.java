package com.qiyukf.unicorn.api.customization.title_bar;

import java.io.Serializable;

public class TitleBarConfig implements Serializable {

    /**
     * 自定义 titlebar 右侧可点击区域的图片 drawable resId.
     */
    public int titleBarRightImg;

    /**
     * 自定义 titlebar 右侧可点击区域的文字
     */
    public String titleBarRightText;

    /**
     * 设置右上角文字颜色(包括评价、商家、人工客服、退出)
     */
    public int titleBarRightTextColor;

    /**
     * 设置右上角评价按钮背景
     * drawable resId
     */
    public int titleBarRightEvaluatorBtnBack;

    /**
     * 设置右上角转人工客服按钮的背景
     * drawable resId
     */
    public int titleBarRightHumanBtnBack;

    /**
     * 设置右上角退出会话按钮的背景
     * drawable resId
     */
    public int titleBarRightQuitBtnBack;


    /**
     * 自定义 titbar 右侧可点击区域的点击事件
     */
    public transient OnTitleBarRightBtnClickListener onTitleBarRightBtnClickListener;
}
