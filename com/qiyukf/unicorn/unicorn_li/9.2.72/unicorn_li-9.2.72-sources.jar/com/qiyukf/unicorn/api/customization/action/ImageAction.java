package com.qiyukf.unicorn.api.customization.action;


import com.qiyukf.unicorn.R;
import com.qiyukf.uikit.session.actions.PickImageAction;
import com.qiyukf.unicorn.api.msg.MessageService;

import java.io.File;

/**
 * Created by hzxuwen on 2015/6/12.
 */
public class ImageAction extends PickImageAction {

    int actionFontColor = 0;

    public ImageAction() {
        super(R.drawable.ysf_message_plus_photo_selector, R.string.ysf_input_panel_photo, true);
    }

    public ImageAction(int iconResId, int titleId){
        super(iconResId,titleId,true);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId   图标标题的 String
     */
    public ImageAction(String iconUrl, String titleId) {
        super(iconUrl, titleId, true);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId   图标标题的 String
     */
    public ImageAction(int iconUrl, String titleId) {
        super(iconUrl, titleId, true);
    }

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     * @param actionFontColor
     */

    public void setActionFontColor(int actionFontColor){
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        }else {
            return actionFontColor;
        }
    }

    @Override
    protected void onPicked(File file) {
        MessageService.sendMessage(buidlImageMessage(file));
    }
}

