package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 消息中点击事件响应。<br>
 * 目前仅开放了超链接的点击事件响应。
 */
public interface OnMessageItemClickListener {

    /**
     * 消息显示项中超链接的点击响应函数。如果没有设置，启动系统默认浏览器打开超链接
     * @param context 上下文
     * @param url 超链接
     */
    void onURLClicked(Context context, String url);
}
