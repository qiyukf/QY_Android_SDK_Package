package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import com.qiyukf.nimlib.util.StringUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.uikit.common.media.picker.model.PhotoInfo;
import com.qiyukf.uikit.session.activity.PickImageActivity;
import com.qiyukf.uikit.session.constant.Extras;
import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.uikit.session.helper.SendImageHelper;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.GetMapLocationEvent;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.api.msg.MessageService;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;
import com.qiyukf.unicorn.widget.dialog.LocationPermissionTipDialog;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 * 相机 action
 */

public class CameraAction extends BaseAction {

    int actionFontColor = 0;

    /**
     * 构造函数
     *
     * @param iconResId 图标 res id
     * @param titleId   图标标题的string res id
     */
    public CameraAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId 图标标题的 String
     */
    public CameraAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId 图标标题的 String
     */
    public CameraAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    @Override
    public void onClick() {
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(getFragment().getContext(), PermissionsConstant.cameraAndRedFile)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.cameraAndRedFile);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_TAKE_PHOTO);
                eventEntry.setPermissionList(permissionList);
                unicornEventBase.onEvent(eventEntry, getFragment().getContext(), new EventCallback() {
                    @Override
                    public void onProcessEventSuccess(Object o) {
                        checkPermissionAndGoCamera(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onPorcessEventError() {
                        checkPermissionAndGoCamera(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onNotPorcessEvent() {
                        checkPermissionAndGoCamera(unicornEventBase, eventEntry);
                    }

                    @Override
                    public void onInterceptEvent() {
                        ToastUtil.showToast(R.string.ysf_no_permission_camera);
                    }
                });
            } else {
                checkPermissionAndGoCamera(null, null);
            }
        } else {
            checkPermissionAndGoCamera(null, null);
        }
    }

    private String tempFile() {
        String filename = StringUtil.get32UUID() + ".jpg";
        return YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_TEMP);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RequestCode.PICK_IMAGE:
                SendImageHelper.onPickImageActivityResult(getFragment(), data, makeRequestCode(RequestCode.PREVIEW_IMAGE_FROM_CAMERA), callback);
                break;
            case RequestCode.PREVIEW_IMAGE_FROM_CAMERA:
                if (getPendingMediaCallback() != null && data != null) {
                    // 拍照预览完成：回传给 InputPanel，不直接发送
                    boolean isOrig = data.getBooleanExtra(Extras.EXTRA_IS_ORIGINAL, false);
                    List<PhotoInfo> photos = SendImageHelper.buildPhotosFromCameraResult(data);
                    if (photos != null && !photos.isEmpty()) {
                        // 拍照流程总是追加到预览条
                        getPendingMediaCallback().onPhotosSelected(photos, isOrig, false);
                    }
                } else {
                    SendImageHelper.onPreviewImageActivityResult(getFragment(), data, requestCode, makeRequestCode(RequestCode.PICK_IMAGE), callback);
                }
                break;
        }
    }

    private SendImageHelper.Callback callback = new SendImageHelper.Callback() {
        @Override
        public void sendImage(File file, String origName, boolean isOrig) {
            MessageService.sendMessage(buidlImageMessage(file));
        }
    };

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     *
     * @param actionFontColor
     */

    public void setActionFontColor(int actionFontColor) {
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        } else {
            return actionFontColor;
        }
    }

    private void checkPermissionAndGoCamera(UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(getFragment())
                .permissions(PermissionsConstant.cameraAndRedFile)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        int from = PickImageActivity.FROM_CAMERA;
                        PickImageActivity.start(getFragment(), makeRequestCode(RequestCode.PICK_IMAGE), from, tempFile(), true, 1, false, false, 0, 0);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(getFragment().getContext(), eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_camera);
                        }
                    }
                })
                .request();
    }
}
