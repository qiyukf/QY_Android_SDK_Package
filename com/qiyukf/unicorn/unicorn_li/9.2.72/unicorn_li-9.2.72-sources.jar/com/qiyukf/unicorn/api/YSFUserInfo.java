package com.qiyukf.unicorn.api;

/**
 * 云商服标识第三方 APP 用户的类。当第三方 APP 用户登录后，需要告诉 SDK 当前登录用户信息。<br>
 * 用户数据中，name，mobile，email为七鱼保留字段，在客服端显示的顺序和label不能指定。<br>
 * extras为扩展字段，用于显示企业专有的用户信息。
 */
public class YSFUserInfo {

    /**
     * APP 的用户 ID, 该 ID 能唯一标识一个用户即可，不一定要和 APP 中的用户账号相同。<br>
     * SDK 根据该 ID 识别用户，组织聊天记录。
     */
    public String userId;

    /**
     * 当且仅当开发者在管理后台开启了 authToken 校验功能时，该字段才有效。
     * 用于校验用户 userId 真实性，如果 authToken 无效，此次设置用户信息的请求将无效。
     */
    public String authToken;

    /**
     * CRM 扩展字段。用于企业自定义用户信息展示。<br>
     * 该 array 中的 item 目前可包含以下字段： <br>
     *     1. key: 数据项的名称，用于区别不同的数据.<br>
     *     2. index: 用于排序，显示数据时数据项按index值升序排列；不设定index的数据项将排在后面；index相同或未设定的数据项将按照其在 JSON 中出现的顺序排列。<br>
     *     3. label: 该项数据显示的名称。<br>
     *     4. value: 该数据显示的值，类型不做限定，根据实际需要进行设定。<br>
     *     5. href: 超链接地址。若指定该值，则该项数据将显示为超链接样式，点击后跳转到其值所指定的 URL 地址。<br>
     *     6. hidden: 是否隐藏该item。目前仅对mobile和email有效。<br>
     * <p>
     * 现在，以下3个key是由七鱼使用的，对这3项的排序和标签名是固定，不能指定index和label。<br>
     *     1. real_name: 用户姓名<br>
     *     2. mobile_phone：用户手机号，可以隐藏。<br>
     *     3. email：用户的邮箱账号，可以隐藏。<br>
     */
    public String data;

    /**
     * 纬度
     */
    public double latitude;
    /**
     * 经度
     */
    public double longitude;
}
