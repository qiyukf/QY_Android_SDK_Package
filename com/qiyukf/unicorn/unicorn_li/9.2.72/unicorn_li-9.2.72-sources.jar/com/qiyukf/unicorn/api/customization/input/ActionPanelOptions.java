package com.qiyukf.unicorn.api.customization.input;


import java.io.Serializable;

/**
 * 自定义输入栏 actionPanel 相关内容的选项类
 */
public class ActionPanelOptions implements Serializable {


    /**
     * 获取"+"出现的 actionlist 的接口
     */
    public transient ActionListProvider actionListProvider;

    /**
     * actionpanel出现的列表的背景颜色 res id
     */
    public int backgroundColor;


}
