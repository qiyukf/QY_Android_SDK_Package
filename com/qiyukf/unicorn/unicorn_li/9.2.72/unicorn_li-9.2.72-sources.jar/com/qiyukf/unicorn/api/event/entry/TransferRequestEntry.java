package com.qiyukf.unicorn.api.event.entry;

/**
 * Describe:转接事件中，请求结果
 */
public class TransferRequestEntry {
    /**
     * 请求客服事件的状态码 200:成功;201:没有客服在线;202:其它错误;203:需要排队;204:bundleid无效
     */
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
