package com.qiyukf.unicorn.api;

import android.content.Context;

/**
 * 跳转显示地图
 */
public interface ShowMapLocationEvent {

    /**
     * @param context
     * @param longitude
     * @param latitude
     * @param buildName
     * @param address
     * @return
     */
    boolean setData(Context context, double longitude, double latitude, String buildName, String address);
}
