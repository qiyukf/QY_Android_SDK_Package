package com.qiyukf.unicorn.api.customization.action;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.uikit.session.constant.RequestCode;
import com.qiyukf.uikit.session.helper.VideoMsgHelper;
import com.qiyukf.unicorn.api.msg.MessageService;
import com.qiyukf.unicorn.api.msg.UnicornMessageBuilder;

import java.io.File;

/**
 * Created by andya on 2019-07-29
 * Describe:
 */
public class VideoAlbumAction extends BaseAction{


    private int actionFontColor = 0;

    private transient VideoMsgHelper videoMsgHelper;

    public VideoAlbumAction(int iconResId, int titleId) {
        super(iconResId, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 url
     * @param titleId   图标标题的 String
     */
    public VideoAlbumAction(String iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    /**
     * 构造函数
     *
     * @param iconUrl 图标的 res id
     * @param titleId   图标标题的 String
     */
    public VideoAlbumAction(int iconUrl, String titleId) {
        super(iconUrl, titleId);
    }

    @Override
    public void onClick() {
        videoHelper().goVideoAlbum(makeRequestCode(RequestCode.GET_VIDEO_FROM_LOCAL));
    }


    /**
     * ********************** 视频 *******************************
     */
    private void initVideoMessageHelper() {
        videoMsgHelper = new VideoMsgHelper(getFragment(), new VideoMsgHelper.VideoMessageHelperListener() {
            @Override
            public void onVideoPicked(File file, String md5) {
                MediaPlayer mediaPlayer = getVideoMediaPlayer(file);
                long duration = mediaPlayer == null ? 0 : mediaPlayer.getDuration();
                int height = mediaPlayer == null ? 0 : mediaPlayer.getVideoHeight();
                int width = mediaPlayer == null ? 0 : mediaPlayer.getVideoWidth();
                if (mediaPlayer != null) mediaPlayer.release();

                if (getPendingMediaCallback() != null) {
                    // 预览模式：回传给 InputPanel，不直接发送
                    getPendingMediaCallback().onVideoSelected(file, duration, width, height);
                } else {
                    IMMessage message = UnicornMessageBuilder.buildVideoMessage(getAccount(), file, duration, width, height, file.getName());
                    MessageService.sendMessage(message);
                }
            }
        });
    }

    /**
     * 获取视频mediaPlayer
     *
     * @param file 视频文件
     * @return mediaPlayer
     */
    private MediaPlayer getVideoMediaPlayer(File file) {
        try {
            return MediaPlayer.create(getActivity(), Uri.fromFile(file));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RequestCode.GET_VIDEO_FROM_LOCAL:
                videoHelper().onSelectLocalVideoResult(data);
                break;
        }
    }

    /**
     * 可以通过此方法改变文字颜色，如果不设置就显示默认颜色
     * @param actionFontColor 设置的文字颜色
     */

    public void setActionFontColor(int actionFontColor){
        this.actionFontColor = actionFontColor;
    }

    @Override
    public int getActionFontColor() {
        if (actionFontColor == 0) {
            return super.getActionFontColor();
        }else {
            return actionFontColor;
        }
    }

    private VideoMsgHelper videoHelper() {
        if (videoMsgHelper == null) {
            initVideoMessageHelper();
        }
        return videoMsgHelper;
    }

}
