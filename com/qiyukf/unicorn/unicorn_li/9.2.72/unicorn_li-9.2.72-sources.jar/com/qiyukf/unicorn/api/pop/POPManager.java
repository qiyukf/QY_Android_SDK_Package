package com.qiyukf.unicorn.api.pop;


import com.qiyukf.nimlib.sdk.NIMClient;
import com.qiyukf.nimlib.sdk.msg.MsgService;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.unicorn.POPManagerImpl;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.msg.SessionStatusEnum;
import com.qiyukf.unicorn.session.SessionManager;
import com.qiyukf.unicorn.util.QiyuInitHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * 商家管理
 */
public class POPManager {

    /**
     * 获取最近联系商家列表
     *
     * @return 最近联系商家列表
     */
    public static List<Session> getSessionList() {
        POPManagerImpl delegate = UnicornImpl.getPOPManager();
        return (delegate == null) ? new ArrayList<Session>() : delegate.getSessionList();
    }

    public static SessionStatusEnum querySessionStatus() {
        return SessionManager.getInstance().querySessionStatus("-1");
    }

    /**
     * 获取会话状态
     * @param shopId 商家ID
     * @return 当前会话状态
     */
    public static SessionStatusEnum querySessionStatus(String shopId) {
        return SessionManager.getInstance().querySessionStatus(shopId);
    }

    /**
     * 删除最近联系商家记录
     *
     * @param shopId          商家ID
     * @param clearMsgHistory 是否同时清空消息记录
     */
    public static void deleteSession(final String shopId, final boolean clearMsgHistory) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                POPManagerImpl delegate = UnicornImpl.getPOPManager();
                if (delegate != null) {
                    delegate.deleteSession(shopId, clearMsgHistory);
                }
            }
        });
    }

    /**
     * 注册/注销最近联系商家更新监听器（添加、删除、新消息等）
     *
     * @param add true，注册；否则注销，请务必在关闭界面时注销此监听器
     */
    public static void addOnSessionListChangedListener(final OnSessionListChangedListener listener, final boolean add) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                POPManagerImpl delegate = UnicornImpl.getPOPManager();
                if (delegate != null) {
                    delegate.addOnSessionListChangedListener(listener, add);
                }
            }
        });
    }

    /**
     * 根据商家ID获取商家信息，如名称，logo
     *
     * @param shopId 商家ID
     * @return 如果用户联系过该商家，返回商家信息，否则返回 null
     */
    public static ShopInfo getShopInfo(String shopId) {
        POPManagerImpl delegate = UnicornImpl.getPOPManager();
        return (delegate == null) ? null : delegate.getShopInfo(shopId);
    }

    /**
     * 拉取商家的服务器模板消息
     *
     * @param shopId 商家ID
     * @param msgId  模板消息ID
     *  该功能暂未实现
     */
    /*public static void pullShopTemplateMsg(String shopId, long msgId) {
        POPManagerImpl delegate = UnicornImpl.getPOPManager();
        if (delegate != null) {
            UnicornImpl.getInstance().pullTemplateMsg(shopId, msgId);
        }
    }*/

    /**
     * 获取和客服的最后一条聊天消息内容。
     * 可用于未读消息变化时，展示最后一条未读消息，或者展示客服的最后一条消息。
     *
     * @param shopId 商家ID
     * @return 最后一条消息
     */
    public static IMMessage queryLastMessage(String shopId) {
        POPManagerImpl delegate = UnicornImpl.getPOPManager();
        if (delegate != null) {
            return NIMClient.getService(MsgService.class).queryLastMessage(shopId, SessionTypeEnum.Ysf);
        }
        return null;
    }

    /**
     * 清理商户会话的未读数
     *
     * @param shopId 商家ID
     */
    public static void clearUnreadCount(final String shopId) {
        QiyuInitHandler.runOnThread(new Runnable() {
            @Override
            public void run() {
                POPManagerImpl delegate = UnicornImpl.getPOPManager();
                if (delegate != null) {
                    NIMClient.getService(MsgService.class).clearUnreadCount(shopId, SessionTypeEnum.Ysf);
                }
            }
        });
    }
}
