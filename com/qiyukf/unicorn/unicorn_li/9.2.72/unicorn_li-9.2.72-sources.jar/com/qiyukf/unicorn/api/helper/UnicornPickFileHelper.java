package com.qiyukf.unicorn.api.helper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import androidx.fragment.app.Fragment;

import com.qiyukf.module.log.UnicornLog;
import com.qiyukf.nimlib.net.http.util.AttachmentStore;
import com.qiyukf.nimlib.sdk.msg.MessageBuilder;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.nimlib.util.MD5;
import com.qiyukf.nimlib.util.StringUtil;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.UnicornImpl;
import com.qiyukf.unicorn.api.event.EventCallback;
import com.qiyukf.unicorn.api.event.EventProcessFactory;
import com.qiyukf.unicorn.api.event.UnicornEventBase;
import com.qiyukf.unicorn.api.event.entry.RequestPermissionEventEntry;
import com.qiyukf.unicorn.api.msg.MessageService;
import com.qiyukf.unicorn.fileselect.FilePicker;
import com.qiyukf.unicorn.fileselect.entry.FilePickConstant;
import com.qiyukf.unicorn.mediaselect.Matisse;
import com.qiyukf.unicorn.mediaselect.MimeType;
import com.qiyukf.unicorn.model.PermissionsConstant;
import com.qiyukf.unicorn.util.PermissionReq;
import com.qiyukf.unicorn.util.SDKhelper;
import com.qiyukf.unicorn.util.ToastUtil;
import com.qiyukf.unicorn.util.UriHelper;
import com.qiyukf.unicorn.util.file.FileUtil;
import com.qiyukf.unicorn.util.storge.YsfStorageType;
import com.qiyukf.unicorn.util.storge.YsfStorageUtil;
import com.qiyukf.unicorn.widget.dialog.LocationPermissionTipDialog;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;


/**
 * fragment 接入方式用户使用 SDK 中选择文件的帮助类，通过该类可以启动
 * SDK 中的选择图片的的界面，并将回调的数据通过该类提供的方法进行处理，达到
 * 发送图片消息的效果
 */
public class UnicornPickFileHelper {
    private static final String TAG = "UnicornPickFileHelper";
    public static int fileIndex = 0;
    private static LocationPermissionTipDialog locationPermissionTipDialog;

    public static void goPickFileActivity(final Fragment fragment, final int requestCode) {
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(fragment.getContext(), PermissionsConstant.readFile)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.readFile);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_SELECT_FILE);
                eventEntry.setPermissionList(permissionList);
                checkPermissionAndGo(fragment, requestCode, unicornEventBase, eventEntry);

//                unicornEventBase.onEvent(eventEntry, fragment.getContext(), new EventCallback() {
//                    @Override
//                    public void onProcessEventSuccess(Object o) {
//                        checkPermissionAndGo(fragment, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onPorcessEventError() {
//                        checkPermissionAndGo(fragment, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onNotPorcessEvent() {
//                        checkPermissionAndGo(fragment, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onInterceptEvent() {
//                        ToastUtil.showToast(R.string.ysf_no_permission_file);
//                    }
//                });
            } else {
                checkPermissionAndGo(fragment, requestCode, null, null);
            }
        } else {
            checkPermissionAndGo(fragment, requestCode, null, null);
        }
    }

    public static void goPickFileActivity(final Activity activity, final int requestCode) {
        if (UnicornImpl.getOptions().sdkEvents != null && UnicornImpl.getOptions().sdkEvents.eventProcessFactory != null
                && !PermissionReq.hasPermissions(activity, PermissionsConstant.readFile)) {
            UnicornEventBase unicornEventBase = UnicornImpl.getOptions().sdkEvents.eventProcessFactory.eventOf(EventProcessFactory.EVENT_REQUEST_PERMISSION);
            if (unicornEventBase != null) {
                List<String> permissionList = Arrays.asList(PermissionsConstant.readFile);
                RequestPermissionEventEntry eventEntry = new RequestPermissionEventEntry();
                eventEntry.setScenesType(RequestPermissionEventEntry.SCENES_SELECT_FILE);
                eventEntry.setPermissionList(permissionList);
                checkPermissionAndGo(activity, requestCode, unicornEventBase, eventEntry);

//                unicornEventBase.onEvent(eventEntry, activity, new EventCallback() {
//                    @Override
//                    public void onProcessEventSuccess(Object o) {
//                        checkPermissionAndGo(activity, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onPorcessEventError() {
//                        checkPermissionAndGo(activity, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onNotPorcessEvent() {
//                        checkPermissionAndGo(activity, requestCode, unicornEventBase, eventEntry);
//                    }
//
//                    @Override
//                    public void onInterceptEvent() {
//                        ToastUtil.showToast(R.string.ysf_no_permission_file);
//                    }
//                });
            } else {
                checkPermissionAndGo(activity, requestCode, null, null);
            }
        } else {
            checkPermissionAndGo(activity, requestCode, null, null);
        }
    }

    public static void onPickFileResult(String sessionId, Context context, Intent data) {
        if (SDKhelper.isHighAndroidQ()) {
            Uri uri = data.getData();
            if (uri == null || context == null) {
                return;
            }
            try {
                InputStream input = context.getContentResolver().openInputStream(uri);
                long size = input.available();
                if (size > 100 * 1024 * 1024) {
                    ToastUtil.showToast(R.string.ysf_file_out_limit);
                    return;
                }
            } catch (IOException e) {
                UnicornLog.e(TAG,"onPickFileResult is error", e);
                return;
            } catch (NullPointerException e) {
                UnicornLog.e(TAG,"onPickFileResult is NPE", e);
                return;
            }

            String md5 = MD5.getUriMD5(context, uri);
            String filename = md5 + fileIndex + "." + FileUtil.getExtensionName(uri.toString());
            fileIndex++;
            UnicornLog.i(TAG,"onPickFileResult md5= " + md5);
            UnicornLog.i(TAG,"onPickFileResult fileName= " + filename);
            String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_FILE);
            if (AttachmentStore.copy(context, uri, md5Path)) {
                if (md5Path != null) {
                    File file = new File(md5Path);
                    IMMessage message = MessageBuilder.createFileMessage(sessionId, SessionTypeEnum.Ysf, file, UriHelper.uriOfName(context, uri));
                    MessageService.sendMessage(message);
                }
            } else {
                ToastUtil.showToast(R.string.ysf_media_exception);
            }
        } else {
            //这个地方去处理并发送图片
            List<String> list = data.getStringArrayListExtra(FilePickConstant.PICK_FILE_LIST_TAG);
            // 可以通过如下方法获取文件目录 String path = data.getStringExtra(PICK_FILE_DIRECTORY_TAG);
            if (list == null) {
                return;
            }
            String md5 = MD5.getStreamMD5(list.get(0));
            //这个地方
            String filename = md5 + fileIndex + "." + FileUtil.getExtensionName(list.get(0));
            fileIndex++;
            UnicornLog.i(TAG,"onPickFileResult md5= " + md5);
            UnicornLog.i(TAG,"onPickFileResult fileName= " + filename);
            String md5Path = YsfStorageUtil.getWritePath(filename, YsfStorageType.TYPE_FILE);
            if (AttachmentStore.copy(list.get(0), md5Path) != -1) {
                if (md5Path != null) {
                    File file = new File(md5Path);
                    IMMessage message = MessageBuilder.createFileMessage(sessionId, SessionTypeEnum.Ysf, file, StringUtil.nameOfPath(list.get(0)));
                    MessageService.sendMessage(message);
                }
            } else {
                ToastUtil.showToast(R.string.ysf_media_exception);
            }
        }
    }

    private static void checkPermissionAndGo(Activity activity, int requestCode, UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
        PermissionReq.with(activity)
                .permissions(PermissionsConstant.readFile)
                .result(new PermissionReq.Result() {
                    @Override
                    public void onGranted() {
                        FilePicker.openFileActivity(activity, requestCode);
                    }

                    @Override
                    public void onDenied() {
                        if (unicornEventBase == null || !unicornEventBase.onDenyEvent(activity, eventEntry)) {
                            ToastUtil.showToast(R.string.ysf_no_permission_file);
                        }
                    }
                })
                .request();
    }

    private static void checkPermissionAndGo(Fragment fragment, int requestCode, UnicornEventBase unicornEventBase, RequestPermissionEventEntry eventEntry) {
                PermissionReq.with(fragment)
                        .permissions(PermissionsConstant.readFile)
                        .result(new PermissionReq.Result() {
                            @Override
                            public void onGranted() {
                                if (SDKhelper.isHighAndroidQ()) {
                                    try {
                                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                                        intent.setType("*/*");
                                        fragment.startActivityForResult(intent, requestCode);
                                    } catch (Exception e) {
                                        ToastUtil.showToast(R.string.ysf_start_file_select_fail);
                                    }
                                } else {
                                    FilePicker.openFileActivity(fragment, requestCode);
                                }
                            }

                            @Override
                            public void onDenied() {
                                if (unicornEventBase == null || !unicornEventBase.onDenyEvent(fragment.getContext(), eventEntry)) {
                                    ToastUtil.showToast(R.string.ysf_no_permission_video);
                                }
                            }
                        })
                        .request();
    }
}
