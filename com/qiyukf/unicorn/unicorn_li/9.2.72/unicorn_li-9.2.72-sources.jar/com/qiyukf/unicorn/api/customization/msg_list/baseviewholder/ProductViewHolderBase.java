package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;

import android.content.Context;

import com.qiyukf.nimlib.sdk.msg.MessageBuilder;
import com.qiyukf.nimlib.sdk.msg.constant.MsgDirectionEnum;
import com.qiyukf.nimlib.sdk.msg.constant.SessionTypeEnum;
import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.unicorn.R;
import com.qiyukf.unicorn.api.msg.attachment.ProductAttachment;
import com.qiyukf.unicorn.protocol.attach.notification.AssignStaffAttachment;
import com.qiyukf.unicorn.session.SessionHelper;
import com.qiyukf.unicorn.session.SessionManager;
import com.qiyukf.unicorn.util.ToastUtil;


/**
 * 如果想实现商品 UI 的自定义，请实现改抽象类的方法，然后再通过
 * MsgCustomizationRegistry.registerMessageViewHolder 去注册
 * 该 viewHolder ，这样就能达成自定义 product 消息 UI 的目的
 * 这里面有几个东西需要注意一下，一个是重新选择按钮的处理逻辑，一个是手动发送按钮的处理逻辑
 * 附：该类的基类中有大量方法，请自行查看
 */
public abstract class ProductViewHolderBase extends UnicornMessageViewHolder {

    /**
     * 该方法中提供了 textmessage 中显示的全部信息，用户可以通过此信息设置 UI
     *
     * @param attachment   上品的全部信息都在这个里面，该变量里面比较重要的字段 isOpenReselect 是否需要重新选择
     * @param isSendByUser 是否为用户手动发送的商品 true 为用户手动发送的商品 false 为非用户手动发送的
     *                     注意：如果 webJumpUrl 字段为空，那么就不需要显示跳转按钮
     */
    public abstract void bindTextMsgView(Context context, ProductAttachment attachment, Boolean isSendByUser);

    @Override
    public final void bindContentView(IMMessage message, Context context) {
        ProductAttachment attachment = (ProductAttachment) message.getAttachment();
        boolean isSendByUser = attachment.getSendByUser() == 1 && message.getDirect() == MsgDirectionEnum.Out && !(SessionManager.getInstance().getStaffType(message.getSessionId()) == AssignStaffAttachment.StaffType.ROBOT);
        bindTextMsgView(context, attachment, isSendByUser);
    }

    /**
     * 商品信息中不是有手动发送的功能，手动发送的功能可以直接调用这个方法
     */
    public final void onClickToSendByUser(ProductAttachment attachment) {
        if (SessionManager.getInstance().getStaffType(message.getSessionId()) == AssignStaffAttachment.StaffType.ROBOT) {
            ToastUtil.showLongToast(R.string.ysf_send_card_robot);
            return;
        }
        if (!SessionHelper.isAllowSendMessage(false)) {
            ToastUtil.showLongToast(R.string.ysf_send_card_error);
            return;
        }
        ProductAttachment sendAttach = attachment.clone();
        if (sendAttach != null) {
            sendAttach.setSendByUser(0);
            sendAttach.setActionText("");
            IMMessage sendMsg = MessageBuilder.createCustomMessage(message.getSessionId(), SessionTypeEnum.Ysf, sendAttach);
            SessionHelper.sendMessage(sendMsg);
        }
    }

    //左侧消息背景默认不设置
    @Override
    protected int leftBackground() {
        return 0;
    }

    //右侧消息背景默认不设置
    @Override
    protected int rightBackground() {
        return 0;
    }
}
