package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;

import android.content.Context;
import android.view.View;

import com.qiyukf.nimlib.sdk.msg.model.IMMessage;
import com.qiyukf.uikit.session.viewholder.MsgViewHolderBase;

/**
 *  自定义 sdk 中已有消息类型的 UI 的抽象类，如果想自定义消息的 UI ，可通过继承此类来完成
 *  我们把一条消息看作一个 viewHolder，填充 viewHolder 的数据，我们把他
 *  叫做 attachment，不同的 viewHolder 对应不同的 attachment
 *  例如：ProductViewHolder(商品消息) 对应 ProductAttachment
 *  ProductAttachment 里面有商品的全部信息
 */


public abstract class UnicornMessageViewHolder extends MsgViewHolderBase {


    /**
     * 该方法必须重写，返回 viewHolder 的 layout id
     * @return
     */
    public abstract int getViewHolderResId();

    /**
     * 在该方法中去完成 findViewById 的操作，一定要在该方法中去 findViewById，
     * 不然不能在 bindContentView 中去使用 View
     */
    public abstract void inflateFindView();

    /**
     * 可以通过实现此方法，来完成 ViewHolder 的数据的填充
     * 可以通过 message.getAttachment 去获取 attachment，
     * 如果你自定义的是商品消息的 UI，那么在 message.getAttachment 的时候
     * 请进行一次强制类型转换
     * 1、可以通过 message.getDirect 方法去判断消息是客服发送的，
     * 还是访客发送的 0 为访客发送的消息，1为客服发送的消息
     * 2、可以通过设置最外层 layout 的背景去设置每条消息的背景
     * @param message
     */
    public abstract void bindContentView(IMMessage message, Context context);


    @Override
    protected final int getContentResId() {
        return getViewHolderResId();
    }

    @Override
    protected final void bindContentView() {
        bindContentView(message,context);
    }

    @Override
    protected final void inflateContentView() {
        inflateFindView();
    }


    /**
     * 在 findViewById 的时候，可以通过调用此方法去完成，
     * 例如：RootLayout rootLayout = findViewById(R.id.root_layout)
     * 不需要：RootLayout rootLayout = view.findViewById(R.id.root_layout)
     * @param id
     * @param <T>
     * @return
     */
    @Override
    protected <T extends View> T findViewById(int id) {
        return super.findViewById(id);
    }

    //获取消息方向的方法，true 收到的消息 false 为发送出去的消息
    @Override
    protected boolean isReceivedMessage() {
        return super.isReceivedMessage();
    }

    /**
     * 左侧消息的背景，可以通过重写该方法修改左侧消息的背景,如果不想使用此方法设置背景，可直接返回 0
     * @return res id
     */
    @Override
    protected int rightBackground() {
        return super.rightBackground();
    }

    /**
     * 左侧消息的背景，可以通过重写该方法修改左侧消息的背景,如果不想使用此方法设置背景，可直接返回 0
     * @return res id
     */
    @Override
    protected int leftBackground() {
        return super.leftBackground();
    }

    /**
     * 此条消息的点击事件,默认不处理
     */
    @Override
    protected void onItemClick() {
        super.onItemClick();
    }

    /**
     * 此条消息的长按事件,默认不处理
     * @return
     */
    @Override
    protected boolean onItemLongClick() {
        return super.onItemLongClick();
    }

    /**
     * 消息是否水平居中，默认不居中
     * @return
     */
    @Override
    protected boolean isMiddleItem() {
        return super.isMiddleItem();
    }

    /**
     * 该条消息是否展示头像，默认展示
     * @return
     */
    @Override
    protected boolean showAvatar() {
        return super.showAvatar();
    }

}
