package com.qiyukf.unicorn.api.event;

import android.content.Context;

/**
 * 事件处理的基类，可以通过继承改类完成对事件的拦截
 */
public interface UnicornEventBase<T> {

    /**
     * 当有客服请求事件的时候，会调用该方法
     *
     * @param t        该 t 中存放了事件所需要的数据
     * @param context  当前界面的 context 对象，使用之前请判断是否为 null
     * @param callback sdk 的回调对象  注意：如果该事件 sdk 不需要回调的时候，这个对象会为 null，所以当使用的时候需要做一下非null判断
     *                 return 如果不需要对进行处理，直接返回 param 的 entry ，如果需要进行处理，则返回处理后的数据(entry 的中没有处理的数据也需要透传回给 sdk)
     */
    void onEvent(T t, Context context, EventCallback<T> callback);

    /**
     * 当拒绝相关权限后,回调给客户的处理方法
     *
     * @param context        当前界面的 context 对象，使用之前请判断是否为 null
     * @param t         该 t 中存放了事件所需要的数据
     */
    default boolean onDenyEvent(Context context, T t) {
        return false;
    }
}
