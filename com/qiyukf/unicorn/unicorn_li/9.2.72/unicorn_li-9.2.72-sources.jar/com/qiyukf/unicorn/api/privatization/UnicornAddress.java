package com.qiyukf.unicorn.api.privatization;

import androidx.annotation.NonNull;

import java.io.Serializable;

/**
 * Describe: 七鱼私有化地址配置
 */
public class UnicornAddress implements Serializable {

    /**
     * 访问轨迹上报 url
     * default https://da.qiyukf.com
     */
    public String daUrl;


    /**
     * 七鱼默认 url
     * defalut https://nim.qiyukf.com
     */
    public String defaultUrl;

    @NonNull
    @Override
    public String toString() {
        return "defaultUrl:" + defaultUrl + ", daUrl" + daUrl;
    }
}
