package com.qiyukf.unicorn.api.customization.page_ad;

import java.io.Serializable;

/**
 * Describe: 聊天界面增加的 view 的相关配置信息
 */
public class IMPageViewConfig implements Serializable {

    /**
     * 聊天界面广告 view 的 provider
     */
    public transient AdViewProvider adViewProvider;
}
