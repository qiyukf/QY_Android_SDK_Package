package com.qiyukf.unicorn.api;

import android.content.Context;

public interface ReportLocationEvent {

    /**
     * 上报位置坐标
     *
     * @param context 上下文
     */
    void reportCoordinates(Context context, long sessionId);
}
