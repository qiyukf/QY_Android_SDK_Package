package com.qiyukf.unicorn.api.customization.msg_list.baseviewholder;


import com.qiyukf.uikit.common.adapter.TViewHolder;

/**
 * 自定义 sdk 中没有的消息类型的 UI 的抽象类，如果想自定义消息的 UI ，可通过继承此类来完成
 * 我们把一条消息看作一个 viewHolder，填充 viewHolder 的数据，我们把他
 * 叫做 attachment，不同的 viewHolder 对应不同的 attachment
 * attachment 可以通过实现 MsgAttachment 去定义， viewHolder 可以通过继承该类去定义
 */
public abstract class CustomMessageViewHolderBase extends TViewHolder {

    /**
     * 该方法必须重写，返回 viewHolder 的 layout id
     *
     * @return layout id
     */
    protected abstract int getResId();

    /**
     * 在该方法中去完成 findViewById 的操作，一定要在该方法中去 findViewById，
     */
    protected abstract void inflate();

    /**
     * 刷新 listview 的时候的相关操作，也就是刷新数据的处理，该方法是真正把一条数据和 UI 绑定的方法
     * item 实际上就是一条 IMMessage(消息) 可以通过 message = (IMMessage) item 转换成消息，
     * 然后通过 message.getAttachment
     * 就可以拿到数据源
     */

    protected abstract void refresh(Object item);
}
